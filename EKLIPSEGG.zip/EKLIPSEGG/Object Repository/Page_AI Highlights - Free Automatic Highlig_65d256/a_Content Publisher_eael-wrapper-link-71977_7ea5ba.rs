<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Content Publisher_eael-wrapper-link-71977_7ea5ba</name>
   <tag></tag>
   <elementGuidId>58281143-daea-496b-8e67-3919c1b25a94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-719770b.--eael-wrapper-link-tag</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/content-planner/')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bbde7cdc-323b-49d9-9b46-7e3f27d70fe0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-719770b --eael-wrapper-link-tag</value>
      <webElementGuid>5f18a3fc-059f-4c4d-b4ff-f5982ccc26b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/content-planner/</value>
      <webElementGuid>b081fde9-54e7-4110-b8f6-c884db1544b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-2136 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-2136 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8f4d5bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d94e4cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1c0d477 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-719770b elementor-position-left elementor-position-left elementor-vertical-align-middle elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-719770b --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>207560f7-8fcf-47ba-89ae-0eff072a3b8e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/content-planner/')])[3]</value>
      <webElementGuid>504ec337-04a8-4e6a-bdfd-bab0aeba0201</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a</value>
      <webElementGuid>fa4dee71-b1fa-4763-adb8-bf1651797be0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/content-planner/']</value>
      <webElementGuid>a9ea48fd-d745-4b86-99cd-37bccc5e07cb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
