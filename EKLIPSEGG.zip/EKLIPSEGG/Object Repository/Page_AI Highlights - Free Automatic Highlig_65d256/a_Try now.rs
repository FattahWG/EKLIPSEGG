<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Try now</name>
   <tag></tag>
   <elementGuidId>27197961-024e-499c-bce4-a7990d02c374</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Turn Your Streams into Viral Highlights with AI!'])[1]/following::a[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.elementor-button.elementor-button-link.elementor-size-lg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b5e61efb-77d4-4bae-a42b-20a29c178324</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-button-link elementor-size-lg</value>
      <webElementGuid>1c529e0c-e020-4e47-b540-95ea59477a60</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg%2Ffeatures%2Fai-highlights&amp;_gl=1*bnyfi5*_gcl_au*ODEzMzAyNTI3LjE3NTEyMjc3ODM.*_ga*MTczMjEzMzc2Ny4xNzUxMjI3Nzgz*_ga_GLD7CWERS9*czE3NTEyMjc3ODIkbzEkZzEkdDE3NTEyMjc4MDMkajM5JGwwJGgw*_ga_WQX826KJ2T*czE3NTEyMjc3ODYkbzEkZzEkdDE3NTEyMjc4MDQkajQyJGwwJGgw</value>
      <webElementGuid>30fae9c3-4b92-4d3a-ba56-086a193422ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
									Try now!
					
					</value>
      <webElementGuid>304474cd-68bd-4fa3-96cf-a5727d0a88a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-2136 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-2136 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-2136&quot;]/div[@class=&quot;elementor-element elementor-element-f88fe8a bg-radian e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-62a4c68 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-e67c2ef e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-a085a04 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-3570fc8 elementor-align-center elementor-widget elementor-widget-button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/div[@class=&quot;elementor-button-wrapper&quot;]/a[@class=&quot;elementor-button elementor-button-link elementor-size-lg&quot;]</value>
      <webElementGuid>26439d0a-6e8b-4ffb-9c7c-bbcd113559d1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Turn Your Streams into Viral Highlights with AI!'])[1]/following::a[1]</value>
      <webElementGuid>ae33dc05-4be2-49d4-808d-7b21c43961e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::a[1]</value>
      <webElementGuid>853da1dc-282b-485a-a353-75a183c7b10c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg%2Ffeatures%2Fai-highlights&amp;_gl=1*bnyfi5*_gcl_au*ODEzMzAyNTI3LjE3NTEyMjc3ODM.*_ga*MTczMjEzMzc2Ny4xNzUxMjI3Nzgz*_ga_GLD7CWERS9*czE3NTEyMjc3ODIkbzEkZzEkdDE3NTEyMjc4MDMkajM5JGwwJGgw*_ga_WQX826KJ2T*czE3NTEyMjc3ODYkbzEkZzEkdDE3NTEyMjc4MDQkajQyJGwwJGgw')]</value>
      <webElementGuid>65698874-9e66-4349-a561-3b661e34a7f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div/div/div/div[3]/div/div/a</value>
      <webElementGuid>d27c1ce6-4117-43d8-828b-395affd7ddb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg%2Ffeatures%2Fai-highlights&amp;_gl=1*bnyfi5*_gcl_au*ODEzMzAyNTI3LjE3NTEyMjc3ODM.*_ga*MTczMjEzMzc2Ny4xNzUxMjI3Nzgz*_ga_GLD7CWERS9*czE3NTEyMjc3ODIkbzEkZzEkdDE3NTEyMjc4MDMkajM5JGwwJGgw*_ga_WQX826KJ2T*czE3NTEyMjc3ODYkbzEkZzEkdDE3NTEyMjc4MDQkajQyJGwwJGgw' and (text() = '
						
									Try now!
					
					' or . = '
						
									Try now!
					
					')]</value>
      <webElementGuid>4524738b-c161-49be-8769-3b2da5beb76a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
