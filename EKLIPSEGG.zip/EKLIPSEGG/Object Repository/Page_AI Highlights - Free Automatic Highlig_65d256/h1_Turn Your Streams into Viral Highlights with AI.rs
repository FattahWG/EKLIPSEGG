<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Turn Your Streams into Viral Highlights with AI</name>
   <tag></tag>
   <elementGuidId>99dec334-1e08-4691-af58-dfaf32f0df3f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1.elementor-heading-title.elementor-size-default</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>c8a3b272-c3ed-4d16-acba-512f73ecb1c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>3e6eb8ce-98ed-4e56-89df-8d8983d5fd44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Turn Your Streams into Viral Highlights with AI!</value>
      <webElementGuid>cc7f73f1-9a9e-4744-a6e9-3316f63cb5b1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-2136 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-2136 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-2136&quot;]/div[@class=&quot;elementor-element elementor-element-f88fe8a bg-radian e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-62a4c68 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-e67c2ef e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-a085a04 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-f2ab276 BasementGrotesque elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h1[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>27994dc3-e27e-4ed3-a320-1fe2dc2c2015</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      <webElementGuid>58428f59-1488-45bc-806c-e3fed4153982</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::h1[1]</value>
      <webElementGuid>0622f451-daaa-4262-bfed-b477352c09d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try now!'])[1]/preceding::h1[1]</value>
      <webElementGuid>e7b80fa0-2ebd-4393-991b-bd2f7dd7d3f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Turn Your Streams into Viral Highlights with AI!']/parent::*</value>
      <webElementGuid>5ef510f1-7bc5-4249-8c9d-229f387ed654</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>42bc53f1-2bde-456c-8a9a-6bf5b63701fc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Turn Your Streams into Viral Highlights with AI!' or . = 'Turn Your Streams into Viral Highlights with AI!')]</value>
      <webElementGuid>04befcb7-ceea-4b26-8a96-4b5a0eea952e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
