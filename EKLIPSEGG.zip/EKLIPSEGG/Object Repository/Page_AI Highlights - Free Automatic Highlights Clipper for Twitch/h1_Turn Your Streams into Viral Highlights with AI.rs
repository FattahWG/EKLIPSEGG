<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Turn Your Streams into Viral Highlights with AI</name>
   <tag></tag>
   <elementGuidId>e06a555f-529e-4bf9-9a7d-654154e59177</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.elementor-heading-title.elementor-size-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>60686cbd-740a-4d61-818f-0276e13ca99e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>6b989d51-83fe-4a49-8665-1e0cd789fed6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Turn Your Streams into Viral Highlights with AI!</value>
      <webElementGuid>01cbd346-3fd7-4f01-9312-fbb723a4dc0b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-2136 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-2136 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-2136&quot;]/div[@class=&quot;elementor-element elementor-element-f88fe8a bg-radian e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-62a4c68 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-e67c2ef e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-a085a04 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-f2ab276 BasementGrotesque elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h1[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>b358bdfa-bea1-42ac-b660-8b8bed3d21e9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      <webElementGuid>99d45b4d-650f-4a15-8e0d-80c3bf995fc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::h1[1]</value>
      <webElementGuid>31a7868a-6858-4a15-8d4f-cd049c225cfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try now!'])[1]/preceding::h1[1]</value>
      <webElementGuid>29507a17-eb1c-4a06-a5ed-8c1a56fc3b55</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Turn Your Streams into Viral Highlights with AI!']/parent::*</value>
      <webElementGuid>05d82e01-7c1a-474f-bc30-253c47cea218</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>83d00ab8-b54f-4634-9964-6d228fe4c06b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Turn Your Streams into Viral Highlights with AI!' or . = 'Turn Your Streams into Viral Highlights with AI!')]</value>
      <webElementGuid>49dd228c-51fb-4085-921e-df9ed7880ae3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
