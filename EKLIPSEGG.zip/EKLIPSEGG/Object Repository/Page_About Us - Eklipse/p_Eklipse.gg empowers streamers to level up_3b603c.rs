<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Eklipse.gg empowers streamers to level up_3b603c</name>
   <tag></tag>
   <elementGuidId>57c8b3d6-f0d9-4dfd-9bee-1540dd553c71</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-65cc851.elementor-widget.elementor-widget-text-editor > div.elementor-widget-container > p</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='The All-in-One Streamer Toolkit'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>12e149db-defb-42ae-8142-5a02c4c6f29d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Eklipse.gg empowers streamers to level up their content creation and reach new audiences with its innovative AI-powered tools. This all-in-one platform streamlines your workflow by automatically generating highlight clips from your streams, saving you valuable time and effort.</value>
      <webElementGuid>7b5e64ed-83b1-4284-b7ec-8522d7a5ac7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-16843 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-16843 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-16843&quot;]/div[@class=&quot;elementor-element elementor-element-3a53705 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-2b10117 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-65cc851 elementor-widget elementor-widget-text-editor&quot;]/div[@class=&quot;elementor-widget-container&quot;]/p[1]</value>
      <webElementGuid>9726201a-6fef-4a3d-a265-d0e22c77da6a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The All-in-One Streamer Toolkit'])[1]/following::p[1]</value>
      <webElementGuid>22102ad3-058b-4346-935d-ab7790cd9351</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eklipse.gg'])[1]/following::p[1]</value>
      <webElementGuid>4eb36609-59b5-433d-b5eb-24aa21e3ac52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Eklipse.gg empowers streamers to']/parent::*</value>
      <webElementGuid>c410fd16-256c-4946-96de-b00176e9b08a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/p</value>
      <webElementGuid>699138db-3a90-4891-a849-281ac24a797c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Eklipse.gg empowers streamers to level up their content creation and reach new audiences with its innovative AI-powered tools. This all-in-one platform streamlines your workflow by automatically generating highlight clips from your streams, saving you valuable time and effort.' or . = 'Eklipse.gg empowers streamers to level up their content creation and reach new audiences with its innovative AI-powered tools. This all-in-one platform streamlines your workflow by automatically generating highlight clips from your streams, saving you valuable time and effort.')]</value>
      <webElementGuid>0e5554b8-d194-42ba-8439-00dd51d0b08c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
