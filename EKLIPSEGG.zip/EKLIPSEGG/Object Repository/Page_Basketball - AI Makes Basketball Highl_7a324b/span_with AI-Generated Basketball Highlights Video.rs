<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_with AI-Generated Basketball Highlights Video</name>
   <tag></tag>
   <elementGuidId>a66e71cf-1958-4fa9-a2e2-8959998bdc96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Key Moment'])[1]/following::span[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7c382f73-83e0-4dfa-a48a-08a6ce19f70c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-headline-plain-text elementor-headline-text-wrapper</value>
      <webElementGuid>cda95605-9f56-40a4-b42e-6c2ca7147b49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>with AI-Generated Basketball Highlights Video</value>
      <webElementGuid>900c6efe-e3c0-44cd-bf95-0cfcf9d676c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-15124 page-child parent-pageid-15290 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-15124 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-15124&quot;]/div[@class=&quot;elementor-element elementor-element-b5faee5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-57f3546 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-ecfe697 BasementGrotesque elementor-headline--style-highlight elementor-widget elementor-widget-animated-headline&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h1[@class=&quot;elementor-headline e-animated&quot;]/span[@class=&quot;elementor-headline-plain-text elementor-headline-text-wrapper&quot;]</value>
      <webElementGuid>517f653e-0904-43a4-a666-07a0897d0cd0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Key Moment'])[1]/following::span[1]</value>
      <webElementGuid>637941d9-d139-4151-a872-b3de7823e3bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Never Miss a'])[1]/following::span[4]</value>
      <webElementGuid>a933953f-4672-4ccc-829e-2da6603396fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try now'])[1]/preceding::span[1]</value>
      <webElementGuid>f7be5acb-9632-4d95-9164-2ae69217e58a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New Features'])[1]/preceding::span[1]</value>
      <webElementGuid>1da148bd-c9b0-4761-a7e7-5035398ff07f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='with AI-Generated']/parent::*</value>
      <webElementGuid>08e6cbf2-0fe2-423a-a369-7ed8d85e9ed7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]</value>
      <webElementGuid>a4e68ca9-c5d7-4967-bef7-12c177f1069b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'with AI-Generated Basketball Highlights Video' or . = 'with AI-Generated Basketball Highlights Video')]</value>
      <webElementGuid>f75c47ab-f30d-4d84-bae1-6187b8c6b493</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
