<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Brand Essentials for Creators and Partners</name>
   <tag></tag>
   <elementGuidId>93bff428-aa90-47da-b4ed-87351b0e80fa</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-2f34af3.elementor-widget.elementor-widget-heading > div.elementor-widget-container > h2.elementor-heading-title.elementor-size-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>18a921b7-153c-4a21-b44e-b9cdf1be9bc1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>15f796b7-e234-4675-b9f4-6b33f659bf82</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Brand Essentials for Creators and Partners</value>
      <webElementGuid>0d5b6f7e-341d-4824-87dc-6cea20be3805</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-17058 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-17058 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-17058&quot;]/div[@class=&quot;elementor-element elementor-element-7274509 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-bf6d938 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-2f34af3 elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h2[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>dac1b247-7d69-4588-aca0-78dd4e299f06</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h2[1]</value>
      <webElementGuid>22ae82e3-7ecb-4c35-9141-b54a54f6da30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::h2[1]</value>
      <webElementGuid>e4fc1706-eb55-4e87-86d0-1e69b7a540d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Become Affiliate'])[1]/preceding::h2[1]</value>
      <webElementGuid>f69a9731-10b4-4f39-9dee-35a02e4d0b65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Partner with Us'])[1]/preceding::h2[1]</value>
      <webElementGuid>57405789-0749-4c96-919f-742a5033d2bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Brand Essentials for Creators and Partners']/parent::*</value>
      <webElementGuid>3831a379-74bb-42e6-ac3c-afa30f7de296</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div/div/div/h2</value>
      <webElementGuid>8ed6c021-826e-47f1-8cdd-fa03fc3172a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Brand Essentials for Creators and Partners' or . = 'Brand Essentials for Creators and Partners')]</value>
      <webElementGuid>659a823f-b856-4ec8-b7d2-53aa548688b5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
