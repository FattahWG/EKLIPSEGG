<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_beta_eael-wrapper-link-e79ba2f --eael-wra_8130f9</name>
   <tag></tag>
   <elementGuidId>87924c38-9e28-4965-9c23-0873209c062e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-e79ba2f.--eael-wrapper-link-tag</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-edit/')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>541f6819-8b03-4eb5-abe3-2fdc46215835</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-e79ba2f --eael-wrapper-link-tag</value>
      <webElementGuid>fa7769a3-baab-49f9-9baf-2dd4271cb9b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/ai-edit/</value>
      <webElementGuid>4506ee4a-283f-4912-851a-e49278c7ebe8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-7575 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-7575 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8f4d5bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d94e4cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1c0d477 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-e79ba2f elementor-position-left elementor-position-left elementor-vertical-align-middle elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-e79ba2f --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>cc18d4bf-c945-456a-bcb9-b00d1d88e711</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-edit/')])[3]</value>
      <webElementGuid>4df8bd62-09a3-4ebd-b0c7-48b75879fa4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/a</value>
      <webElementGuid>bb291a8d-33f4-4c98-a45e-6e8cebbb4a06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/ai-edit/']</value>
      <webElementGuid>935c5254-1039-48ea-be22-26acec02f335</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
