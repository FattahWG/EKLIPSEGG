<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_beta_eael-wrapper-link-e79ba2f --eael-wrapper-link-tag</name>
   <tag></tag>
   <elementGuidId>6755781e-df83-4ee9-996d-b00002e8af8a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-e79ba2f.--eael-wrapper-link-tag</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-edit/')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c7f12f3d-7c48-4c21-b047-a5beb7f9d828</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-e79ba2f --eael-wrapper-link-tag</value>
      <webElementGuid>856c4652-cfea-4085-85c0-4035591bcbac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/ai-edit/</value>
      <webElementGuid>a020870e-49c0-4fef-81f5-ad6e79f48bb3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-7575 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-7575 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8f4d5bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d94e4cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1c0d477 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-e79ba2f elementor-position-left elementor-position-left elementor-vertical-align-middle elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-e79ba2f --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>79c31051-abc4-4804-8b98-5f09b4187a48</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-edit/')])[3]</value>
      <webElementGuid>adde6eeb-19bd-4885-a43d-9468667e82fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/a</value>
      <webElementGuid>248c1e5f-8dec-4bfc-9957-73bd9d704217</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/ai-edit/']</value>
      <webElementGuid>1f54364e-afe0-4139-a76a-c80cd8b4abad</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
