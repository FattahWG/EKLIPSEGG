<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Content Publisher</name>
   <tag></tag>
   <elementGuidId>6f47c1c3-2865-4f75-ac69-e9fd47937e19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.elementor-heading-title.elementor-size-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>70a4e78d-6fa4-4658-bc40-6c1eeaa8e6be</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>2b863e8a-db56-4033-b4fd-738e9de0e9d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Content Publisher</value>
      <webElementGuid>962fb78f-2128-46d3-b3aa-d8b5615c4fec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-7575 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-7575 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-7575&quot;]/div[@class=&quot;elementor-element elementor-element-1c91c27 bg-radian e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-7e85139 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-af0deff BasementGrotesque elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h1[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>14c784a5-0bf6-4299-91e6-fb82263764b4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h1[1]</value>
      <webElementGuid>d773ae6b-9ca8-4f12-8fc5-27c11125b7af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::h1[1]</value>
      <webElementGuid>db3a54da-20d0-4210-af5e-83f41e1ecc48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try now'])[1]/preceding::h1[1]</value>
      <webElementGuid>607362d5-f677-4f53-a0ea-de273422faab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eklipse Helps You From Start to Finish'])[1]/preceding::h1[1]</value>
      <webElementGuid>2a275135-207e-441a-a657-6ca04409485c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>f90395f2-2230-4b6f-a596-4d1bb8c710b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Content Publisher' or . = 'Content Publisher')]</value>
      <webElementGuid>e4ad5e40-e136-4b1e-b7e4-ffcf38899b71</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
