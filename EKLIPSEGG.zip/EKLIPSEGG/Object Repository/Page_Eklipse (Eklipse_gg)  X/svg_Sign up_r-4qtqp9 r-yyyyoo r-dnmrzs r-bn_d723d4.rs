<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Sign up_r-4qtqp9 r-yyyyoo r-dnmrzs r-bn_d723d4</name>
   <tag></tag>
   <elementGuidId>8de71ccb-4f22-488a-a1a8-2019ed270f2a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>svg.r-4qtqp9.r-yyyyoo.r-dnmrzs.r-bnwqim.r-lrvibr.r-m6rgpd.r-lrsllp.r-1nao33i.r-16y2uox.r-8kz0gk</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>7d1c59bc-33af-43d9-92f0-044d6a787868</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>69f614fe-24ca-40c2-8ec6-78b39fa39c6a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>e07126c9-ea8e-4d47-86f5-fcca09ae1c25</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>r-4qtqp9 r-yyyyoo r-dnmrzs r-bnwqim r-lrvibr r-m6rgpd r-lrsllp r-1nao33i r-16y2uox r-8kz0gk</value>
      <webElementGuid>cc994a83-0641-4d00-8943-69d95e645126</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;react-root&quot;)/div[@class=&quot;css-175oi2r r-13awgt0 r-12vffkv&quot;]/div[@class=&quot;css-175oi2r r-13awgt0 r-12vffkv&quot;]/div[@class=&quot;css-175oi2r r-1f2l425 r-13qz1uu r-417010 r-18u37iz&quot;]/header[@class=&quot;css-175oi2r r-lrvibr r-1g40b8q r-obd0qt r-16y2uox&quot;]/div[@class=&quot;css-175oi2r r-1gymjhz&quot;]/div[@class=&quot;css-175oi2r r-aqfbo4 r-1pi2tsx r-1xcajam r-ipm5af&quot;]/div[@class=&quot;css-175oi2r r-1pi2tsx r-1wtj0ep r-1rnoaur r-1gymjhz r-n7gxbd&quot;]/div[@class=&quot;css-175oi2r r-1awozwy&quot;]/div[@class=&quot;css-175oi2r r-dnmrzs r-1559e4e&quot;]/h1[@class=&quot;css-175oi2r r-1awozwy r-1pz39u2 r-1loqt21 r-6koalj r-16y2uox r-1777fci r-4wgw6l&quot;]/a[@class=&quot;css-175oi2r r-sdzlij r-1phboty r-rs99b7 r-lrvibr r-19yznuf r-64el8z r-o7ynqc r-6416eg r-pjtv4k r-1ny4l3l r-1loqt21&quot;]/div[@class=&quot;css-146c3p1 r-bcqeeo r-qvutc0 r-1qd0xha r-q4m81j r-a023e6 r-rjixqe r-b88u0q r-1awozwy r-6koalj r-18u37iz r-16y2uox r-1777fci&quot;]/svg[@class=&quot;r-4qtqp9 r-yyyyoo r-dnmrzs r-bnwqim r-lrvibr r-m6rgpd r-lrsllp r-1nao33i r-16y2uox r-8kz0gk&quot;]</value>
      <webElementGuid>6486e3e8-5bc5-4abe-804e-ac6ff812e72a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>e5428607-90ec-4968-93ab-20cf7a711d9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Log in'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>1e4a34fd-370b-481a-99f0-6d5caa13700c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eklipse'])[1]/preceding::*[name()='svg'][2]</value>
      <webElementGuid>6e45371c-7c04-4aac-a967-9fc42ace13c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='See new posts'])[1]/preceding::*[name()='svg'][5]</value>
      <webElementGuid>49199df4-73bc-4cc5-98df-aaef73e435a4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
