<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_AI Edit</name>
   <tag></tag>
   <elementGuidId>2e399f3d-a144-43a4-95a8-c4cd47356a48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.text-highlight2.view-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Content'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>df60faea-b804-4483-a0cb-aba5345ad6dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-highlight2 view-text</value>
      <webElementGuid>20eb1b3b-d617-4166-9da5-1f2e8d0ee0a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AI Edit</value>
      <webElementGuid>2410c68e-84ed-4d62-b9e8-dcdf29c8b118</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-16051 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-16051 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-16051&quot;]/div[@class=&quot;elementor-element elementor-element-24ea196 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8bdf48d e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-c2f4b63 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-6a96211 elementor-headline--style-highlight elementor-widget elementor-widget-animated-headline&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h3[@class=&quot;elementor-headline e-animated&quot;]/span[@class=&quot;elementor-headline-plain-text elementor-headline-text-wrapper&quot;]/span[@class=&quot;text-highlight2 view-text&quot;]</value>
      <webElementGuid>6fb88c2a-b750-40af-b8c3-7fc1623ce8af</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content'])[1]/following::span[2]</value>
      <webElementGuid>fbe49923-6150-45ca-afef-0e600b444dc9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automatically edit clips with'])[1]/preceding::span[1]</value>
      <webElementGuid>2107d368-07b5-477c-b406-159514a621ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Spotlight'])[1]/preceding::span[1]</value>
      <webElementGuid>6ec37187-27a7-4376-b643-6104583ac76c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span</value>
      <webElementGuid>d808a269-56ac-4848-85ac-a24d07105263</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'AI Edit' or . = 'AI Edit')]</value>
      <webElementGuid>ef432869-5584-47e5-b128-b832b525ad5c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
