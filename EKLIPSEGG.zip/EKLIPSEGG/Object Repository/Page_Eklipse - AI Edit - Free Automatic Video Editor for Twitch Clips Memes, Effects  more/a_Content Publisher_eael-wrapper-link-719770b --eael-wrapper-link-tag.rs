<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Content Publisher_eael-wrapper-link-719770b --eael-wrapper-link-tag</name>
   <tag></tag>
   <elementGuidId>c29f568f-37ae-4b96-9893-995d05c55a88</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-719770b.--eael-wrapper-link-tag</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/content-planner/')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>f890b399-e707-40d7-86cd-c0abee072a6c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-719770b --eael-wrapper-link-tag</value>
      <webElementGuid>c41a66ab-2a5b-45dd-aed3-52e555832ac7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/content-planner/</value>
      <webElementGuid>391df81b-70a5-4cb9-a5a7-7aed8f2982b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-16051 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-16051 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8f4d5bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d94e4cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1c0d477 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-719770b elementor-position-left elementor-position-left elementor-vertical-align-middle elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-719770b --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>57c1e994-c10f-4e78-99d5-90945a3b35b7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/content-planner/')])[3]</value>
      <webElementGuid>7436cbae-e0dd-4e5c-a96a-695ae6b6f828</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/a</value>
      <webElementGuid>59775144-9ceb-46ba-8514-dc99f798e53a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/content-planner/']</value>
      <webElementGuid>d2f45ef8-fa4f-46bf-89b3-ccf5587aea41</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
