<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_AI Edit</name>
   <tag></tag>
   <elementGuidId>4d46d091-5034-4f15-8cdb-d87970eedc66</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>span.text-highlight2.view-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Content'])[1]/following::span[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>ff9e4186-5650-427e-a852-9a94d236206a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-highlight2 view-text</value>
      <webElementGuid>0aff62fc-0675-4cdd-a0d6-9360d356e63b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AI Edit</value>
      <webElementGuid>d5ed9c24-4c55-408c-bc66-6a530dde6c7e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-16051 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-16051 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-16051&quot;]/div[@class=&quot;elementor-element elementor-element-24ea196 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8bdf48d e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-c2f4b63 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-6a96211 elementor-headline--style-highlight elementor-widget elementor-widget-animated-headline&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h3[@class=&quot;elementor-headline e-animated&quot;]/span[@class=&quot;elementor-headline-plain-text elementor-headline-text-wrapper&quot;]/span[@class=&quot;text-highlight2 view-text&quot;]</value>
      <webElementGuid>3133fe6a-daa5-4c66-83cc-0c783a9f7f51</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content'])[1]/following::span[2]</value>
      <webElementGuid>f798c456-62d4-4fa9-8efd-e1a81c87c1d7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Automatically edit clips with'])[1]/preceding::span[1]</value>
      <webElementGuid>70e0f848-0cf4-4958-9d20-8eba5935e795</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Spotlight'])[1]/preceding::span[1]</value>
      <webElementGuid>bf75e1bc-a05d-4e32-9caf-3a7a6d3c0370</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/span</value>
      <webElementGuid>c34a8ef0-3e36-4333-9967-12050587ed65</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'AI Edit' or . = 'AI Edit')]</value>
      <webElementGuid>a89e5117-6f6e-4311-ba70-3f367e16b7b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
