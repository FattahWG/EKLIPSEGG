<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Download App</name>
   <tag></tag>
   <elementGuidId>98245437-8c64-4740-ae0c-f30e2e5619c2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.btn.btn-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Download App')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bc26e227-9b2f-45d6-93b3-dad9e54c1beb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipsegg.onelink.me/lNPZ/premium</value>
      <webElementGuid>63798b93-adba-40b0-bec3-d2acccca0c1f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-link</value>
      <webElementGuid>61b8e66a-717e-4119-bf0e-83b13c9d814f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Download App</value>
      <webElementGuid>4caea3a2-2001-4762-b112-bb1e395351d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-b2f38de e-flex e-con-boxed e-con e-parent elementor-motion-effects-element elementor-motion-effects-element-type-background e-lazyloaded&quot;]/div[@class=&quot;e-con-inner&quot;]/div[@class=&quot;elementor-element elementor-element-eaac217 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-4c204cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-23263a4 elementor-widget__width-auto elementor-widget-widescreen__width-auto elementor-widget elementor-widget-ek_elementor_button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[@class=&quot;btn btn-link&quot;]</value>
      <webElementGuid>34a16906-6656-4c3f-8719-1cf32acf076d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Download App')]</value>
      <webElementGuid>641635f9-dbce-4332-8387-e7dcd6386ba2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ready to go viral?'])[1]/following::a[1]</value>
      <webElementGuid>776655cb-e6e0-4093-b636-8a4f898428cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Built for everyone, every creator'])[1]/preceding::a[1]</value>
      <webElementGuid>288b04bb-0714-45f0-8ea2-a9e4bfa0dec0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Compatible with any console'])[1]/preceding::a[1]</value>
      <webElementGuid>68bcdc11-59a9-41fa-a86a-ae0cdf3713fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Download App']/parent::*</value>
      <webElementGuid>b624c1a4-213f-4060-aa3d-824c54f75961</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://eklipsegg.onelink.me/lNPZ/premium')]</value>
      <webElementGuid>71619cf0-6f9d-4daa-b6ce-5da30d570df0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/div[2]/div[3]/div/div/a</value>
      <webElementGuid>80ef73c8-f5d3-49ad-8732-b45db81a662d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipsegg.onelink.me/lNPZ/premium' and (text() = 'Download App' or . = 'Download App')]</value>
      <webElementGuid>4834d350-daad-4e54-888a-8b0ecc65c64d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
