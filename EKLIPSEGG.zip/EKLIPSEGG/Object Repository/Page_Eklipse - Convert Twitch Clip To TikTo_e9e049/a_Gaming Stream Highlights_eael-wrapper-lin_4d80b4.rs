<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Gaming Stream Highlights_eael-wrapper-lin_4d80b4</name>
   <tag></tag>
   <elementGuidId>e2cc2cda-59a4-4fbd-bdbe-ebd1308271b3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-highlights/')])[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-1ea88d9.--eael-wrapper-link-tag</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>6d73aee6-314a-46fa-b6cb-afa6551d2f6f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-1ea88d9 --eael-wrapper-link-tag</value>
      <webElementGuid>45ee03f5-b59a-4e2e-818c-657ef2e118e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/ai-highlights/</value>
      <webElementGuid>2bacddc3-74c7-483d-9191-aa363693d04e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8f4d5bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d94e4cb e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1c0d477 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1ea88d9 elementor-position-left elementor-position-left elementor-vertical-align-middle elementor-widget__width-initial elementor-widget-mobile__width-initial elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-1ea88d9 --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>8f89b030-f575-4a41-9dc9-cc106f2860db</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-highlights/')])[3]</value>
      <webElementGuid>0dda6d43-2e62-4d26-a0b3-7404da2127f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/a</value>
      <webElementGuid>88b03d55-31f6-48f4-885d-5f1a9638777b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/ai-highlights/']</value>
      <webElementGuid>34c59822-baf5-4db9-8946-361a4c88604b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
