<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Learn more</name>
   <tag></tag>
   <elementGuidId>d5d4fee4-be5c-4cea-a3e9-ef497b6ee584</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-b4dbcd9.elementor-widget__width-auto.elementor-widget-widescreen__width-auto.elementor-widget.elementor-widget-ek_elementor_button > div.elementor-widget-container > a.btn.btn-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Learn more')])[7]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>ad16f38e-a0bd-4a33-b227-da6335df2c8f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/content-planner/</value>
      <webElementGuid>0c092b1a-f96e-4d38-a654-44d124a3b059</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-link</value>
      <webElementGuid>e218a97e-704e-4980-b5d4-12b3f6184be8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Learn more</value>
      <webElementGuid>644134e8-91a4-4dc2-8818-5c7f870c9a6d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-1835234 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-b4dbcd9 elementor-widget__width-auto elementor-widget-widescreen__width-auto elementor-widget elementor-widget-ek_elementor_button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[@class=&quot;btn btn-link&quot;]</value>
      <webElementGuid>f7acaa62-f9d2-4629-8b42-bb43f4549e05</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Learn more')])[7]</value>
      <webElementGuid>7f4182bd-a894-4fe5-ac67-a2318619d7e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Scheduling'])[1]/following::a[1]</value>
      <webElementGuid>7f79a9f5-8f98-4148-aea3-77962185b61b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features'])[9]/following::a[1]</value>
      <webElementGuid>913c336b-97c0-47c0-982f-b35e67eff600</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Premium Features'])[1]/preceding::a[1]</value>
      <webElementGuid>6134eee5-bbf3-4b05-b709-93962b7081b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Premium Just Got a Whole Lot Better'])[1]/preceding::a[2]</value>
      <webElementGuid>6353adc9-6875-4618-9a87-67e2a1da6efc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/content-planner/')])[4]</value>
      <webElementGuid>cc1578bd-9210-4e42-aee1-205e1b2c3703</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div[4]/div/a</value>
      <webElementGuid>b55983ff-5285-45bd-9ede-f2766983e3f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/content-planner/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>dc9cb880-1d85-453f-83c5-1fa78ecefc17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Learn more')])[6]</value>
      <webElementGuid>47b60f64-ab54-4e2a-a8d8-0e4d5b06e049</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Stickers'])[1]/following::a[1]</value>
      <webElementGuid>706b1a8b-a039-4b27-8ad4-503a8f527944</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features'])[6]/following::a[1]</value>
      <webElementGuid>f97318a2-dbd9-409f-b56d-280b6b81211a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content Planner'])[1]/preceding::a[1]</value>
      <webElementGuid>b0afe56d-3951-4d15-8bd7-8bb749b40ba7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Plan and Post Content'])[1]/preceding::a[2]</value>
      <webElementGuid>fcb75de9-4dae-4a72-992a-01de6371f65a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/eklipse-studio/')])[4]</value>
      <webElementGuid>dad88d94-3c7d-4961-872e-6480f390d1cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[4]/div/a</value>
      <webElementGuid>7e548062-843d-4ed0-9a7f-eef402016687</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/eklipse-studio/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>fa2edd2e-e3bd-4754-afa7-e17b8c9b8b41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Learn more')]</value>
      <webElementGuid>299f28df-6b2b-4d83-9870-504794981fe5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Highlights'])[1]/following::a[1]</value>
      <webElementGuid>19c0458e-8d71-4c59-bb15-eabf55fba3bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Powered Clips At Your Fingertips'])[1]/following::a[1]</value>
      <webElementGuid>81de4d3e-27f5-44b1-acad-b68803ed1914</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Edit'])[2]/preceding::a[1]</value>
      <webElementGuid>4db0a431-1bed-4f21-b192-fd6d3bec86d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[2]/preceding::a[1]</value>
      <webElementGuid>015c9382-02aa-4f67-b74e-142f53230ad9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Learn more']/parent::*</value>
      <webElementGuid>820a1d11-a0f4-4daf-a04a-80d191bc1c80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-highlights/')])[4]</value>
      <webElementGuid>3e903194-7977-41d8-8588-56b6634fffd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/div/div[3]/div/div/a</value>
      <webElementGuid>2bad81c4-8e3b-4555-835c-35dd2b20809f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/ai-highlights/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>ed742bf6-0d11-4931-8635-7013ccca66ca</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
