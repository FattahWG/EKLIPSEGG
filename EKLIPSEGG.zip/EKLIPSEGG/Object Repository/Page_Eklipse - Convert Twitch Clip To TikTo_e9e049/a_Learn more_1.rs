<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Learn more_1</name>
   <tag></tag>
   <elementGuidId>3b29cfca-8f81-45a3-989f-171d2ca2a65d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-9ee4265.elementor-widget.elementor-widget-ek_elementor_button > div.elementor-widget-container > a.btn.btn-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Learn more')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5443ffa5-ad2a-4014-b04c-ed9fe3d70e19</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/ai-edit/</value>
      <webElementGuid>da5cb86d-cb79-4a65-bce0-7cd9179aedfa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-link</value>
      <webElementGuid>fff4cc5e-3a4f-41da-b64a-322ee47f04d7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Learn more</value>
      <webElementGuid>131ba48a-9742-4f95-bd97-29f2c2b932bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-1e14b0b e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-dcdd3d3 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-335895a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-db710b2 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-72c7d43 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-9ee4265 elementor-widget elementor-widget-ek_elementor_button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[@class=&quot;btn btn-link&quot;]</value>
      <webElementGuid>a0dfab6d-1006-46ab-bbe8-2c3755cc75f9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Learn more')])[2]</value>
      <webElementGuid>090d0fb4-0587-47c6-bbc8-790d2950c73a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Edit'])[2]/following::a[1]</value>
      <webElementGuid>d9138fee-0855-455a-b4b1-4abefaeacee3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[1]/following::a[1]</value>
      <webElementGuid>f192ebce-1d6c-4341-af6e-84843a773759</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mobile App'])[2]/preceding::a[1]</value>
      <webElementGuid>e3e10584-0744-419b-a63b-4657fceb1680</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[3]/preceding::a[1]</value>
      <webElementGuid>7d624228-5833-4f28-98f3-cc89cfe10e61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/ai-edit/')])[4]</value>
      <webElementGuid>cd2d5309-e0c6-4fe1-babc-c8ce14b55afe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/div[2]/div[3]/div/div/a</value>
      <webElementGuid>930057f0-8c5f-4344-95a2-e26107266bea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/ai-edit/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>b9e00206-4a50-4616-a172-9cb33fbc2f49</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
