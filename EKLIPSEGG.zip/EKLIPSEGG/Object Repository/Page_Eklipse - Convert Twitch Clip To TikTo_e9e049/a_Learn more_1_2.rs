<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Learn more_1_2</name>
   <tag></tag>
   <elementGuidId>aa085d4e-b60b-4df3-85a5-a2b52e0779ee</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-8be6b20.elementor-widget.elementor-widget-ek_elementor_button > div.elementor-widget-container > a.btn.btn-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Learn more')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>cd643bac-73ca-4b60-a5a1-3356ef3f79d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/mobile/</value>
      <webElementGuid>4649e2a6-6192-4e50-b7e6-20a8ecfd3d14</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-link</value>
      <webElementGuid>0880e094-2824-4f4c-99f2-ae53410cf8c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Learn more</value>
      <webElementGuid>4f1603e8-11d0-4e2a-ab7c-dc7b5548669b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-1e14b0b e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-dcdd3d3 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-335895a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-f7b4523 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-3a19795 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-8be6b20 elementor-widget elementor-widget-ek_elementor_button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[@class=&quot;btn btn-link&quot;]</value>
      <webElementGuid>15612bd7-5a51-4045-9ca7-803b6101795c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Learn more')])[3]</value>
      <webElementGuid>5bda5a19-bb39-4398-ba0d-c7b966d28168</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mobile App'])[2]/following::a[1]</value>
      <webElementGuid>5bc9fdf9-c2ff-49b5-9d01-4fda14ca11ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[2]/following::a[1]</value>
      <webElementGuid>7362cc4f-c64b-405c-8d9c-120f25128150</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Voice Command'])[2]/preceding::a[1]</value>
      <webElementGuid>68a1b3fc-35cf-4c9a-8362-9c2b8a173ca8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[4]/preceding::a[1]</value>
      <webElementGuid>e205c5a6-3f6e-4a76-9b3b-21b3ad0a827d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/mobile/')])[5]</value>
      <webElementGuid>4678b53b-f5a7-4ecc-b609-b5e2bb8499d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div[2]/div[3]/div[3]/div/div/a</value>
      <webElementGuid>3ef2f1a8-5488-4c09-bfdf-9a0a5897258d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/mobile/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>b85cfd48-7aa3-488c-9d38-3a6c1fa0aed0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
