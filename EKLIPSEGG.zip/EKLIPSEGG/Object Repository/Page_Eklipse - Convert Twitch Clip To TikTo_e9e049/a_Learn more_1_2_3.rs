<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Learn more_1_2_3</name>
   <tag></tag>
   <elementGuidId>4b2a3ede-8edf-460c-91ae-13756b375a7f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-3990db9.elementor-widget.elementor-widget-ek_elementor_button > div.elementor-widget-container > a.btn.btn-link</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Learn more')])[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b8fffa22-a67a-49d8-865f-2c0f1d46a96e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/voice-command/</value>
      <webElementGuid>413aa745-cdc3-4ade-bc28-a182861514f3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-link</value>
      <webElementGuid>8bb3b159-fd66-4aee-891e-f0c3cd354501</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Learn more</value>
      <webElementGuid>3b240f36-e67e-4587-9fd6-a5071270082b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-1e14b0b e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-dcdd3d3 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-335895a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-d8045ab e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-2c41008 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-3990db9 elementor-widget elementor-widget-ek_elementor_button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[@class=&quot;btn btn-link&quot;]</value>
      <webElementGuid>2eff2773-a1f9-48c5-afaf-93312621c41b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Learn more')])[4]</value>
      <webElementGuid>7c310c62-ed2c-40c9-86ea-592a5981793e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Voice Command'])[2]/following::a[1]</value>
      <webElementGuid>7607eab1-8541-4011-9656-70cd17d31104</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[3]/following::a[1]</value>
      <webElementGuid>87456b18-1d8f-4aa0-b3d8-63a337136b58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Affiliates'])[1]/preceding::a[1]</value>
      <webElementGuid>d18b6e34-731f-4bc7-9962-e9dd696a5f79</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trusted by hundreds of thousands of streamers worldwide'])[1]/preceding::a[2]</value>
      <webElementGuid>bc713448-d86a-4f5f-b528-1f4d9e5da861</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/voice-command/')])[3]</value>
      <webElementGuid>e89efca2-a112-4f8c-8471-8e427c72f8f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div[3]/div/div/a</value>
      <webElementGuid>e052c610-9374-45c1-9689-b6d3d4002a3f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/voice-command/' and (text() = 'Learn more' or . = 'Learn more')]</value>
      <webElementGuid>aa104e93-5504-459d-9ab7-cb68a0f58d1c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
