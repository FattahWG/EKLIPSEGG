<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign In</name>
   <tag></tag>
   <elementGuidId>35422e5b-5102-4b03-8bd7-16592e00c2cc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.header-main__col.header-main__col--right > a.btn.btn-login</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Sign In')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b89e6e88-1772-4751-a396-e1f42f1ef625</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*6yjrto*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw</value>
      <webElementGuid>86fc114c-c3e7-45e8-8190-646338e610d3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-login</value>
      <webElementGuid>88df9c03-cb49-446f-a567-273a978971b2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						Sign In
					</value>
      <webElementGuid>87f02b8e-2b9f-44d2-9d3a-e9376e28e06d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--right&quot;]/a[@class=&quot;btn btn-login&quot;]</value>
      <webElementGuid>db6542bc-4391-446d-974a-a05c219bc723</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Sign In')])[2]</value>
      <webElementGuid>4e9d5590-e34b-4fa6-afac-6236918c0b5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[1]/following::a[1]</value>
      <webElementGuid>653a62ac-56e2-4584-badc-163e466bb63a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/following::a[2]</value>
      <webElementGuid>3b0f3e40-3539-412b-9ca7-e4ed60302cd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/preceding::a[1]</value>
      <webElementGuid>6abcf861-a1a6-4a3f-bec9-4ce2ac6acf85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='#1 AI for Streamers &amp; Creators—Automate Content'])[1]/preceding::a[4]</value>
      <webElementGuid>88d696b9-b57a-434f-97b5-5239573d852c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*6yjrto*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw')]</value>
      <webElementGuid>d5a6f0b7-ec3d-497c-9304-61f2ddf32ce7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a</value>
      <webElementGuid>90fed99e-d492-4503-b901-cf854af0c7cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*6yjrto*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAyODckajQ5JGwwJGgw' and (text() = '
						Sign In
					' or . = '
						Sign In
					')]</value>
      <webElementGuid>09e625ee-8b4f-4e05-93f6-8a3b3228727e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
