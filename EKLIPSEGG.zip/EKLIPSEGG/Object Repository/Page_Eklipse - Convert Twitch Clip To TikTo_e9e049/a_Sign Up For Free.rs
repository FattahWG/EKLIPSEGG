<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign Up For Free</name>
   <tag></tag>
   <elementGuidId>03d76720-299d-4b2c-bd39-0fa7cd774595</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.header-main__col.header-main__col--right > a.btn.btn-register</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Sign Up For Free')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>3f8b59cf-7465-4c1f-8833-f444d47a12a9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*bqi3qp*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAzMjkkajckbDAkaDA.*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAzMzAkajYkbDAkaDA.</value>
      <webElementGuid>4dccdda8-cfcc-400e-ac9d-99e976b42715</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-register</value>
      <webElementGuid>5852fca6-3091-430e-a68b-b7d06359ee53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-page</name>
      <type>Main</type>
      <value>https://eklipse.gg</value>
      <webElementGuid>a4f06952-6c04-4858-9e51-665cf09d0abd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						Sign Up For Free
					</value>
      <webElementGuid>c2e84cc6-8c97-4ebd-bd20-0677b07aec65</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--right&quot;]/a[@class=&quot;btn btn-register&quot;]</value>
      <webElementGuid>7cd04970-4a9a-4ace-a2e7-b13670ca7a61</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Sign Up For Free')])[2]</value>
      <webElementGuid>b41df875-de93-41bc-b0b9-f000e74fc62e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::a[1]</value>
      <webElementGuid>9c9a139e-8721-4662-a514-19612080dfd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[1]/following::a[2]</value>
      <webElementGuid>96b20b62-082f-4070-8c66-628aa4244247</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='#1 AI for Streamers &amp; Creators—Automate Content'])[1]/preceding::a[3]</value>
      <webElementGuid>8d40ef73-a00e-400c-b03b-7d23f7f2e627</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Elevate Your'])[1]/preceding::a[4]</value>
      <webElementGuid>a33e747e-cb67-47c1-bfff-1114a3eb4637</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*bqi3qp*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAzMjkkajckbDAkaDA.*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAzMzAkajYkbDAkaDA.')]</value>
      <webElementGuid>7a73e064-3397-4d46-a082-991abc566a9d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a[2]</value>
      <webElementGuid>abef28c3-038c-4cc6-ba36-e563c008f82b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://app.eklipse.gg/register?from=https%3A%2F%2Feklipse.gg&amp;_gl=1*bqi3qp*_gcl_au*MTY5MDI4OTQyMy4xNzUxMTkwMTkz*_ga*NzczMzQxNzE0LjE3NTExOTAxOTE.*_ga_GLD7CWERS9*czE3NTExOTAxOTIkbzEkZzEkdDE3NTExOTAzMjkkajckbDAkaDA.*_ga_WQX826KJ2T*czE3NTExOTAxOTYkbzEkZzEkdDE3NTExOTAzMzAkajYkbDAkaDA.' and (text() = '
						Sign Up For Free
					' or . = '
						Sign Up For Free
					')]</value>
      <webElementGuid>338a8be9-dcc4-42c1-aeec-dc466c458d18</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
