<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Studio</name>
   <tag></tag>
   <elementGuidId>f5f13a2b-30d4-408a-b4c1-dcca03f1097d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-495794c3.elementor-button-info.elementor-align-left.elementor-tablet_extra-align-center.elementor-widescreen-align-center.elementor-widget.elementor-widget-button > div.elementor-widget-container > div.elementor-button-wrapper > a.elementor-button.elementor-button-link.elementor-size-xs</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[5]/following::a[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>56109b10-cdf1-4808-bb12-5153ac3f998c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-button-link elementor-size-xs</value>
      <webElementGuid>f9434e4f-b4ff-45a4-937c-922c22cd238f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#</value>
      <webElementGuid>c3ee773a-15b6-4f96-b197-789e48e314ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
									Studio
					
					</value>
      <webElementGuid>77f22128-5093-4f64-a24b-0e046f40dbe8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-3ca251b2 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-2aedde13 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-495794c3 elementor-button-info elementor-align-left elementor-tablet_extra-align-center elementor-widescreen-align-center elementor-widget elementor-widget-button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/div[@class=&quot;elementor-button-wrapper&quot;]/a[@class=&quot;elementor-button elementor-button-link elementor-size-xs&quot;]</value>
      <webElementGuid>9390958a-3c0c-478d-bf55-7159c5330822</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learn more'])[5]/following::a[1]</value>
      <webElementGuid>ee95ef69-4ca2-4001-8f12-2c57b5e05f11</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='more!'])[1]/following::a[2]</value>
      <webElementGuid>4aec214e-d299-49c5-8746-299d90287a5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Directly on Eklipse'])[1]/preceding::a[1]</value>
      <webElementGuid>3e453c57-425e-4094-928f-9152733ed744</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '#')])[6]</value>
      <webElementGuid>ab0d881d-7e83-4c6b-8a12-95081e16ebd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/a</value>
      <webElementGuid>3d866018-5957-4d5b-a1c8-7b2b50a19fe8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#' and (text() = '
						
									Studio
					
					' or . = '
						
									Studio
					
					')]</value>
      <webElementGuid>9e5635e1-c7a5-4c21-8d1b-311e49d891ee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
