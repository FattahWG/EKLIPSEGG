<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Black Ops 6 NEW</name>
   <tag></tag>
   <elementGuidId>0c3b6bdd-f699-4f09-903b-720d98c1ea40</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-1730451.elementor-widget-mobile__width-initial.eael-infobox-shape-radius.eael-infobox-hover-img-shape-radius.elementor-widget.elementor-widget-eael-info-box > div.elementor-widget-container</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3ffffc9e-7987-4f07-871b-96384d1f759b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-widget-container</value>
      <webElementGuid>dbd3eac7-1741-4185-a76b-7dba7351e501</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				</value>
      <webElementGuid>c7d34491-f650-4848-a8ed-341b9c744e72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[@class=&quot;megamenu&quot;]/div[@class=&quot;elementor elementor-11943&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-flex e-con-boxed e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;e-con-inner&quot;]/div[@class=&quot;elementor-element elementor-element-0f961dc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-cf5443b e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-b435716 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1730451 elementor-widget-mobile__width-initial eael-infobox-shape-radius eael-infobox-hover-img-shape-radius elementor-widget elementor-widget-eael-info-box&quot;]/div[@class=&quot;elementor-widget-container&quot;]</value>
      <webElementGuid>4a715eca-1304-417e-b468-df74906c1ef0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Case'])[1]/following::div[8]</value>
      <webElementGuid>43d2ed88-4b09-4a69-b0e9-ff459ec5d0e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kick Support'])[1]/following::div[8]</value>
      <webElementGuid>efb18900-6112-4f95-be9e-8a37a884e26c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/ul/li/div/div/div/div/div/div/div/div</value>
      <webElementGuid>f17443d9-e36f-4125-aa4c-bbbbebd85be3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				' or . = '
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				')]</value>
      <webElementGuid>a33b2ec7-0bd3-44b2-bb06-24dff245c291</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
