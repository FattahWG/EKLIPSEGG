<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Black Ops 6 NEW_1</name>
   <tag></tag>
   <elementGuidId>125cb7dc-8bb9-4f2e-8eb7-472ed8ed316c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.eael-infobox.icon-on-left</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Case'])[1]/following::div[9]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>012224f0-f69d-4379-971b-fbfa039ecb72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-infobox icon-on-left</value>
      <webElementGuid>ef4d3984-84eb-49f4-9d9f-175f19f18bfb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            </value>
      <webElementGuid>3d137cff-59cf-4108-8f0f-fa40e480cf50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[@class=&quot;megamenu&quot;]/div[@class=&quot;elementor elementor-11943&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-flex e-con-boxed e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;e-con-inner&quot;]/div[@class=&quot;elementor-element elementor-element-0f961dc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-cf5443b e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-b435716 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-1730451 elementor-widget-mobile__width-initial eael-infobox-shape-radius eael-infobox-hover-img-shape-radius elementor-widget elementor-widget-eael-info-box&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[1]/div[@class=&quot;eael-infobox icon-on-left&quot;]</value>
      <webElementGuid>1acd802c-664c-4972-950c-c87cbe4b1a8d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Case'])[1]/following::div[9]</value>
      <webElementGuid>fb050928-8c9d-494d-9a61-9fc2744a9f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kick Support'])[1]/following::div[9]</value>
      <webElementGuid>883d7099-ebc3-4096-aeed-fe27ce9690cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div</value>
      <webElementGuid>803c3d7e-3f64-4086-97b4-a2792b9c2058</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            ' or . = '
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            ')]</value>
      <webElementGuid>deecb0f5-74ab-4fdb-90a2-528a2c635fc7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
