<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FeaturesAuto CaptionCreate vibrant capt_fe8a1b</name>
   <tag></tag>
   <elementGuidId>0dcd0cee-b9e8-487b-b1dc-fea6a29a4889</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-abfbfa3.e-con-full.e-flex.e-con.e-child</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Templates'])[1]/following::div[6]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>dfb36196-c042-4330-bfbc-6282b85f211c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-abfbfa3 e-con-full e-flex e-con e-child</value>
      <webElementGuid>6257336b-ab18-494a-b5da-331bb4409f24</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>abfbfa3</value>
      <webElementGuid>fabcbfa7-9984-4c25-9ae0-fd134dafd0fe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>6aaa2b40-ac77-4f9b-a820-45086710f7bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Auto Caption					
				
			
			
		
				
				
				
				
							Create vibrant captions with animations and custom fonts						
				
				
				
																										
				
				</value>
      <webElementGuid>04be6357-f113-486f-ad4f-0858ab3a7103</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-3ca251b2 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-4147794a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-abfbfa3 e-con-full e-flex e-con e-child&quot;]</value>
      <webElementGuid>41be8050-c0b7-4af1-a91d-5082a6d25ff0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Templates'])[1]/following::div[6]</value>
      <webElementGuid>e96021eb-52d4-43d4-8f0d-48712777c009</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features'])[4]/following::div[6]</value>
      <webElementGuid>bb4ef490-5622-4541-ae10-ae7ad9f7ed50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[3]/div</value>
      <webElementGuid>b5456c35-ea07-486b-a1ab-645d69c8d025</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Auto Caption					
				
			
			
		
				
				
				
				
							Create vibrant captions with animations and custom fonts						
				
				
				
																										
				
				' or . = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Auto Caption					
				
			
			
		
				
				
				
				
							Create vibrant captions with animations and custom fonts						
				
				
				
																										
				
				')]</value>
      <webElementGuid>2f5c2df0-1dfa-4d80-a68f-4c547a324800</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
