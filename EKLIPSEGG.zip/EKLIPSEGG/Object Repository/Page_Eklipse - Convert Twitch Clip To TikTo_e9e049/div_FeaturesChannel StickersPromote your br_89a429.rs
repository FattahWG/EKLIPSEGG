<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FeaturesChannel StickersPromote your br_89a429</name>
   <tag></tag>
   <elementGuidId>735a9041-1ca0-45cd-84a2-a89cac72a585</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-65cb9e9d.e-con-full.e-flex.e-con.e-child</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto'])[1]/following::div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e4736c26-3882-411c-8510-062f4a1025cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-65cb9e9d e-con-full e-flex e-con e-child</value>
      <webElementGuid>075b3004-ce34-4b93-a9a4-fd40f2fe0c49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>65cb9e9d</value>
      <webElementGuid>4e8cc3b9-7e4d-4857-81c4-80366c3b1afb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>b7d7ca79-e77a-49d1-82e4-00fed4add219</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Channel Stickers					
				
			
			
		
				
				
				
				
							Promote your brand with channel name stickers						
				
				
				
																										
				
				</value>
      <webElementGuid>244cd128-b2d3-4190-b83d-8d8dd7576088</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-3ca251b2 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-4147794a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-65cb9e9d e-con-full e-flex e-con e-child&quot;]</value>
      <webElementGuid>4c61c972-04fb-4aa1-88a8-b56f57e569bd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto'])[1]/following::div[5]</value>
      <webElementGuid>98961a18-0323-46cf-983a-de504d5db659</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features'])[5]/following::div[5]</value>
      <webElementGuid>8b2b5576-b764-4764-abcb-b8f57b961de0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[3]/div[2]</value>
      <webElementGuid>464a4253-02b4-4157-9eb5-06708795503d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Channel Stickers					
				
			
			
		
				
				
				
				
							Promote your brand with channel name stickers						
				
				
				
																										
				
				' or . = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Channel Stickers					
				
			
			
		
				
				
				
				
							Promote your brand with channel name stickers						
				
				
				
																										
				
				')]</value>
      <webElementGuid>6e5d6d82-c198-406c-98cb-487788f8a71f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
