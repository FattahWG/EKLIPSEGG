<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FeaturesConvert to TikTokEasily convert_78dfa9</name>
   <tag></tag>
   <elementGuidId>33feb420-7316-462e-8071-1f77f74248f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-548a7665.e-con-full.e-flex.e-con.e-child</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Directly on Eklipse'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>75d69140-0bb9-4635-8c46-4f5950f3c02e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-548a7665 e-con-full e-flex e-con e-child</value>
      <webElementGuid>f30377f2-5d06-4ad8-89bc-1b81b9139d53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>548a7665</value>
      <webElementGuid>1433fb02-7d57-4c9f-805a-efc88cca51a6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>5dc18e1c-12ea-48ad-a415-05965ddcf45c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Convert to TikTok					
				
			
			
		
				
				
				
				
							Easily convert clips into vertical format using templates						
				
				
				
																										
				
				</value>
      <webElementGuid>aa4f9546-86a1-4e87-8873-c9b7f7564e7c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-3ca251b2 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-1e52b89b e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-548a7665 e-con-full e-flex e-con e-child&quot;]</value>
      <webElementGuid>5144529a-dfbb-478c-a361-e29da0bc3a85</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit Directly on Eklipse'])[1]/following::div[2]</value>
      <webElementGuid>72f8750a-5a7d-4ea4-9295-05a660531c9a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Studio'])[1]/following::div[4]</value>
      <webElementGuid>e5bd0411-1acd-4279-ae65-7a264dbbda93</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[2]/div</value>
      <webElementGuid>b3c10a33-33d9-4c71-afe4-e4c37745ebb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Convert to TikTok					
				
			
			
		
				
				
				
				
							Easily convert clips into vertical format using templates						
				
				
				
																										
				
				' or . = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Convert to TikTok					
				
			
			
		
				
				
				
				
							Easily convert clips into vertical format using templates						
				
				
				
																										
				
				')]</value>
      <webElementGuid>30921731-12ff-451b-a833-3b55f7777494</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
