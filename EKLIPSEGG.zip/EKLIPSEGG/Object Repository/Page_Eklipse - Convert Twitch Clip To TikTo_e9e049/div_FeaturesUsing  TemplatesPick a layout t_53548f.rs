<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FeaturesUsing  TemplatesPick a layout t_53548f</name>
   <tag></tag>
   <elementGuidId>cd651250-be1e-4d07-9191-39770eb79c9a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-4c0d71e8.e-con-full.e-flex.e-con.e-child</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Convert'])[1]/following::div[5]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>daea70bf-c015-4ca8-8566-9ea6619e56f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-element elementor-element-4c0d71e8 e-con-full e-flex e-con e-child</value>
      <webElementGuid>6207d42d-77e4-4b2f-9e44-c7686a7d71c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-id</name>
      <type>Main</type>
      <value>4c0d71e8</value>
      <webElementGuid>45efe332-ecf2-4cd6-a11d-b96420673c06</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-element_type</name>
      <type>Main</type>
      <value>container</value>
      <webElementGuid>afb98ebc-c668-41fd-a1b1-4916909dc6b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Using  Templates					
				
			
			
		
				
				
				
				
							Pick a layout that suits your style to easily reformat your highlights						
				
				
				
																										
				
				</value>
      <webElementGuid>28f3e616-5b06-46b5-b1ef-e0210085d75e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-3ca251b2 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-1e52b89b e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-4c0d71e8 e-con-full e-flex e-con e-child&quot;]</value>
      <webElementGuid>4a1eaa0a-95cb-4148-80bc-68a0d3872171</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Convert'])[1]/following::div[5]</value>
      <webElementGuid>cd9e3bf9-0096-4138-a6c8-9539a44b699d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Features'])[3]/following::div[5]</value>
      <webElementGuid>6ff07d7f-c927-49c0-b337-7b418f6af8ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div[2]/div[2]</value>
      <webElementGuid>1d77ce23-3a33-40a6-b1e5-18060e001fb1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Using  Templates					
				
			
			
		
				
				
				
				
							Pick a layout that suits your style to easily reformat your highlights						
				
				
				
																										
				
				' or . = '
				
				
					

						
				
								
			
			
						

									
						
							Features						
					
				
									
						Using  Templates					
				
			
			
		
				
				
				
				
							Pick a layout that suits your style to easily reformat your highlights						
				
				
				
																										
				
				')]</value>
      <webElementGuid>e201b335-d3c2-4eca-ac2e-851f407c0f45</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
