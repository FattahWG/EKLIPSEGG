<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Can I share highlights video to social m_4db9cd</name>
   <tag></tag>
   <elementGuidId>65fef356-1edb-4f13-af62-409554730459</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#elementor-tab-title-1156</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h2[@id='elementor-tab-title-1156']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>b5d767cb-17f3-41c8-ad8a-527a8ae31286</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>elementor-tab-title-1156</value>
      <webElementGuid>d9347f00-0eaf-4240-b853-6d870445e8d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-tab-title</value>
      <webElementGuid>7dbe8cd8-25c8-49fb-972b-6a63d8465034</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>6</value>
      <webElementGuid>e3917817-1298-4280-8e57-b923e7a9f670</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>e73969db-4196-4c25-b25c-f0005a4da42c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>elementor-tab-content-1156</value>
      <webElementGuid>cc22f86e-9504-4fd5-9680-b9260e295807</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>b412ca3b-0110-4fb4-ab1b-187395404ca8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
													
															
								
														
												Can I share highlights video to social media platforms?
					</value>
      <webElementGuid>980fb861-a546-4548-b06a-84593a2b9ec7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;elementor-tab-title-1156&quot;)</value>
      <webElementGuid>340005c3-26b1-4d65-971d-c608acdd249f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//h2[@id='elementor-tab-title-1156']</value>
      <webElementGuid>70d59280-2b0c-4fa7-aa23-d3690fa92109</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='You can check your clipped streams by going to the “Processed” tab in the Clips > Streams menu.'])[1]/following::h2[1]</value>
      <webElementGuid>62d5d2c6-c207-4074-856e-2fa41c2c871c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Click the “Get Clip” button to begin automatically clipping your stream using Eklipse AI.'])[1]/following::h2[1]</value>
      <webElementGuid>c74480fe-030a-4376-90af-02e2d450b595</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='What are the benefits of Eklipse.gg?'])[1]/preceding::h2[1]</value>
      <webElementGuid>0e2976f9-c895-4bd3-bab9-404970a18740</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[6]/h2</value>
      <webElementGuid>a950382e-d9c7-49a2-a1a8-eb05dad67611</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[@id = 'elementor-tab-title-1156' and (text() = '
													
															
								
														
												Can I share highlights video to social media platforms?
					' or . = '
													
															
								
														
												Can I share highlights video to social media platforms?
					')]</value>
      <webElementGuid>2b24aea8-6b1a-4c5d-ab70-2ecf42839aa6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
