<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_How To Clip Your Twitch  YouTube   Faceb_65e166</name>
   <tag></tag>
   <elementGuidId>3770f1f4-7a00-487b-99c1-4a8b69a8c9d4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#elementor-tab-title-1153</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h2[@id='elementor-tab-title-1153']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>d8ac5753-ee22-4a8e-94d7-a9de2feff24a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>elementor-tab-title-1153</value>
      <webElementGuid>7a9dd17e-e68b-4690-b673-ec01e1499aec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-tab-title</value>
      <webElementGuid>866fd656-a9e9-4a68-9860-eb71138c8f66</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>3</value>
      <webElementGuid>b9605998-a221-4d15-8476-7350e74b2d70</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ae8385ec-79a6-4686-9da7-ad9f60e226e0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>elementor-tab-content-1153</value>
      <webElementGuid>088ba53b-a9cf-4532-a244-6c3796da8a0f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>8a6587a5-1875-41b7-b8b5-13c23fc58f16</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
													
															
								
														
												How To Clip Your Twitch / YouTube /  Facebook Gaming Stream Automatically with AI Using Eklipse
					</value>
      <webElementGuid>5f4f291d-0f4c-453c-9df5-561c5cd0cbd2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;elementor-tab-title-1153&quot;)</value>
      <webElementGuid>6dfd2f27-21f3-4a98-8a88-3384631bf27e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//h2[@id='elementor-tab-title-1153']</value>
      <webElementGuid>dea196d3-d81f-4294-a70e-dc83b3a91e7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try Our FREE Product NOW!'])[1]/following::h2[1]</value>
      <webElementGuid>0474889d-da90-413f-ae15-c1e8bf30dba4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='transform lengthy videos into short viral moments. With YouTube IRL Video Highlights'])[1]/following::h2[1]</value>
      <webElementGuid>f893c935-7de8-434e-b95e-97269dfcb6d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign up and create your Eklipse account.'])[1]/preceding::h2[1]</value>
      <webElementGuid>800ffd0e-86cd-47e7-94c4-6ea3682691cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/h2</value>
      <webElementGuid>d3c059b3-487e-4c20-ae2a-3dd19a2a6862</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[@id = 'elementor-tab-title-1153' and (text() = '
													
															
								
														
												How To Clip Your Twitch / YouTube /  Facebook Gaming Stream Automatically with AI Using Eklipse
					' or . = '
													
															
								
														
												How To Clip Your Twitch / YouTube /  Facebook Gaming Stream Automatically with AI Using Eklipse
					')]</value>
      <webElementGuid>ee0a7a42-4e3e-4879-a5bb-3312281df319</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
