<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_What can I do with Eklipse</name>
   <tag></tag>
   <elementGuidId>5c1029cf-1d7f-4146-bbfe-750d5585f93a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#elementor-tab-title-1152</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//h2[@id='elementor-tab-title-1152']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>fdc1ff34-6832-4ead-a4a4-7e2b6ceb8e33</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>elementor-tab-title-1152</value>
      <webElementGuid>dc390f7e-28ed-45ab-8c37-a1b552391d86</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-tab-title</value>
      <webElementGuid>c8f39e5d-1ad2-4d2e-a43f-5155f60f9315</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>2</value>
      <webElementGuid>1095ffbb-232f-4c77-9533-e043c32d1910</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>928ab97c-fb9c-435d-a63c-4e56bc701936</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>elementor-tab-content-1152</value>
      <webElementGuid>b8e3e934-9bfc-4ae7-a0de-43c556f00c8c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>83bad418-b5ab-4ae1-b82a-d792081f6bb4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
													
															
								
														
												What can I do with Eklipse?
					</value>
      <webElementGuid>bd24d445-09a8-4844-b61c-05d77b132cbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;elementor-tab-title-1152&quot;)</value>
      <webElementGuid>76d0eea2-e9be-491e-81ae-42c194a89250</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//h2[@id='elementor-tab-title-1152']</value>
      <webElementGuid>a980d9b6-38eb-4b30-84cc-8343a7449bb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='What is Eklipse?'])[2]/following::h2[1]</value>
      <webElementGuid>6e569868-5780-4703-8ea8-68fa6dca51af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Got More Questions'])[1]/following::h2[2]</value>
      <webElementGuid>5d598f2c-41d9-4b8c-9049-b19789f5063f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='transform lengthy videos into short viral moments. With YouTube IRL Video Highlights'])[1]/preceding::h2[1]</value>
      <webElementGuid>48169376-4a30-4f30-b81f-734fc68c2e48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/h2</value>
      <webElementGuid>b5144154-6190-43b7-ba41-3418e161ff70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[@id = 'elementor-tab-title-1152' and (text() = '
													
															
								
														
												What can I do with Eklipse?
					' or . = '
													
															
								
														
												What can I do with Eklipse?
					')]</value>
      <webElementGuid>abfe5396-2215-41f2-a446-bc44cbbfbe8a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
