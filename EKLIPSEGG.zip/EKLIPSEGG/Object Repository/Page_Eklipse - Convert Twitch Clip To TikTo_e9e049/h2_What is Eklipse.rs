<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_What is Eklipse</name>
   <tag></tag>
   <elementGuidId>a3e776c7-7c9f-4b03-8854-b90c51d9d83f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#elementor-tab-title-1151</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>6fd00c52-f4e3-4efe-812b-9cb7be5424d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>elementor-tab-title-1151</value>
      <webElementGuid>2b7f3c9a-52c8-4e30-b9e0-a6416a3340f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-tab-title elementor-active</value>
      <webElementGuid>b1a6e311-2c97-486e-b420-ad1f9b2145f8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>1</value>
      <webElementGuid>32212638-6042-45d9-82af-107475a0f1e1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>ca6fe779-8ef3-44af-9b4e-bdd811907409</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>elementor-tab-content-1151</value>
      <webElementGuid>cdc508ba-b519-4fbe-bce7-f4dd6d3428eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>ac8a2375-4ee5-4ffa-bcf1-3d5c20f1d37b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>491ab3c1-1b78-49d0-9606-5d3212b380ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-selected</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>03ebcc35-64be-4045-8264-00f92f2bf4bb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
													
															
								
														
												What is Eklipse?
					</value>
      <webElementGuid>0ba19692-ab9d-44b5-9230-814d43e46215</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;elementor-tab-title-1151&quot;)</value>
      <webElementGuid>dfabfefd-2076-471c-8fc9-300e23baa1be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//h2[@id='elementor-tab-title-1151']</value>
      <webElementGuid>94e10ecb-e338-4d09-b2a9-670b71b9d45b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Got More Questions'])[1]/following::h2[1]</value>
      <webElementGuid>1e375566-c70a-4859-9196-5945f5100a33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Affiliates'])[3]/following::h2[2]</value>
      <webElementGuid>81cb490d-c41d-4c19-8b47-958ef66094ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='What can I do with Eklipse?'])[1]/preceding::h2[1]</value>
      <webElementGuid>a2287b42-4b06-440f-b6af-bcb0e75832e2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/h2</value>
      <webElementGuid>5381ed5a-9bd7-4d72-b845-95235de9d344</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[@id = 'elementor-tab-title-1151' and (text() = '
													
															
								
														
												What is Eklipse?
					' or . = '
													
															
								
														
												What is Eklipse?
					')]</value>
      <webElementGuid>2787fd86-1bfe-47c9-b530-aa3ac08ef350</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
