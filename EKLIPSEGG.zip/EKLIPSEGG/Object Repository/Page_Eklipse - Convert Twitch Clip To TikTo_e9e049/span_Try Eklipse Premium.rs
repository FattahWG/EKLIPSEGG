<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Try Eklipse Premium</name>
   <tag></tag>
   <elementGuidId>9b4a2041-169b-429b-8ef2-12e6822e0bde</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-cb3d3d7.elementor-button-info.elementor-align-center.elementor-tablet_extra-align-center.elementor-widescreen-align-center.elementor-laptop-align-center.elementor-widget.elementor-widget-button > div.elementor-widget-container > div.elementor-button-wrapper > a.elementor-button.elementor-button-link.elementor-size-xs > span.elementor-button-content-wrapper > span.elementor-button-text</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='...and so much more'])[1]/following::span[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>6e904686-99ba-4744-92a7-4c3af1860636</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button-text</value>
      <webElementGuid>c2556d6e-227a-4baa-8d93-4b49dcaec3ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Try Eklipse Premium</value>
      <webElementGuid>3e65878f-0869-4eb9-b96b-73049ae0a782</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-344c52d9 e-flex e-con-boxed e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;e-con-inner&quot;]/div[@class=&quot;elementor-element elementor-element-cb3d3d7 elementor-button-info elementor-align-center elementor-tablet_extra-align-center elementor-widescreen-align-center elementor-laptop-align-center elementor-widget elementor-widget-button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/div[@class=&quot;elementor-button-wrapper&quot;]/a[@class=&quot;elementor-button elementor-button-link elementor-size-xs&quot;]/span[@class=&quot;elementor-button-content-wrapper&quot;]/span[@class=&quot;elementor-button-text&quot;]</value>
      <webElementGuid>cdf89ad9-4094-44fc-b2bc-fb533a150c84</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='...and so much more'])[1]/following::span[4]</value>
      <webElementGuid>fad3b59c-8dab-4010-97ea-947ec41f2a8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Affiliates'])[2]/preceding::span[1]</value>
      <webElementGuid>92ee8c72-0a98-4a4f-9a67-52d179e52c89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cpawsmusic'])[1]/preceding::span[3]</value>
      <webElementGuid>c25cfca6-60ee-4e2f-8bfb-3a17cbe4ea6b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Try Eklipse Premium']/parent::*</value>
      <webElementGuid>b4f334c4-7f26-4dd5-bfb2-e3bd76fb4b44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/span/span[2]</value>
      <webElementGuid>3a93f77b-1dc9-4b28-92e9-92e3feef5db7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Try Eklipse Premium' or . = 'Try Eklipse Premium')]</value>
      <webElementGuid>e3a2ee3c-07ad-4088-a670-516af51eac71</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
