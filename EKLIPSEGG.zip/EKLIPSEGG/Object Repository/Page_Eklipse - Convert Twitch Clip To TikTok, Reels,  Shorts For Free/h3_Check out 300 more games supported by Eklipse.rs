<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Check out 300 more games supported by Eklipse</name>
   <tag></tag>
   <elementGuidId>4cb386ec-5008-4f89-987b-d5674255a982</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h3.title</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='NEW!'])[1]/following::h3[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>70ff41ac-9975-40f0-b7bb-02e296e2ff9d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title</value>
      <webElementGuid>89e46251-086c-4fd5-af4c-85874556e2de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Check out 300+ more games supported by Eklipse</value>
      <webElementGuid>85453550-fa93-4f88-869c-dc90ac2a8dd9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header fixed no-fixed&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[@class=&quot;megamenu&quot;]/div[@class=&quot;elementor elementor-11943&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-flex e-con-boxed e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;e-con-inner&quot;]/div[@class=&quot;elementor-element elementor-element-0f961dc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-3bd4380 elementor-widget__width-initial elementor-widget-widescreen__width-inherit elementor-widget elementor-widget-eael-info-box&quot;]/div[@class=&quot;elementor-widget-container&quot;]/a[1]/div[@class=&quot;eael-infobox icon-on-left&quot;]/div[@class=&quot;infobox-content&quot;]/h3[@class=&quot;title&quot;]</value>
      <webElementGuid>87402a90-dbea-4e44-9b50-e0ffae3b49a8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NEW!'])[1]/following::h3[1]</value>
      <webElementGuid>83a88b64-4944-4522-a6a6-7abdca765101</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Use Case'])[1]/following::h3[1]</value>
      <webElementGuid>6b73b258-520a-432c-a916-c255f562efdd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Discovery'])[1]/preceding::h3[1]</value>
      <webElementGuid>05be313e-f5d6-42f4-99d0-64dbc4abc43e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Learning Center'])[1]/preceding::h3[1]</value>
      <webElementGuid>86374c8f-0abc-4293-91f1-37f6093e7fa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Check out']/parent::*</value>
      <webElementGuid>10180925-c766-48f7-a445-7ae38f3eda33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/div/h3</value>
      <webElementGuid>6fbaec5c-f3a7-41c4-a10f-852d51f860ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Check out 300+ more games supported by Eklipse' or . = 'Check out 300+ more games supported by Eklipse')]</value>
      <webElementGuid>17436a41-0e55-44e3-b8e9-707f990e46d6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
