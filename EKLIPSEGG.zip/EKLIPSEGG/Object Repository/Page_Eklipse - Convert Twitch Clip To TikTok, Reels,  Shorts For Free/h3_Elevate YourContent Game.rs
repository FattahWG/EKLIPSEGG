<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Elevate YourContent Game</name>
   <tag></tag>
   <elementGuidId>a274486a-7892-4c98-8580-2f9b404192f5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='#1 AI for Streamers &amp; Creators—Automate Content'])[1]/following::h3[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.elementor-headline.e-animated</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>26d306fe-3c0e-41c9-bd6e-47158d2a2e83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-headline e-animated</value>
      <webElementGuid>1603cd3f-6a15-41ee-bb53-99e2edd896ed</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
					Elevate Your
				
					Content Game
				
				</value>
      <webElementGuid>c3d761da-beb3-48d7-aa17-acc23126bd38</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;home page-template-default page page-id-13271 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-13271 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-13271 elementor-motion-effects-parent&quot;]/div[@class=&quot;elementor-element elementor-element-6e1f56c e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-6e41d55 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-0e57b1e e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-49545bd e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-5f65087 elementor-headline--style-highlight elementor-widget elementor-widget-animated-headline&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h3[@class=&quot;elementor-headline e-animated&quot;]</value>
      <webElementGuid>6bee526f-230b-4399-b306-49f121626de9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='#1 AI for Streamers &amp; Creators—Automate Content'])[1]/following::h3[1]</value>
      <webElementGuid>792f1f12-70fb-4c2e-a048-a39d9db54c78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h3[1]</value>
      <webElementGuid>a5426cb9-d34b-4f63-95d0-48817c049c26</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/h3</value>
      <webElementGuid>afd7b3c9-b5c6-4d6c-b15c-62d252c666f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = '
					Elevate Your
				
					Content Game
				
				' or . = '
					Elevate Your
				
					Content Game
				
				')]</value>
      <webElementGuid>453e0d72-6fd5-42a7-b162-ee166fdabf08</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
