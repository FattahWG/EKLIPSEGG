<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Effortlessly Create Content From Your Xbox and PlayStation Streams - No PC Needed</name>
   <tag></tag>
   <elementGuidId>75461eec-aa29-4e81-b551-5de48621a515</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-29d4a82.elementor-widget.elementor-widget-heading > div.elementor-widget-container > h2.elementor-heading-title.elementor-size-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>5ac62a29-184d-48c4-b3e0-70244fd059c4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>9baedf13-29a7-4dc1-ac36-2cc96f4b25ad</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Effortlessly Create Content From Your Xbox and PlayStation Streams - No PC Needed!</value>
      <webElementGuid>776f21a0-9917-4d85-8c60-5fad0520fcf0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-9411 page-child parent-pageid-1568 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-9411 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-9411&quot;]/div[@class=&quot;elementor-element elementor-element-61ba59b e-con-full bg-radian e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-9e16a29 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-fb15aa9 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-29d4a82 elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h2[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>b303cccf-ee60-4467-8c09-e50daa602eff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::h2[1]</value>
      <webElementGuid>d12c5afe-b402-4f0a-a64a-718ffa8606df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[2]/following::h2[1]</value>
      <webElementGuid>6df96422-110d-4c87-9dfa-4d80cb025539</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Register Now'])[1]/preceding::h2[1]</value>
      <webElementGuid>3237e23c-6b18-4879-91b4-c6c54a4be97e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Compatibility'])[1]/preceding::h2[1]</value>
      <webElementGuid>80f37aa8-98ad-4541-b029-fa75032133bc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Effortlessly Create Content From Your Xbox and PlayStation Streams - No PC Needed!']/parent::*</value>
      <webElementGuid>9491db06-943b-45e3-8185-2758e62020e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div/div/div/div/div/h2</value>
      <webElementGuid>78150b73-4be9-4919-8a27-f43e0420218e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Effortlessly Create Content From Your Xbox and PlayStation Streams - No PC Needed!' or . = 'Effortlessly Create Content From Your Xbox and PlayStation Streams - No PC Needed!')]</value>
      <webElementGuid>b45347c3-824b-41b0-950a-257705ac2fb1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
