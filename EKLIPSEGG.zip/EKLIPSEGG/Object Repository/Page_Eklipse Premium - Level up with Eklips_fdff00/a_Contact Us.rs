<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Contact Us</name>
   <tag></tag>
   <elementGuidId>e0bb165b-80b6-4b07-9258-190e838bd0eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-dab4c4a.elementor-align-center.elementor-widget.elementor-widget-button > div.elementor-widget-container > div.elementor-button-wrapper > a.elementor-button.elementor-button-link.elementor-size-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='monthly-tab']/div/div/div/div[3]/div/div[3]/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>0e4005ee-b193-4df4-9ce9-d4e8a515c0ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-button-link elementor-size-sm</value>
      <webElementGuid>df892f1c-8567-4124-8364-3a564d6c89de</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2MjkzIiwidG9nZ2xlIjpmYWxzZX0%3D</value>
      <webElementGuid>36ae9953-ee1b-4a1c-a887-2da8bb31909d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
									Contact Us
					
					</value>
      <webElementGuid>ae674add-4c80-4f16-ae57-a6cf04108517</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;monthly-tab&quot;)/div[@class=&quot;elementor elementor-16337&quot;]/div[@class=&quot;elementor-element elementor-element-7befa83 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-0e62d80 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-f51fe0a e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-018709c e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-dab4c4a elementor-align-center elementor-widget elementor-widget-button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/div[@class=&quot;elementor-button-wrapper&quot;]/a[@class=&quot;elementor-button elementor-button-link elementor-size-sm&quot;]</value>
      <webElementGuid>bfff3996-f03b-4712-a7c2-7841a6f40a2e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='monthly-tab']/div/div/div/div[3]/div/div[3]/div/div/a</value>
      <webElementGuid>64e59877-4e65-4f4f-908e-7536002c704f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dedicated 24/7 support and services'])[1]/following::a[1]</value>
      <webElementGuid>f5e89d73-0afa-4f18-b844-8572988bd051</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Advanced, centralized team management'])[1]/following::a[1]</value>
      <webElementGuid>81c51719-2f98-47be-bdd7-fb77cab8c7d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free Plan'])[2]/preceding::a[1]</value>
      <webElementGuid>a470fca4-ed78-406e-bc92-51cef39c603b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2MjkzIiwidG9nZ2xlIjpmYWxzZX0%3D')]</value>
      <webElementGuid>206bea66-7ed4-49ee-a43f-41754bcd2b80</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[3]/div/div[3]/div/div/a</value>
      <webElementGuid>a7f8bd6d-0688-4896-a45a-2b3383489286</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#elementor-action%3Aaction%3Dpopup%3Aopen%26settings%3DeyJpZCI6IjE2MjkzIiwidG9nZ2xlIjpmYWxzZX0%3D' and (text() = '
						
									Contact Us
					
					' or . = '
						
									Contact Us
					
					')]</value>
      <webElementGuid>26659155-683b-4051-a350-63055652b555</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
