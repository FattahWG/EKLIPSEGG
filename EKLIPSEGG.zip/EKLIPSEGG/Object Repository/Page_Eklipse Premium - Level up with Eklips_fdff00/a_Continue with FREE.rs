<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Continue with FREE</name>
   <tag></tag>
   <elementGuidId>b787c569-5115-48db-b42a-3115427e5f96</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-efc7af4.elementor-align-center.elementor-widget.elementor-widget-button > div.elementor-widget-container > div.elementor-button-wrapper > a.elementor-button.elementor-button-link.elementor-size-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='monthly-tab']/div/div/div/div/div/div[3]/div/div/a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>274e4d61-993f-4af3-9c42-d67cfaa7d2b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-button-link elementor-size-sm</value>
      <webElementGuid>7d50b6f5-94c5-449c-bd17-b3efb14c743e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://app.eklipse.gg/register?utm_id=FreeCard&amp;from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*rom51q*_gcl_au*Mjk5NTkyMzQwLjE3NTEyMTI5NTk.*_ga*Nzg2NDc4NjAxLjE3NTEyMTI5NTk.*_ga_GLD7CWERS9*czE3NTEyMTI5NTkkbzEkZzEkdDE3NTEyMTMwMTQkajUkbDAkaDA.*_ga_WQX826KJ2T*czE3NTEyMTI5NjIkbzEkZzEkdDE3NTEyMTMwMTQkajgkbDAkaDA.</value>
      <webElementGuid>a80c34bd-40bf-4e3c-b6a9-4434445c0d11</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
									Continue with FREE
					
					</value>
      <webElementGuid>78c6139c-9458-4206-9a3f-8e0ce0ffbc52</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;monthly-tab&quot;)/div[@class=&quot;elementor elementor-16337&quot;]/div[@class=&quot;elementor-element elementor-element-7befa83 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-0e62d80 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-a5e3d80 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-248b2bc e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-efc7af4 elementor-align-center elementor-widget elementor-widget-button&quot;]/div[@class=&quot;elementor-widget-container&quot;]/div[@class=&quot;elementor-button-wrapper&quot;]/a[@class=&quot;elementor-button elementor-button-link elementor-size-sm&quot;]</value>
      <webElementGuid>6d4162f1-9158-4ee6-8d10-71c23ddf7eca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='monthly-tab']/div/div/div/div/div/div[3]/div/div/a</value>
      <webElementGuid>77704108-465f-44f9-8025-e1600fd6d6af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto-process your streams for 14 days'])[1]/following::a[1]</value>
      <webElementGuid>0a7e26b1-ed94-47ed-8ef2-388c12c237ea</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Highlight up to 15 clips from your stream*'])[1]/following::a[1]</value>
      <webElementGuid>6443d7e3-ebbb-4fa8-afec-f920e28ce7b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Premium Plan'])[1]/preceding::a[1]</value>
      <webElementGuid>2196b790-b27c-4ba7-9289-ff64b256cedf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://app.eklipse.gg/register?utm_id=FreeCard&amp;from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*rom51q*_gcl_au*Mjk5NTkyMzQwLjE3NTEyMTI5NTk.*_ga*Nzg2NDc4NjAxLjE3NTEyMTI5NTk.*_ga_GLD7CWERS9*czE3NTEyMTI5NTkkbzEkZzEkdDE3NTEyMTMwMTQkajUkbDAkaDA.*_ga_WQX826KJ2T*czE3NTEyMTI5NjIkbzEkZzEkdDE3NTEyMTMwMTQkajgkbDAkaDA.')]</value>
      <webElementGuid>01a4b8e6-7a0d-449d-bb14-2d719c296cec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div[3]/div/div/a</value>
      <webElementGuid>fc527411-138c-47fc-8fb8-3475f03acf85</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://app.eklipse.gg/register?utm_id=FreeCard&amp;from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*rom51q*_gcl_au*Mjk5NTkyMzQwLjE3NTEyMTI5NTk.*_ga*Nzg2NDc4NjAxLjE3NTEyMTI5NTk.*_ga_GLD7CWERS9*czE3NTEyMTI5NTkkbzEkZzEkdDE3NTEyMTMwMTQkajUkbDAkaDA.*_ga_WQX826KJ2T*czE3NTEyMTI5NjIkbzEkZzEkdDE3NTEyMTMwMTQkajgkbDAkaDA.' and (text() = '
						
									Continue with FREE
					
					' or . = '
						
									Continue with FREE
					
					')]</value>
      <webElementGuid>bf1dcb86-28bd-4e04-ad72-1e457c40fe52</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
