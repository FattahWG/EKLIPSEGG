<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Learn More</name>
   <tag></tag>
   <elementGuidId>981adc97-a34b-414f-af82-076d8a77b9c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#section1</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='section1']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>495b5ce4-9a25-4ab4-a83f-0f9c72a3ecc0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-button-link elementor-size-md</value>
      <webElementGuid>fec61988-8793-4c87-8e60-29e22b854d68</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/use-case/monster-hunter/</value>
      <webElementGuid>11a43eec-9baf-47b8-b5c9-8ab6d85025c2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>section1</value>
      <webElementGuid>b87ce76b-d19b-4b4f-9273-6afbdd4a1ad6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
									Learn More
					
					</value>
      <webElementGuid>56598d5b-d0cf-401b-a576-75e987facc21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;section1&quot;)</value>
      <webElementGuid>8fa4dadc-a1d7-4e0e-a52c-d0a6b1c153b9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='section1']</value>
      <webElementGuid>5da547c3-5c76-4cd4-9a4b-3973f00c507b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Monster Hunter Wilds'])[1]/following::a[1]</value>
      <webElementGuid>e79b0e34-b5c7-44dd-bcb8-bf58e453e343</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A Hunter Must Hunt, A Gamer Must Clip'])[1]/following::a[1]</value>
      <webElementGuid>9eaf520f-0364-45fa-b7ea-c9a98edc3588</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Supported Games'])[1]/preceding::a[1]</value>
      <webElementGuid>d9ea8db1-84b0-4e9c-a590-a0872fc2f764</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/use-case/monster-hunter/')])[2]</value>
      <webElementGuid>95147912-f974-4766-812b-2408971880da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div[3]/div/div/a</value>
      <webElementGuid>b5181b0d-dd81-44b8-972a-d7288dfe4f1d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/use-case/monster-hunter/' and @id = 'section1' and (text() = '
						
									Learn More
					
					' or . = '
						
									Learn More
					
					')]</value>
      <webElementGuid>1b0d5956-a270-40c4-b219-fd95acb9e0c3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
