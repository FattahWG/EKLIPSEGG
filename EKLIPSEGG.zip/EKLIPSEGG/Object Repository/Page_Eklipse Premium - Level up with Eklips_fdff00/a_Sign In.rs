<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Sign In</name>
   <tag></tag>
   <elementGuidId>eed56977-0288-4bb5-8168-cab18bebe4eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.header-main__col.header-main__col--right > a.btn.btn-login</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(text(),'Sign In')])[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>9e2f0f07-12d3-4f40-9d3d-856b24f4241c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*1px592m*_gcl_au*MTA5Mzc0Njk4OS4xNzUxMTkxMDA1*_ga*MTY0OTIzNDQ5MS4xNzUxMTkxMDA1*_ga_GLD7CWERS9*czE3NTExOTEwMDUkbzEkZzEkdDE3NTExOTEwNDMkajIyJGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTEwMDgkbzEkZzEkdDE3NTExOTEwNDQkajI0JGwwJGgw</value>
      <webElementGuid>8b77a28e-ed24-4c04-9706-897061aee7da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-login</value>
      <webElementGuid>58480936-b167-4c99-93b6-0710ff6a021a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						Sign In
					</value>
      <webElementGuid>5b166ec0-c2a5-4e2e-9f49-dc59e17c3f7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-1830 page-parent wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-1830 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--right&quot;]/a[@class=&quot;btn btn-login&quot;]</value>
      <webElementGuid>1d28a897-39df-4de2-b1db-34a3ed2fb49e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Sign In')])[2]</value>
      <webElementGuid>5720b53a-fb42-473c-9f60-a8675c0dea6e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[1]/following::a[1]</value>
      <webElementGuid>3b86b6fb-52da-4687-a004-b423e97632f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/following::a[2]</value>
      <webElementGuid>3e0b330e-5415-425d-aabb-10fbf07a43bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/preceding::a[1]</value>
      <webElementGuid>cf89b5cf-c18e-4e2b-9679-b584d6d49b1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*1px592m*_gcl_au*MTA5Mzc0Njk4OS4xNzUxMTkxMDA1*_ga*MTY0OTIzNDQ5MS4xNzUxMTkxMDA1*_ga_GLD7CWERS9*czE3NTExOTEwMDUkbzEkZzEkdDE3NTExOTEwNDMkajIyJGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTEwMDgkbzEkZzEkdDE3NTExOTEwNDQkajI0JGwwJGgw')]</value>
      <webElementGuid>5378c7ae-526a-47a0-b9db-0dbe26af80d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/a</value>
      <webElementGuid>b555aa55-a94c-4bd9-87b1-42b364c381d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://app.eklipse.gg/login?from=https%3A%2F%2Feklipse.gg%2Fpremium&amp;_gl=1*1px592m*_gcl_au*MTA5Mzc0Njk4OS4xNzUxMTkxMDA1*_ga*MTY0OTIzNDQ5MS4xNzUxMTkxMDA1*_ga_GLD7CWERS9*czE3NTExOTEwMDUkbzEkZzEkdDE3NTExOTEwNDMkajIyJGwwJGgw*_ga_WQX826KJ2T*czE3NTExOTEwMDgkbzEkZzEkdDE3NTExOTEwNDQkajI0JGwwJGgw' and (text() = '
						Sign In
					' or . = '
						Sign In
					')]</value>
      <webElementGuid>ccdfedac-3586-47ee-a8c5-2daa9c275727</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
