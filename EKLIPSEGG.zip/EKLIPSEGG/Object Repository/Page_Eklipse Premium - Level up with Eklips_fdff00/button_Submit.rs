<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Submit</name>
   <tag></tag>
   <elementGuidId>413203c5-6633-4ae3-a750-e94cb5e91976</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>button.elementor-button.elementor-size-sm</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//button[@type='submit']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>a86ec181-bac8-42c9-b6b4-0d13f694b0b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-button elementor-size-sm</value>
      <webElementGuid>27ce7ecd-ec29-4ca0-95a5-39f3e7d3c467</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
      <webElementGuid>41e60867-4a03-499a-835e-9e34eb905c78</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
						
																						Submit
													
					</value>
      <webElementGuid>600c7f9d-1c9c-4f5a-af72-e1d16fb17823</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;contact_us_form&quot;)/div[@class=&quot;elementor-form-fields-wrapper elementor-labels-above&quot;]/div[@class=&quot;elementor-field-group elementor-column elementor-field-type-submit elementor-col-100 e-form__buttons&quot;]/button[@class=&quot;elementor-button elementor-size-sm&quot;]</value>
      <webElementGuid>be6eeeb6-6dba-4ea1-a2e2-5635e75d407e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//button[@type='submit']</value>
      <webElementGuid>dd2aa956-4dd6-4b75-98ac-d6813ca8891b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='contact_us_form']/div/div[4]/button</value>
      <webElementGuid>e445aef6-e6e7-4e39-82e2-922ed3ca826a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message'])[1]/following::button[1]</value>
      <webElementGuid>d553e808-0ffa-4a62-a206-bab41c28d338</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/following::button[1]</value>
      <webElementGuid>79cfc827-6edf-4dec-9c9b-b970510094de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/button</value>
      <webElementGuid>9643f8c4-6f90-4636-8e72-d15d018f9c99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//button[@type = 'submit' and (text() = '
						
																						Submit
													
					' or . = '
						
																						Submit
													
					')]</value>
      <webElementGuid>8c214c75-cd16-4c20-a74c-1b01b1f75927</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
