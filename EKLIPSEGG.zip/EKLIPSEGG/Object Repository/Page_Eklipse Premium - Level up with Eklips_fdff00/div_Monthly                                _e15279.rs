<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Monthly                                _e15279</name>
   <tag></tag>
   <elementGuidId>4f401284-de09-4656-ae79-e6828b396118</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.eael-tabs-nav</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='eael-advance-tabs-a1362bb']/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>067651b2-cb17-4c5d-a5b1-a2beead7418d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-tabs-nav</value>
      <webElementGuid>83fb214f-dfb6-48ff-90f9-7b417db16484</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    
            </value>
      <webElementGuid>ae61c483-7fe6-41d2-91cf-a34542ba0229</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;eael-advance-tabs-a1362bb&quot;)/div[@class=&quot;eael-tabs-nav&quot;]</value>
      <webElementGuid>9d22844b-14a1-4428-abca-17b4892cedb4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='eael-advance-tabs-a1362bb']/div</value>
      <webElementGuid>997f89c4-3b02-47ac-9f8a-3983bd13bedc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::div[14]</value>
      <webElementGuid>52b42912-baa0-4558-9c7a-b7e3649e7cd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>7f551b1e-8b6b-4f5e-a2f7-2222982e65e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    
            ' or . = '
                
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    
            ')]</value>
      <webElementGuid>9adefe8d-a4c4-4f52-93b1-8cf113587375</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
