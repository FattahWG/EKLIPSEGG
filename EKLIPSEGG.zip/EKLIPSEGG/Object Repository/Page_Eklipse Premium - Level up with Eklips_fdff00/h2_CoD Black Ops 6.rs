<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_CoD Black Ops 6</name>
   <tag></tag>
   <elementGuidId>cc8cfe6e-d0a4-4185-9ca4-e6b57ef1ca51</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.elementor-element.elementor-element-40a2b90.elementor-widget.elementor-widget-heading > div.elementor-widget-container > h2.elementor-heading-title.elementor-size-default</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='exclusively on Eklipse.'])[1]/following::h2[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>d9aa639e-bc00-4e9b-9f2e-695b3746cc33</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>elementor-heading-title elementor-size-default</value>
      <webElementGuid>760a07b0-254e-4cad-87e8-e1d10239db00</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CoD: Black Ops 6</value>
      <webElementGuid>c5bbb4e3-3942-4c4f-8d7a-da4815c132c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-1830 page-parent wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-1830 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/main[1]/div[@class=&quot;elementor elementor-1830&quot;]/div[@class=&quot;elementor-element elementor-element-2600ba6 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-8c293b5 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-5d1b235 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-40a2b90 elementor-widget elementor-widget-heading&quot;]/div[@class=&quot;elementor-widget-container&quot;]/h2[@class=&quot;elementor-heading-title elementor-size-default&quot;]</value>
      <webElementGuid>432a59b7-da96-4c23-b6b9-cf1212028a85</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='exclusively on Eklipse.'])[1]/following::h2[1]</value>
      <webElementGuid>5fcdb760-c880-4737-941b-8ac33d1c4adc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exclusive Access to New Games'])[1]/following::h2[1]</value>
      <webElementGuid>f83fd279-d0cb-4c19-b501-5d6adc30b41b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Playstation • XBOX • PC'])[1]/preceding::h2[1]</value>
      <webElementGuid>545a79c8-d4e2-4ca8-adcc-bb8496273813</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Twitch • Kick • YouTube'])[1]/preceding::h2[1]</value>
      <webElementGuid>1161a5f8-41c6-4296-80a2-100dc71310f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CoD: Black Ops 6']/parent::*</value>
      <webElementGuid>93a6bbb6-9cc5-42ee-abd9-e800c6643954</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/h2</value>
      <webElementGuid>1d8a6b88-f04b-46a6-942e-cba944ea0392</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'CoD: Black Ops 6' or . = 'CoD: Black Ops 6')]</value>
      <webElementGuid>95bbed27-9e18-478c-bdb1-b3a708daca8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
