<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Annual  Save up to 37</name>
   <tag></tag>
   <elementGuidId>99710a06-f555-437b-a684-ce1fd6c510fd</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#annual-span-classbadgesave-up-to-37span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='annual-span-classbadgesave-up-to-37span']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>dbc3adfb-d891-403c-9072-1bcfe070f4cf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>annual-span-classbadgesave-up-to-37span</value>
      <webElementGuid>bfca06bc-7428-4199-85e3-3eee216140c8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value> eael-tab-item-trigger eael-tab-nav-item</value>
      <webElementGuid>572e2900-8407-4dd4-877b-7dbaccc920a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-selected</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>dce449c4-6314-45c4-8557-775a19a64475</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>2</value>
      <webElementGuid>a70e92dd-fa42-485e-8160-93c1fd3920c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>tab</value>
      <webElementGuid>5f20ad8b-f6bf-4b75-90ff-943d81a2009e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>1f776c77-ce1f-4e1b-8e71-c38194c5e44f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>annual-span-classbadgesave-up-to-37span-tab</value>
      <webElementGuid>8b47ed1e-8922-4e18-b432-59b003ba6bce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>f3bafa38-b77b-480b-99b0-4b02c9a4ce96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                            
                            
                                                            Annual  Save up to 37%                                                    </value>
      <webElementGuid>7ad2aab9-35c1-41b9-ae1f-1ddee5ecdc9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;annual-span-classbadgesave-up-to-37span&quot;)</value>
      <webElementGuid>cd8759ab-3fa7-4a8e-aeb2-61e1a962549a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//li[@id='annual-span-classbadgesave-up-to-37span']</value>
      <webElementGuid>524ab9b6-bf29-4847-8d61-9741521da05f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='eael-advance-tabs-a1362bb']/div/ul/li[2]</value>
      <webElementGuid>0a1e7892-96df-4888-8ccf-0a6eacd4e6e6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Monthly'])[1]/following::li[1]</value>
      <webElementGuid>adb7918a-f428-475e-b7f9-3ffd47ba92d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li[2]</value>
      <webElementGuid>0efb9a95-06e7-4a98-ba22-f434b4079b61</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[@id = 'annual-span-classbadgesave-up-to-37span' and (text() = '
                            
                            
                            
                                                            Annual  Save up to 37%                                                    ' or . = '
                            
                            
                            
                                                            Annual  Save up to 37%                                                    ')]</value>
      <webElementGuid>9e3bac98-56c1-43f0-952e-0b7061803568</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
