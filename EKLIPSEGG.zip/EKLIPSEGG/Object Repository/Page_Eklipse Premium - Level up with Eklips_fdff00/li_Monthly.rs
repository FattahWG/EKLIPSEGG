<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Monthly</name>
   <tag></tag>
   <elementGuidId>5c987a44-c0b2-4333-9901-48b96cd5f54d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#monthly</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='monthly']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>6600be7d-9737-4415-8c51-93d9ea07cd96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>monthly</value>
      <webElementGuid>27cc89c1-4fad-4d29-87ef-54dc3ce19e4d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-tab-item-trigger eael-tab-nav-item inactive</value>
      <webElementGuid>3ab103bb-aa31-47c9-ac12-cc4bc9d742dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-selected</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>984a6426-f08a-4a10-92d9-6eaa99c6f644</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-tab</name>
      <type>Main</type>
      <value>1</value>
      <webElementGuid>69ebd6a3-84ba-46e5-9228-95713d4b0cd3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>tab</value>
      <webElementGuid>7ea6b8a1-88ca-4ddb-a203-f4be045597f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
      <webElementGuid>2f0cc194-17ae-4c38-bd9e-f8b3b54bb013</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-controls</name>
      <type>Main</type>
      <value>monthly-tab</value>
      <webElementGuid>c4e53fed-9e6c-43e6-9c35-f059f866eac9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-expanded</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>53576918-1336-4aea-98eb-12258cee49d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                            
                            
                                                            Monthly                                                    </value>
      <webElementGuid>1321df33-3804-4c26-b964-e4af5ef8ac72</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;monthly&quot;)</value>
      <webElementGuid>dda076db-3faa-466d-bbdb-6897d5a9e220</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//li[@id='monthly']</value>
      <webElementGuid>11355164-54a3-48c8-b7f1-c54392966a9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='eael-advance-tabs-a1362bb']/div/ul/li</value>
      <webElementGuid>00a70492-66a0-4fd9-bf75-d5b10e5721f6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::li[1]</value>
      <webElementGuid>0db687fa-7c3d-4a48-b9d0-50dbe6213a47</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul/li</value>
      <webElementGuid>fd7d5126-cc5b-4f4a-99e6-b337ce6082c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[@id = 'monthly' and (text() = '
                            
                            
                            
                                                            Monthly                                                    ' or . = '
                            
                            
                            
                                                            Monthly                                                    ')]</value>
      <webElementGuid>35632548-b82f-45a3-a24e-2e9c63f2e42d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
