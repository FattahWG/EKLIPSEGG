<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_concat(contact-form-7 id, , 8, ,  title_0b75cb</name>
   <tag></tag>
   <elementGuidId>69e3b1a0-8ed0-469d-a00c-ab45c0708f9e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.e-font-icon-svg.e-eicon-close.eicon-close</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='x'])[1]/following::*[name()='svg'][2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>c192e859-bd95-4a31-b87b-c120cccec122</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>e-font-icon-svg e-eicon-close eicon-close</value>
      <webElementGuid>193a60e9-3c03-4c36-bc57-27396bb4c4dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;elementor-popup-modal-16293&quot;)/div[@class=&quot;dialog-widget-content dialog-lightbox-widget-content animated&quot;]/a[@class=&quot;dialog-close-button dialog-lightbox-close-button&quot;]/svg[@class=&quot;e-font-icon-svg e-eicon-close eicon-close&quot;]</value>
      <webElementGuid>229bcf69-2ab0-4c5c-aeb7-c42bcf986911</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='x'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>2096efd9-349a-4fb9-9af1-e40aed2e9dbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Add Your Heading Text Here'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>e6919a61-da15-4e52-9610-3395bcfcce8e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
