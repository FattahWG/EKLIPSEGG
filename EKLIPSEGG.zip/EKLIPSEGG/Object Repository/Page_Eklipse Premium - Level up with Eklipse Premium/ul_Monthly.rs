<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ul_Monthly</name>
   <tag></tag>
   <elementGuidId>92fbe7c8-20fe-4036-864e-cfab94d44251</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.eael-tabs-nav > ul</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='eael-advance-tabs-a1362bb']/div/ul</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ul</value>
      <webElementGuid>a2e5f88f-6b6d-4d2e-bb3e-d80597f2b8b5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>tablist</value>
      <webElementGuid>1f9c2fba-5fdf-46ee-96eb-ab512150ed8d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    </value>
      <webElementGuid>9876cb8e-603a-4172-b650-5415f72d4d45</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;eael-advance-tabs-a1362bb&quot;)/div[@class=&quot;eael-tabs-nav&quot;]/ul[1]</value>
      <webElementGuid>a8553bdb-05b1-4592-9fd2-3ba519c85a25</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='eael-advance-tabs-a1362bb']/div/ul</value>
      <webElementGuid>426da3df-1ac9-40cc-8caa-761075f6cb59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign Up For Free'])[2]/following::ul[2]</value>
      <webElementGuid>1aad44ce-9f07-49ee-be8b-7cfc022b0ff8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/ul</value>
      <webElementGuid>54cb85e6-7924-4242-9dec-082cd2a038f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//ul[(text() = '
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    ' or . = '
                                            
                            
                            
                            
                                                            Monthly                                                    
                                            
                            
                            
                            
                                                            Annual  Save up to 37%                                                    
                                    ')]</value>
      <webElementGuid>b9f8fa39-7cc3-426a-9407-b42d72c25f8d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
