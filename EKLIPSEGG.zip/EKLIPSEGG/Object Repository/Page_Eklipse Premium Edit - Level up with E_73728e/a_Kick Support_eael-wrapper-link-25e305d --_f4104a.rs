<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Kick Support_eael-wrapper-link-25e305d --_f4104a</name>
   <tag></tag>
   <elementGuidId>55ce6a0a-3bca-4155-a7dc-690160c7a407</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.eael-wrapper-link-25e305d.--eael-wrapper-link-tag</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(//a[contains(@href, 'https://eklipse.gg/features/kick-highlight/')])[3]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>2e5bf01b-0f53-42fe-ab91-32b107254b1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>eael-wrapper-link-25e305d --eael-wrapper-link-tag</value>
      <webElementGuid>ca8a3653-c07c-44b0-ba8a-451e10512943</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://eklipse.gg/features/kick-highlight/</value>
      <webElementGuid>1124e28f-5c11-43da-b6f2-17e3f7a0aabf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-4003 page-child parent-pageid-1830 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-4003 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main__container&quot;]/div[@class=&quot;header-main__col header-main__col--center&quot;]/nav[@class=&quot;header-main__menu&quot;]/ul[@class=&quot;primary-menu&quot;]/li[@class=&quot;nav_item menu-item-depth-0 has-child menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children megamenu&quot;]/ul[@class=&quot;submenu submenu-lv1&quot;]/li[1]/div[@class=&quot;elementor elementor-11934&quot;]/div[@class=&quot;elementor-element elementor-element-e79b4d5 e-con-full e-flex e-con e-parent e-lazyloaded&quot;]/div[@class=&quot;elementor-element elementor-element-28817fa e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-653a68f e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-c9d9968 e-con-full e-flex e-con e-child&quot;]/div[@class=&quot;elementor-element elementor-element-25e305d elementor-position-left elementor-position-top elementor-widget-mobile__width-initial elementor-vertical-align-top elementor-widget elementor-widget-image-box&quot;]/a[@class=&quot;eael-wrapper-link-25e305d --eael-wrapper-link-tag&quot;]</value>
      <webElementGuid>ad143d25-22fd-47b1-8443-9917a2e74607</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://eklipse.gg/features/kick-highlight/')])[3]</value>
      <webElementGuid>6ba208ad-07a8-4792-a1ef-ec684f37bf2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]/a</value>
      <webElementGuid>c8a607af-0ca5-42e1-a503-cea6e7906020</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://eklipse.gg/features/kick-highlight/']</value>
      <webElementGuid>ac462956-981d-491b-857c-86c45ed97a87</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
