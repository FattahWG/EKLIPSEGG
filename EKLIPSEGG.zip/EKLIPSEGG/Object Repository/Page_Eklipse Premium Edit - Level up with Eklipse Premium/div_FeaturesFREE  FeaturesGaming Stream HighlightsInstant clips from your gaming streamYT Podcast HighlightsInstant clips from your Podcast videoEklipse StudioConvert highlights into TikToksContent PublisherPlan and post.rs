<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FeaturesFREE  FeaturesGaming Stream HighlightsInstant clips from your gaming streamYT Podcast HighlightsInstant clips from your Podcast videoEklipse StudioConvert highlights into TikToksContent PublisherPlan and post</name>
   <tag></tag>
   <elementGuidId>6885f297-a852-459c-a0d8-c3b86f95e983</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.header-main</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7d51cdea-7bca-4416-919b-134e9adc7c58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>header-main</value>
      <webElementGuid>1b701ead-de78-4329-b4f8-5c4ce6e9b713</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
			
				
					
						
														
						
					
				
				
											
							
								
									
								
								
									
										
										
									
								
							
							
							Features

			
				
		
				
				
			FREE  Features		
				
		
		
				
				
			Gaming Stream HighlightsInstant clips from your gaming stream		
				
				
				
			YT Podcast HighlightsInstant clips from your Podcast video		
				
				
				
			Eklipse StudioConvert highlights into TikToks		
				
				
				
			Content PublisherPlan and post your content direct from Eklipse		
				
				
				
			Voice CommandTell our AI what moments to clip		
				
				
				
			AI-Edit betaInstantly adds memes to gaming clips		
				
				
				
			Mobile AppPreview,  edit, share clips on the go!		
				
				
				
			Console StreamerEffortlessly Create Content From Console!		
				
				
				
			AI Sport Highlights betaAI-driven Sport Highlights		
				
				
				
				
		
		
				
				
			PREMIUM Features		
				
		
				
				
			Pro EditsProfessional editing just for you		
				
				
				
			Kick SupportConnect Kick streams for the optimal experience		
				
				
				
				
				
				
		


Use Case

			
				
					
		
		
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Modern Warfare        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            CoD Warzone        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Monster Hunter        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            League of Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Fortnite Streamers        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Apex Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Marvel Rivals        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            NBA2K25        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            EAFC24        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Valorant        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            DRAGON BALL        
            

		            
				
				
				
				
				
				
			            
	            
	            
            Check out 300+ more games supported by Eklipse        
            

		            
				
				
				
					
				
				
		


Discovery

			
				
		
				
				
			Learning CenterGet step by step guidance on how to use our tools		
				
				
				
							
					
						
									Visit Learning Center
					
					
				
						
				
				
		
				
				
			Blog		
				
				
				
			What's New Latest updates and features from Eklipse.gg		
				
				
				
			Beginner's GuideEssential streaming 101 guides and tutorials.		
				
				
				
			Streaming TipsPro tips and tricks to enhance your streaming game		
				
				
				
							
					
						
									See more post >
					
					
				
						
				
				
		
				
				
			Help		
				
		
		
				
				
			Basic info		
				
				
				
			What is Eklipse?		
				
				
				
			How does Eklipse work?		
				
				
				
			What are highlights		
				
				
				
			Where should I start?		
				
				
				
			How can I get highlights?		
				
				
				
			Need support?Join Discord server		
				
				
		
				
				
			AI Edit		
				
				
				
			How do I use this AI Edit feature?		
				
				
				
			How does the AI Edit by AI feature work?		
				
				
				
			Eklipse Studio		
				
				
				
			What is Eklipse Studio?		
				
				
		
				
				
			Youtube Highligths		
				
				
				
			What is YouTube Video Highlights? 		
				
				
				
			How does YouTube Video Highlights Work?		
				
				
				
			Is YouTube Video Highlights free to use?		
				
				
				
				
				
				
		


Premium
							
							
							
								Sign In
							
							
								Sign Up For Free
							
						
									
				
					
						Sign In
					
					
						Sign Up For Free
					
						
							
														
						
					
					
						
							
							
						
					

    				
			
		</value>
      <webElementGuid>fa9b2aff-b6b3-4e0e-86e4-38afd9fb7911</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;no-js&quot;]/body[@class=&quot;page-template-default page page-id-4003 page-child parent-pageid-1830 wp-custom-logo ehf-template-eklipsegg ehf-stylesheet-eklipsegg elementor-default elementor-kit-9 elementor-page elementor-page-4003 mysticky-welcomebar-apper e--ua-isTouchDevice e--ua-blink e--ua-edge e--ua-webkit&quot;]/header[@class=&quot;header&quot;]/div[@class=&quot;header-main&quot;]</value>
      <webElementGuid>566413da-cd49-421f-8b5c-389b1ac7a240</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div</value>
      <webElementGuid>723a4f57-4bc6-4dea-a0a6-f0890f0876f8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;
			
				
					
						
														
						
					
				
				
											
							
								
									
								
								
									
										
										
									
								
							
							
							Features

			
				
		
				
				
			FREE  Features		
				
		
		
				
				
			Gaming Stream HighlightsInstant clips from your gaming stream		
				
				
				
			YT Podcast HighlightsInstant clips from your Podcast video		
				
				
				
			Eklipse StudioConvert highlights into TikToks		
				
				
				
			Content PublisherPlan and post your content direct from Eklipse		
				
				
				
			Voice CommandTell our AI what moments to clip		
				
				
				
			AI-Edit betaInstantly adds memes to gaming clips		
				
				
				
			Mobile AppPreview,  edit, share clips on the go!		
				
				
				
			Console StreamerEffortlessly Create Content From Console!		
				
				
				
			AI Sport Highlights betaAI-driven Sport Highlights		
				
				
				
				
		
		
				
				
			PREMIUM Features		
				
		
				
				
			Pro EditsProfessional editing just for you		
				
				
				
			Kick SupportConnect Kick streams for the optimal experience		
				
				
				
				
				
				
		


Use Case

			
				
					
		
		
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Modern Warfare        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            CoD Warzone        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Monster Hunter        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            League of Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Fortnite Streamers        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Apex Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Marvel Rivals        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            NBA2K25        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            EAFC24        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Valorant        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            DRAGON BALL        
            

		            
				
				
				
				
				
				
			            
	            
	            
            Check out 300+ more games supported by Eklipse        
            

		            
				
				
				
					
				
				
		


Discovery

			
				
		
				
				
			Learning CenterGet step by step guidance on how to use our tools		
				
				
				
							
					
						
									Visit Learning Center
					
					
				
						
				
				
		
				
				
			Blog		
				
				
				
			What&quot; , &quot;'&quot; , &quot;s New Latest updates and features from Eklipse.gg		
				
				
				
			Beginner&quot; , &quot;'&quot; , &quot;s GuideEssential streaming 101 guides and tutorials.		
				
				
				
			Streaming TipsPro tips and tricks to enhance your streaming game		
				
				
				
							
					
						
									See more post >
					
					
				
						
				
				
		
				
				
			Help		
				
		
		
				
				
			Basic info		
				
				
				
			What is Eklipse?		
				
				
				
			How does Eklipse work?		
				
				
				
			What are highlights		
				
				
				
			Where should I start?		
				
				
				
			How can I get highlights?		
				
				
				
			Need support?Join Discord server		
				
				
		
				
				
			AI Edit		
				
				
				
			How do I use this AI Edit feature?		
				
				
				
			How does the AI Edit by AI feature work?		
				
				
				
			Eklipse Studio		
				
				
				
			What is Eklipse Studio?		
				
				
		
				
				
			Youtube Highligths		
				
				
				
			What is YouTube Video Highlights? 		
				
				
				
			How does YouTube Video Highlights Work?		
				
				
				
			Is YouTube Video Highlights free to use?		
				
				
				
				
				
				
		


Premium
							
							
							
								Sign In
							
							
								Sign Up For Free
							
						
									
				
					
						Sign In
					
					
						Sign Up For Free
					
						
							
														
						
					
					
						
							
							
						
					

    				
			
		&quot;) or . = concat(&quot;
			
				
					
						
														
						
					
				
				
											
							
								
									
								
								
									
										
										
									
								
							
							
							Features

			
				
		
				
				
			FREE  Features		
				
		
		
				
				
			Gaming Stream HighlightsInstant clips from your gaming stream		
				
				
				
			YT Podcast HighlightsInstant clips from your Podcast video		
				
				
				
			Eklipse StudioConvert highlights into TikToks		
				
				
				
			Content PublisherPlan and post your content direct from Eklipse		
				
				
				
			Voice CommandTell our AI what moments to clip		
				
				
				
			AI-Edit betaInstantly adds memes to gaming clips		
				
				
				
			Mobile AppPreview,  edit, share clips on the go!		
				
				
				
			Console StreamerEffortlessly Create Content From Console!		
				
				
				
			AI Sport Highlights betaAI-driven Sport Highlights		
				
				
				
				
		
		
				
				
			PREMIUM Features		
				
		
				
				
			Pro EditsProfessional editing just for you		
				
				
				
			Kick SupportConnect Kick streams for the optimal experience		
				
				
				
				
				
				
		


Use Case

			
				
					
		
		
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            Black Ops 6 NEW!        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Modern Warfare        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            CoD Warzone        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Monster Hunter        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            League of Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Fortnite Streamers        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Apex Legends        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Marvel Rivals        
            

		            
				
				
				
		
				
				
			            
	            
	            

                            
            
            
            
        
            
            NBA2K25        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            EAFC24        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            Valorant        
            

		            
				
				
				
				
			            
	            
	            

                            
            
            
            
        
            
            DRAGON BALL        
            

		            
				
				
				
				
				
				
			            
	            
	            
            Check out 300+ more games supported by Eklipse        
            

		            
				
				
				
					
				
				
		


Discovery

			
				
		
				
				
			Learning CenterGet step by step guidance on how to use our tools		
				
				
				
							
					
						
									Visit Learning Center
					
					
				
						
				
				
		
				
				
			Blog		
				
				
				
			What&quot; , &quot;'&quot; , &quot;s New Latest updates and features from Eklipse.gg		
				
				
				
			Beginner&quot; , &quot;'&quot; , &quot;s GuideEssential streaming 101 guides and tutorials.		
				
				
				
			Streaming TipsPro tips and tricks to enhance your streaming game		
				
				
				
							
					
						
									See more post >
					
					
				
						
				
				
		
				
				
			Help		
				
		
		
				
				
			Basic info		
				
				
				
			What is Eklipse?		
				
				
				
			How does Eklipse work?		
				
				
				
			What are highlights		
				
				
				
			Where should I start?		
				
				
				
			How can I get highlights?		
				
				
				
			Need support?Join Discord server		
				
				
		
				
				
			AI Edit		
				
				
				
			How do I use this AI Edit feature?		
				
				
				
			How does the AI Edit by AI feature work?		
				
				
				
			Eklipse Studio		
				
				
				
			What is Eklipse Studio?		
				
				
		
				
				
			Youtube Highligths		
				
				
				
			What is YouTube Video Highlights? 		
				
				
				
			How does YouTube Video Highlights Work?		
				
				
				
			Is YouTube Video Highlights free to use?		
				
				
				
				
				
				
		


Premium
							
							
							
								Sign In
							
							
								Sign Up For Free
							
						
									
				
					
						Sign In
					
					
						Sign Up For Free
					
						
							
														
						
					
					
						
							
							
						
					

    				
			
		&quot;))]</value>
      <webElementGuid>78ded3b7-d9f9-4543-a1fa-cb6462b9e6af</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
