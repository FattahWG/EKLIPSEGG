<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_1 Channel selected</name>
   <tag></tag>
   <elementGuidId>366a9cc5-c9e7-4452-b8cd-76e919fed695</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='full-width-tabpanel-1']/div/div[2]/div/div/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.css-yi3mkw</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>04f242e4-0e1d-4958-b680-5a55658a2dda</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-yi3mkw</value>
      <webElementGuid>06fea1c0-8689-40e7-affe-b5a0c302a06d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>1 Channel selected</value>
      <webElementGuid>b9087e22-f17d-4659-9a16-b8c228bc5737</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-channel-stickers MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;MuiBox-root css-1hfttq&quot;]/div[@class=&quot;MuiBox-root css-8siohu&quot;]/div[@id=&quot;full-width-tabpanel-1&quot;]/div[@class=&quot;MuiBox-root css-11mn6qt&quot;]/div[@class=&quot;MuiBox-root css-1su3en&quot;]/div[1]/div[@class=&quot;MuiFormControl-root css-1mzc8&quot;]/div[@class=&quot;MuiInputBase-root MuiOutlinedInput-root MuiInputBase-colorEkPurple Mui-focused MuiInputBase-formControl  css-l0o93r&quot;]/div[@class=&quot;MuiSelect-select MuiSelect-outlined MuiSelect-multiple MuiInputBase-input MuiOutlinedInput-input css-1m97sio&quot;]/div[@class=&quot;MuiBox-root css-yi3mkw&quot;]</value>
      <webElementGuid>c3138f35-39f2-4c7f-8c88-6678fe675f46</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='full-width-tabpanel-1']/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>394d083f-25ca-4abb-a4b4-af5a7a2ad816</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Multi Channel Template Styles'])[1]/following::div[5]</value>
      <webElementGuid>b6297e7c-fe57-43bb-ac7f-efad4b82f768</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[1]/following::div[9]</value>
      <webElementGuid>2eb92eac-3b7c-46b2-8ace-afa5a14f13da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[39]/preceding::div[1]</value>
      <webElementGuid>d41aec67-46e0-4104-96db-0e57fc67e1b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[2]/preceding::div[2]</value>
      <webElementGuid>9d47532b-983d-4a7a-a5e0-d3fcd9896a37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='1 Channel selected']/parent::*</value>
      <webElementGuid>21b30bea-f196-4d3e-9d72-4a69d3abdfbe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[2]/div/div/div/div/div</value>
      <webElementGuid>93dafdb1-3658-4696-8b74-9083d91a912e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '1 Channel selected' or . = '1 Channel selected')]</value>
      <webElementGuid>1ce015df-640a-49fc-9348-516b8a49c200</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
