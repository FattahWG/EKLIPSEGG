<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Add Clip to StartEklipse supports video_a5a232</name>
   <tag></tag>
   <elementGuidId>638edeae-0756-4b0f-af44-73bb4d0244af</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/main/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiPaper-root.MuiPaper-elevation.MuiPaper-rounded.MuiPaper-elevation1.css-18nibrg</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f61066f2-5ac0-4d3f-8e2a-6bac226ddd73</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 css-18nibrg</value>
      <webElementGuid>fdd68667-78ee-407b-b234-787832b4efbe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Add Clip to StartEklipse supports videos from your Local, Twitch/Kick link, and Twitch Channel​Get Clipor


From Your Local




From Twitch</value>
      <webElementGuid>5ba20bc3-b53f-4637-8b5c-d7ddc01eae10</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/main[@class=&quot;MuiBox-root css-1azpmo8&quot;]/div[@class=&quot;MuiStack-root css-nyjdb9&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation1 css-18nibrg&quot;]</value>
      <webElementGuid>04ab8db6-8665-4bd1-8911-9e0ccfbca797</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/main/div/div[2]</value>
      <webElementGuid>a8dd90a6-3066-42c0-9257-2ac0a817a09c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[8]/following::div[5]</value>
      <webElementGuid>2c945530-d9c9-4b30-b1d0-50ed3ad7f880</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[7]/following::div[32]</value>
      <webElementGuid>4f916bb4-d4af-483d-92cd-5edcd7b73630</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//main/div/div[2]</value>
      <webElementGuid>3d8a2108-c757-4c7b-98c1-b5068bc5d8e4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Add Clip to StartEklipse supports videos from your Local, Twitch/Kick link, and Twitch Channel​Get Clipor


From Your Local




From Twitch' or . = 'Add Clip to StartEklipse supports videos from your Local, Twitch/Kick link, and Twitch Channel​Get Clipor


From Your Local




From Twitch')]</value>
      <webElementGuid>820ae898-0805-44d7-8e66-1cb91eafc8d0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
