<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Closed caption is being created</name>
   <tag></tag>
   <elementGuidId>7ece364d-5766-4497-a3a0-65fdd4ae3e8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue'])[1]/following::div[9]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiTypography-root.MuiTypography-h5.MuiTypography-gutterBottom.css-k0h85y</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0492959a-6204-4c94-acc6-1287822e1e63</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiTypography-root MuiTypography-h5 MuiTypography-gutterBottom css-k0h85y</value>
      <webElementGuid>31c45ee9-a059-4ea7-8e2e-f933eefd5b17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Closed caption is being created...</value>
      <webElementGuid>68f9739f-43f0-4036-b5fe-69800d02674c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;MuiDialog-root MuiModal-root css-e3a0f3&quot;]/div[@class=&quot;MuiDialog-container MuiDialog-scrollPaper css-16u656j&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-rounded MuiPaper-elevation24 MuiDialog-paper MuiDialog-paperScrollPaper MuiDialog-paperWidthSm css-1bzhk19&quot;]/div[@class=&quot;MuiDialogContent-root css-i3vm3l&quot;]/div[@class=&quot;MuiTypography-root MuiTypography-h5 MuiTypography-gutterBottom css-k0h85y&quot;]</value>
      <webElementGuid>a66276df-5f89-42c0-a296-735f5f5702ff</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue'])[1]/following::div[9]</value>
      <webElementGuid>fada41fc-ca66-4dfd-bc87-444070f8afe9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back'])[1]/following::div[12]</value>
      <webElementGuid>f3cf6113-6c93-4177-a6ee-05fab6605616</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Closed caption is being created...']/parent::*</value>
      <webElementGuid>20ef8fde-e34d-4c57-9771-20616193e4c7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[3]/div/div/div</value>
      <webElementGuid>53d76ea4-1ce2-4983-ad78-b77b3322b527</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Closed caption is being created...' or . = 'Closed caption is being created...')]</value>
      <webElementGuid>252028a7-1a9e-4701-b6a6-9a7efaffc9a3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
