<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_FollowFor more</name>
   <tag></tag>
   <elementGuidId>f3d50ab0-ca0d-47c8-ae3c-542a2958d43c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[5]/div/div[2]/div/div[5]/div[2]/div/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.text-preset-container.MuiBox-root.css-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>ade8aaab-d778-4c06-950a-146d7df6e475</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-preset-container MuiBox-root css-0</value>
      <webElementGuid>68fe2ca4-c0ad-4af1-8d9f-d1f91d9b828f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Follow
For more!</value>
      <webElementGuid>8cd8b7bf-3948-4e45-a30d-143e2d1eda95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-text MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;menu-text-container MuiBox-root css-ra1eor&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1mfrlut&quot;]/div[@class=&quot;MuiBox-root css-ga71el&quot;]/div[@class=&quot;MuiBox-root css-kl9pno&quot;]/div[@class=&quot;text-preset-list MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-llqt6j&quot;]/div[@class=&quot;text-preset-container MuiBox-root css-0&quot;]</value>
      <webElementGuid>7088365d-690d-4e64-9663-f6a3d58da460</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[5]/div/div[2]/div/div[5]/div[2]/div/div/div</value>
      <webElementGuid>fb4a11ce-b0a2-443b-92cd-170224768b6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[4]/following::div[12]</value>
      <webElementGuid>4ae56168-44b8-4489-a4bc-268b5337944f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[5]/div[2]/div/div/div</value>
      <webElementGuid>1b1e009a-b9f9-49a4-a9b2-c0b9820ac2ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Follow
For more!' or . = 'Follow
For more!')]</value>
      <webElementGuid>d81087b5-776b-4a9d-bd5a-86669bc48bae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
