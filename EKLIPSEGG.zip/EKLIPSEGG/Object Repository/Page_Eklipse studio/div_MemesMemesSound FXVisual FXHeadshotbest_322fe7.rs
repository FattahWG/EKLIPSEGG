<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_MemesMemesSound FXVisual FXHeadshotbest_322fe7</name>
   <tag></tag>
   <elementGuidId>101431e6-0686-4fdc-a399-b5f4f6f96109</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[4]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.menu-add-effects-container.MuiBox-root.css-ra1eor > div.MuiBox-root.css-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>21c2e590-9ced-407c-87f0-0ba48a049a87</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-0</value>
      <webElementGuid>cd2898fb-5a7e-41de-b59a-f2499bc5b93e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>MemesMemesSound FXVisual FX​​Headshotbest cry ever 2Star Wars BlasterDuar kontDababy let_s gAmericas Got Talent Buzzeriscord cat screamerd emojipOK_ _ Ramm12345…157</value>
      <webElementGuid>e70bef78-55e7-45c9-9710-5d8aa0e89dce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-memes MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;menu-add-effects-container MuiBox-root css-ra1eor&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]</value>
      <webElementGuid>cf67a543-6f9a-43a3-be7b-1a213e13c9d8</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[4]/div/div</value>
      <webElementGuid>a3c242b6-e196-4362-90b1-7ad95992ac20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[7]/following::div[14]</value>
      <webElementGuid>0b5b3f89-091f-4662-9386-4fb78ef0b32b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[6]/following::div[28]</value>
      <webElementGuid>f1b6a5eb-d542-4b75-a34b-6b778a58dde2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div</value>
      <webElementGuid>b69fd329-8a21-4b77-bd06-30b61500cda2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'MemesMemesSound FXVisual FX​​Headshotbest cry ever 2Star Wars BlasterDuar kontDababy let_s gAmericas Got Talent Buzzeriscord cat screamerd emojipOK_ _ Ramm12345…157' or . = 'MemesMemesSound FXVisual FX​​Headshotbest cry ever 2Star Wars BlasterDuar kontDababy let_s gAmericas Got Talent Buzzeriscord cat screamerd emojipOK_ _ Ramm12345…157')]</value>
      <webElementGuid>44d65c0c-82c2-430e-9b5e-5e0be7a26d2c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
