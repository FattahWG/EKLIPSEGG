<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_MemesMemesSound FXVisual FXalltop pickh_8a9ae2</name>
   <tag></tag>
   <elementGuidId>a1b29fbc-a8b5-455d-ba69-8f8e61b05df7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[4]/div/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.menu-add-effects-container.MuiBox-root.css-ra1eor > div.MuiBox-root.css-0</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e868ba26-1b63-4152-93ea-523010be6249</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-0</value>
      <webElementGuid>b6255f4e-f15c-4952-8c4b-b015bb3c1093</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>MemesMemesSound FXVisual FX​​alltop pickhypefunnyfailragedisappointmentwholesometoxicSelectPreviewJ Jonah Jameson Laughing Green Screen1</value>
      <webElementGuid>8ac9bb1b-b688-437f-ad4a-82432f9ba4ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-memes MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;menu-add-effects-container MuiBox-root css-ra1eor&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]</value>
      <webElementGuid>156b5663-8f2a-49ee-9633-8b95c0e92e00</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[4]/div/div</value>
      <webElementGuid>93aa3620-e5da-4c4a-b588-b391b5aab362</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[7]/following::div[14]</value>
      <webElementGuid>19495c9f-5d6d-46a9-9ae4-cd180bb96424</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='daily'])[6]/following::div[28]</value>
      <webElementGuid>420c70f6-5eb8-414c-a5bc-7feaa87f5536</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div</value>
      <webElementGuid>4cf492f2-89bf-4560-986f-b096ad135f4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'MemesMemesSound FXVisual FX​​alltop pickhypefunnyfailragedisappointmentwholesometoxicSelectPreviewJ Jonah Jameson Laughing Green Screen1' or . = 'MemesMemesSound FXVisual FX​​alltop pickhypefunnyfailragedisappointmentwholesometoxicSelectPreviewJ Jonah Jameson Laughing Green Screen1')]</value>
      <webElementGuid>5179b3f8-ed10-4952-8cf7-bdfcf4978929</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
