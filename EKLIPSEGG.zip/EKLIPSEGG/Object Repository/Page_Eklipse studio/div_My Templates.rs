<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_My Templates</name>
   <tag></tag>
   <elementGuidId>d188c9ff-0a9e-42db-81e5-1bc9eb64f8d1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div/div/div[2]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiStack-root.css-g2uvf</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c7c4f7f9-8206-4848-ae26-090d6e5a87ae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiStack-root css-g2uvf</value>
      <webElementGuid>d533b6f8-1f1a-42c9-aef3-bb1f55874d18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>My Templates</value>
      <webElementGuid>1db606ec-b5e1-436e-9623-2c3f9fde58a2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-select-template MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;MuiBox-root css-1h1ard6&quot;]/div[@class=&quot;MuiStack-root css-13zidti&quot;]/div[@class=&quot;MuiStack-root css-g2uvf&quot;]</value>
      <webElementGuid>3ead5e0b-309e-4d47-9d1c-571b037485d6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div/div/div[2]/div</value>
      <webElementGuid>050e5e31-eed3-423b-aa30-5a5738d22526</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Layout Templates'])[1]/following::div[2]</value>
      <webElementGuid>aef9faec-ce62-4628-af55-be5a7b21a975</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Output Settings'])[1]/following::div[7]</value>
      <webElementGuid>5ee5800e-e352-441e-80a7-6fe0f94fdb3d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free'])[1]/preceding::div[6]</value>
      <webElementGuid>c7f2f807-1dd3-4882-8078-9bb29e8cd10a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free'])[2]/preceding::div[11]</value>
      <webElementGuid>500617e9-da35-4c77-a649-d10e146b36a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div[2]/div</value>
      <webElementGuid>01f7b9ff-f0f8-4c42-9e26-b745449bea6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'My Templates' or . = 'My Templates')]</value>
      <webElementGuid>d535aedf-baef-40fc-aed6-f9ef89a52b97</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
