<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_StylizedWait for it.I did not expectthi_55328d</name>
   <tag></tag>
   <elementGuidId>f22e4fd0-6e03-4d2e-bcbf-b4748f17a70e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[5]/div/div[2]/div/div[5]/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.css-kl9pno</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>32915b42-bcd8-48e4-8994-12be4671bb2c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiBox-root css-kl9pno</value>
      <webElementGuid>8867f67a-f56d-47cf-98df-af8b3b31389d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>StylizedWait for it...I did not expect
thisHow did this
happen?!Stay till the end
for a surpriseI was shocked
after this</value>
      <webElementGuid>b00b2071-19a2-4d30-ae0a-4f164d79bd3a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-text MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;menu-text-container MuiBox-root css-ra1eor&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1mfrlut&quot;]/div[@class=&quot;MuiBox-root css-ga71el&quot;]/div[@class=&quot;MuiBox-root css-kl9pno&quot;]</value>
      <webElementGuid>2fb2d4f2-3bf9-4b98-9c01-f235c6dbcf04</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/div/div/div[5]/div/div[2]/div/div[5]/div[2]</value>
      <webElementGuid>0bb0a446-0142-41f3-bc49-f2237310c9da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[4]/following::div[9]</value>
      <webElementGuid>872a3cef-5eeb-4ee4-bb6f-dbe4c330b41d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[5]/div[2]</value>
      <webElementGuid>acdce2b0-6640-48cc-80ba-2d7e40b59e5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'StylizedWait for it...I did not expect
thisHow did this
happen?!Stay till the end
for a surpriseI was shocked
after this' or . = 'StylizedWait for it...I did not expect
thisHow did this
happen?!Stay till the end
for a surpriseI was shocked
after this')]</value>
      <webElementGuid>e1f575c8-d96c-499f-8c78-a0d15c98cd80</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
