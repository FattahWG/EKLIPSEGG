<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Texts</name>
   <tag></tag>
   <elementGuidId>ebf7b4e5-7d02-4e57-b3d0-b7b573c9ad7b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[5]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>619999ce-56d5-4b40-b72e-f92c09c76bbd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiButtonBase-root MuiListItemButton-root MuiListItemButton-gutters MuiListItemButton-root MuiListItemButton-gutters css-tieffb</value>
      <webElementGuid>59f3c523-d302-40f8-9acc-a3e116c880b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>5d6658e3-a8e3-46c9-9049-e4726a0221a0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>button</value>
      <webElementGuid>6958c153-0fa6-4a00-8b5b-fd02f8175e29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>





Texts</value>
      <webElementGuid>c150c256-6cc0-486e-8a49-f85a63744322</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/ul[@class=&quot;MuiList-root MuiList-padding css-1pasaxp&quot;]/li[@class=&quot;MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df&quot;]/div[@class=&quot;MuiButtonBase-root MuiListItemButton-root MuiListItemButton-gutters MuiListItemButton-root MuiListItemButton-gutters css-tieffb&quot;]</value>
      <webElementGuid>586e7679-1500-431c-b214-7832069bdb41</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[5]/div</value>
      <webElementGuid>d89485b0-0d75-4846-9b54-87cb436f057e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Memes'])[1]/following::div[1]</value>
      <webElementGuid>7dc4b2b3-96b5-45a7-86b0-a1cbbc552e20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Channel Stickers'])[1]/following::div[4]</value>
      <webElementGuid>9c34b01c-e795-4667-b9bf-ed6837bbaf6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Output Settings'])[1]/preceding::div[5]</value>
      <webElementGuid>08f9b22d-f140-4629-8933-66b4b0123e22</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div</value>
      <webElementGuid>bb894fb2-a4a5-42e8-987e-157c6381e826</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '





Texts' or . = '





Texts')]</value>
      <webElementGuid>009d03b1-a6e8-4ea9-a9a2-c26dbce6907c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
