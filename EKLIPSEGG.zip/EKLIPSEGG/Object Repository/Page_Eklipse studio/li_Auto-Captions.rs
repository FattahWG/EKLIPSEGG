<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Auto-Captions</name>
   <tag></tag>
   <elementGuidId>0b24f1a2-9ed9-4895-b219-bad5a79cf8b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>ab461a98-3a49-4a4c-822f-608be718e7dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df</value>
      <webElementGuid>d05328f2-e40a-4024-a3f2-bb06ee0d37b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>





Auto-Captions</value>
      <webElementGuid>5a12ae10-62ee-4dcf-a067-6be8bf908b29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-xsfmsn&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/ul[@class=&quot;MuiList-root MuiList-padding css-jpx4cj&quot;]/li[@class=&quot;MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df&quot;]</value>
      <webElementGuid>40def6a2-ee87-4a07-87cf-863c47ce1f89</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[2]</value>
      <webElementGuid>e7579e91-6a35-42b3-9e09-6477f92a013a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cropping'])[1]/following::li[1]</value>
      <webElementGuid>8e9b1c64-4930-491d-bc55-8da04d98a870</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Channel Stickers'])[1]/preceding::li[1]</value>
      <webElementGuid>da50f6d1-e4a0-4eec-b35d-d92d85687e4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]</value>
      <webElementGuid>4eda8d4a-e587-4837-8c36-12e00a5b54e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '





Auto-Captions' or . = '





Auto-Captions')]</value>
      <webElementGuid>97df8e54-272b-4bac-bee1-330826083f92</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
