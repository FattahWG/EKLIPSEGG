<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Channel Stickers</name>
   <tag></tag>
   <elementGuidId>bddf30f9-e76b-413d-898b-f7af6ee1fa34</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>7716a574-bf78-40fe-ae9f-45d1ca4b406d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df</value>
      <webElementGuid>348dadb0-4b97-4171-bc7d-0a2b9460d6bd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>





Channel Stickers</value>
      <webElementGuid>e286d8da-4d38-4184-98c5-5a3c8fd1230c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-xsfmsn&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/ul[@class=&quot;MuiList-root MuiList-padding css-jpx4cj&quot;]/li[@class=&quot;MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df&quot;]</value>
      <webElementGuid>ad108770-5ba4-4f47-bc36-08438a7d9b01</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[3]</value>
      <webElementGuid>410096da-fb61-46de-826d-00a31f1258d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto-Captions'])[1]/following::li[1]</value>
      <webElementGuid>68f0ffd9-c987-445f-a24f-33fd64f0c89b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cropping'])[1]/following::li[2]</value>
      <webElementGuid>f51cf3e5-d800-40d2-9dfe-0cbb098281af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Memes'])[1]/preceding::li[1]</value>
      <webElementGuid>20dc18de-0a37-45e7-8f36-7523731a8e86</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]</value>
      <webElementGuid>7dbbb03c-7497-4a40-b78d-31d1db89dadd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '





Channel Stickers' or . = '





Channel Stickers')]</value>
      <webElementGuid>7a1b131a-2f16-4b9a-93e1-ff1933ba0f96</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
