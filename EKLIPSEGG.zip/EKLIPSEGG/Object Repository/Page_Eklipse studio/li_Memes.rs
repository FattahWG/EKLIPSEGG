<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Memes</name>
   <tag></tag>
   <elementGuidId>2821ce8e-7b4e-4ec7-a22a-2f4d6c98241b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>c9263328-4b58-487e-a137-1c14d1f1f52f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df</value>
      <webElementGuid>6dd39c60-cc83-4d84-8e3e-5365c4cee302</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>





Memes</value>
      <webElementGuid>e223f72d-3547-4528-8148-0b33686620cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-xsfmsn&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/ul[@class=&quot;MuiList-root MuiList-padding css-jpx4cj&quot;]/li[@class=&quot;MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df&quot;]</value>
      <webElementGuid>359ec45d-ddcd-44c9-b101-67d696fdddf2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[4]</value>
      <webElementGuid>45a4a278-f344-44a3-848b-2e90193ceb7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Channel Stickers'])[1]/following::li[1]</value>
      <webElementGuid>2d733dbf-6d6d-4dc6-97b4-ffb4a19dc13f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto-Captions'])[1]/following::li[2]</value>
      <webElementGuid>32540db5-8f21-436b-b4e0-41d844c7632b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Texts'])[1]/preceding::li[1]</value>
      <webElementGuid>6b20c8ee-1fcb-4e45-a977-758703130a5e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[4]</value>
      <webElementGuid>beff034e-ffae-4c9b-b9be-3494172f4cc0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '





Memes' or . = '





Memes')]</value>
      <webElementGuid>a9ed6a3b-5aa9-4e6d-8098-d23931aec4bb</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
