<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Output Settings</name>
   <tag></tag>
   <elementGuidId>44000237-c824-4ed4-862d-54e026282bb6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[6]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>471af598-8c33-4bfc-8c46-9a7ebec8e3b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df</value>
      <webElementGuid>a120bd19-eaf8-4d2e-bbb1-6d1ce0e6b6df</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>





Output Settings</value>
      <webElementGuid>fa2e75f7-cb45-42aa-950a-263bae58ffa3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-xsfmsn&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/ul[@class=&quot;MuiList-root MuiList-padding css-jpx4cj&quot;]/li[@class=&quot;MuiListItem-root MuiListItem-gutters menu-list-item css-qkz7df&quot;]</value>
      <webElementGuid>14e3e107-c099-48a5-80c5-3209e41fa612</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div/div/div[2]/ul/li[6]</value>
      <webElementGuid>12fba8ce-d1d0-4761-97e8-a6d1c422c878</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Texts'])[1]/following::li[1]</value>
      <webElementGuid>a1256adc-c84d-404b-8631-0db34dac55d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Memes'])[1]/following::li[2]</value>
      <webElementGuid>0accedf6-3b9b-4233-b6d6-77f659c88a78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Layout Templates'])[1]/preceding::li[1]</value>
      <webElementGuid>86e610ba-4ff1-41ae-bfa0-0a5c587876d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]</value>
      <webElementGuid>162bc148-897a-45a2-9f79-bf46e4e59b94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = '





Output Settings' or . = '





Output Settings')]</value>
      <webElementGuid>abf5bfad-8be8-4138-ae83-61bd48b3724d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
