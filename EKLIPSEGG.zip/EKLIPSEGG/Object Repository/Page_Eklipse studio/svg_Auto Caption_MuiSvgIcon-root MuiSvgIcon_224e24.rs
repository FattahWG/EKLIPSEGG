<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Auto Caption_MuiSvgIcon-root MuiSvgIcon_224e24</name>
   <tag></tag>
   <elementGuidId>773ab810-4e48-4707-8959-b5e333fc0604</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto Caption'])[1]/following::*[name()='svg'][2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeSmall.css-1k33q06</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>854742e3-65c9-4f8e-9bff-a472a860ed06</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06</value>
      <webElementGuid>8407eccc-3b2f-41b6-95bf-5934d757f274</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>35c06162-8a19-434f-9387-133c7e2922eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>ae79291b-03a7-4936-b255-58731e9a971c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>c0374998-a8a1-4982-9d3a-60076656c6d6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>KeyboardArrowLeftIcon</value>
      <webElementGuid>a948187f-12bf-45d0-9943-4ca995e6b6c6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-auto-caption MuiBox-root css-4q161y&quot;]/div[@class=&quot;menu-auto-caption-container MuiBox-root css-16bw7cj&quot;]/div[@class=&quot;MuiTabs-root css-pc1mzd&quot;]/div[@class=&quot;MuiButtonBase-root MuiTabScrollButton-root MuiTabScrollButton-horizontal MuiTabs-scrollButtons css-1q0ig8p&quot;]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06&quot;]</value>
      <webElementGuid>c70cb47f-f681-4496-af03-b1df4ee73628</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Auto Caption'])[1]/following::*[name()='svg'][2]</value>
      <webElementGuid>d18890ab-6f08-495f-ac54-a2c34825ea68</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Free'])[13]/following::*[name()='svg'][2]</value>
      <webElementGuid>35a06f02-8eee-42d9-8e23-b762e8c7b8a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Styles'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>a2d28388-d94e-43ba-a920-ffd72a7f2514</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Captions'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>153fc0ba-b39a-45e1-be93-3f4da7237042</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
