<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg_Captions_MuiSvgIcon-root MuiSvgIcon-fon_c25cb6</name>
   <tag></tag>
   <elementGuidId>22f9b30b-4792-46c9-8237-15d83b040af6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Captions'])[1]/following::*[name()='svg'][1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>6cb1bc39-faa2-4158-8bda-91dd6f6f7983</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06</value>
      <webElementGuid>9b848adc-8ccb-48da-9de6-5b7f2e2dbd57</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>a00f086c-9b42-490f-a80a-a3950484e1b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>918b0264-f7c6-4cff-87f2-26f160f2e98e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>61bd6a27-1790-458b-b9e3-d26a2f347632</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>KeyboardArrowRightIcon</value>
      <webElementGuid>12869c56-1805-4fac-b5b9-95ada7d4930f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-auto-caption MuiBox-root css-4q161y&quot;]/div[@class=&quot;menu-auto-caption-container MuiBox-root css-16bw7cj&quot;]/div[@class=&quot;MuiTabs-root css-pc1mzd&quot;]/div[@class=&quot;MuiButtonBase-root MuiTabScrollButton-root MuiTabScrollButton-horizontal MuiTabs-scrollButtons css-1q0ig8p&quot;]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeSmall css-1k33q06&quot;]</value>
      <webElementGuid>ebca375c-9a9c-4d57-bf51-e62a47f6ab9b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Captions'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>f9207473-0600-4537-9ef3-1fccf5cbfc1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Styles'])[1]/following::*[name()='svg'][1]</value>
      <webElementGuid>5dfcd6b1-fd1d-434a-98ca-692be2c688e9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Generated Caption'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>fe703a31-a746-4438-a9ba-863f92b17b64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Emoji'])[1]/preceding::*[name()='svg'][1]</value>
      <webElementGuid>525641a2-7d2c-49cb-80c9-c8ba4af5cc66</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
