<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg__MuiSvgIcon-root MuiSvgIcon-fontSizeMed_b3633d</name>
   <tag></tag>
   <elementGuidId>b27855d8-6ad3-4a52-a543-ec31937f28c5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[41]/following::*[name()='svg'][4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.MuiBox-root.css-1gibhro > svg.MuiSvgIcon-root.MuiSvgIcon-fontSizeMedium.css-vubbuv</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
      <webElementGuid>f12c6df2-5286-43cd-85a5-c5a906c45fd8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv</value>
      <webElementGuid>a054f252-3ffa-4ba4-b54b-52a364e7eed8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>focusable</name>
      <type>Main</type>
      <value>false</value>
      <webElementGuid>b9a8f4fe-7908-476e-a246-91385b76a206</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
      <webElementGuid>b3b7eb63-4db3-41d2-8975-dbff7e9bbe92</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 24 24</value>
      <webElementGuid>52134f08-56b1-4fb0-b1d2-2cb026eef51f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-testid</name>
      <type>Main</type>
      <value>ExpandMoreIcon</value>
      <webElementGuid>9067832b-2c7c-47a8-b0a6-f6fda7ab0713</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;MuiBox-root css-20pg7w&quot;]/div[@class=&quot;MuiDrawer-root MuiDrawer-docked css-71o41b&quot;]/div[@class=&quot;MuiPaper-root MuiPaper-elevation MuiPaper-elevation0 MuiDrawer-paper MuiDrawer-paperAnchorLeft MuiDrawer-paperAnchorDockedLeft css-kaqrgg&quot;]/div[@class=&quot;MuiBox-root css-164swfl&quot;]/div[@class=&quot;drawer-menu-container MuiBox-root css-u8x2t0&quot;]/div[@class=&quot;drawer-menu-content MuiBox-root css-l7vbaj&quot;]/div[@class=&quot;drawer-menu drawer-menu-text MuiBox-root css-18gvuhn&quot;]/div[@class=&quot;menu-text-container MuiBox-root css-ra1eor&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1mfrlut&quot;]/div[@class=&quot;MuiBox-root css-ofhxps&quot;]/div[@class=&quot;MuiBox-root css-8atqhb&quot;]/div[@class=&quot;MuiBox-root css-ie8tbk&quot;]/div[@class=&quot;MuiBox-root css-0&quot;]/div[@class=&quot;MuiBox-root css-1tq5dko&quot;]/div[@class=&quot;MuiBox-root css-1gibhro&quot;]/svg[@class=&quot;MuiSvgIcon-root MuiSvgIcon-fontSizeMedium css-vubbuv&quot;]</value>
      <webElementGuid>751656b5-4089-49ce-9d20-015f800ce921</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='​'])[41]/following::*[name()='svg'][4]</value>
      <webElementGuid>cffcd413-e3b7-47e2-b5a6-0a67285e73ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Small'])[1]/following::*[name()='svg'][5]</value>
      <webElementGuid>955505da-6648-4145-8818-3a94ded5bf48</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[1]/preceding::*[name()='svg'][3]</value>
      <webElementGuid>bd46d1bf-466a-414b-abd8-4936a442203b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[2]/preceding::*[name()='svg'][6]</value>
      <webElementGuid>e1129b84-b68c-46c5-a0e7-ffa76e2217a1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
