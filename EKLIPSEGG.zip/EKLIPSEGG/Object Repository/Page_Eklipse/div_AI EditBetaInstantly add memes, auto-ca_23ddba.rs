<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_AI EditBetaInstantly add memes, auto-ca_23ddba</name>
   <tag></tag>
   <elementGuidId>ad584ecc-3e9b-4266-9c5b-091d23dab129</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-dialog-centered > div.modal-content</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>bdac287e-8a09-4074-96bd-e67a21246626</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>20521f12-716a-4414-be92-3c9e74df2cfc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>AI EditBetaInstantly add memes, auto-captions, video &amp; sound effects that fit your clip perfectly!1Import2Select MethodGet ClipTry select clip from Twitch instead?Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.Local UploadUpload video from your device Get the best AI Edit with your best clips Previous+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer's TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer's Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer's Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer's Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer's TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer's Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer's Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer's Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer's TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer's Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine NextCustomize Style SettingsLayoutPortraitLandscapeCaptionsMemeComing SoonLightMediumHeavySound EffectComing SoonAn audio element, such as music, voice, or sound effects, used to enhance the mood or convey information in a video or meme.LightMediumHeavySlow Motion EffectComing SoonMaking a video play slower to highlight a momentLightMediumHeavyZoom EffectComing SoonLightMediumHeavyBackground MusicComing SoonMusic playing softly in the background to set the moodTextComing SoonFrame EffectComing SoonTransitionComing SoonMore Detail (Optional)Coming SoonFast-paced action editing with a lot of sparkling effectsBackGet AI Edit</value>
      <webElementGuid>b043e59a-789f-482a-a3a8-fefe1914ffe6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ai-edit-modal-container current-step-2 modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>cb9411ae-afc2-4223-8ae0-da6c317e4114</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      <webElementGuid>b31a31a6-a927-4dd0-9b43-a8d6fd33022f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::div[7]</value>
      <webElementGuid>866290f3-346e-4812-a074-337570801cc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>481dc250-38d3-48f5-bf38-a82f76911734</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;AI EditBetaInstantly add memes, auto-captions, video &amp; sound effects that fit your clip perfectly!1Import2Select MethodGet ClipTry select clip from Twitch instead?Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.Local UploadUpload video from your device Get the best AI Edit with your best clips Previous+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine NextCustomize Style SettingsLayoutPortraitLandscapeCaptionsMemeComing SoonLightMediumHeavySound EffectComing SoonAn audio element, such as music, voice, or sound effects, used to enhance the mood or convey information in a video or meme.LightMediumHeavySlow Motion EffectComing SoonMaking a video play slower to highlight a momentLightMediumHeavyZoom EffectComing SoonLightMediumHeavyBackground MusicComing SoonMusic playing softly in the background to set the moodTextComing SoonFrame EffectComing SoonTransitionComing SoonMore Detail (Optional)Coming SoonFast-paced action editing with a lot of sparkling effectsBackGet AI Edit&quot;) or . = concat(&quot;AI EditBetaInstantly add memes, auto-captions, video &amp; sound effects that fit your clip perfectly!1Import2Select MethodGet ClipTry select clip from Twitch instead?Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.Local UploadUpload video from your device Get the best AI Edit with your best clips Previous+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine+SelectPreview01:30😱Wine Game Jumpscare! 🍷Gameplay GONE WRONG! #HorrorTales #Gaming #JumpScare #PewPew+SelectPreview01:30Gnome Grenades &amp; Giggles! 😂🤣 #Gaming #Streamer #FunnyMoments #HorrorTales #Wine+SelectPreview01:00Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Point Struggle! 😂 #Gaming #FunnyMoments #HorrorTalesTheWine #FunnyStreamers #Gameplay+SelectPreview01:30Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Extraction Fail! 🤣😂 #Gaming #Streamer #FunnyMoments #ExtractionFail #Bodoh #Humor #Highlights+SelectPreview01:30Robot Invasion &amp; Ban?! 😂😱 | Horror Tales: The Wine 🍷🎮 #Gaming #Horror #Funny #Streamer #Escape+SelectPreview01:00😱 TERRIFYING ENCOUNTER! 😱 New Enemy Jumpscare in Horror Tales: The Wine! 🍷 #HorrorGames #Gaming #LetsPlay #JumpScare #HorrorTales #TheWine #Gameplay+SelectPreview01:00😱MONSTER CHASE GONE WRONG! 😱 Streamer&quot; , &quot;'&quot; , &quot;s TERRIFYING Reaction! #HorrorGames #Gaming #Streamer #Scary #Funny #Wine+SelectPreview01:30😱Monster Chase GONE WRONG!😂| Hilarious Gameplay| Horror Tales: The Wine 🍷#HorrorGames #FunnyMoments #Gaming #Streamer #Scared+SelectPreview00:46Streamer&quot; , &quot;'&quot; , &quot;s Hilarious Reaction! 😂🤣 #Gaming #HorrorTales #FunnyMoments #Streamer #Wine NextCustomize Style SettingsLayoutPortraitLandscapeCaptionsMemeComing SoonLightMediumHeavySound EffectComing SoonAn audio element, such as music, voice, or sound effects, used to enhance the mood or convey information in a video or meme.LightMediumHeavySlow Motion EffectComing SoonMaking a video play slower to highlight a momentLightMediumHeavyZoom EffectComing SoonLightMediumHeavyBackground MusicComing SoonMusic playing softly in the background to set the moodTextComing SoonFrame EffectComing SoonTransitionComing SoonMore Detail (Optional)Coming SoonFast-paced action editing with a lot of sparkling effectsBackGet AI Edit&quot;))]</value>
      <webElementGuid>a84cb1cc-8b60-4648-b116-1d2aca425019</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
