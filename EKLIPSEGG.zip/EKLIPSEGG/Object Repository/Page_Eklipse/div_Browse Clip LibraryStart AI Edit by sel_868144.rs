<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Browse Clip LibraryStart AI Edit by sel_868144</name>
   <tag></tag>
   <elementGuidId>179fefa3-5e11-4afd-b890-fca7439bc246</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Get Clip'])[2]/following::div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.action</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6be3a826-60b2-432b-b890-ac4b6b331278</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>action</value>
      <webElementGuid>7e7ae53e-5d4d-4830-a1a9-fd2844f99ebf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.</value>
      <webElementGuid>8a0dcd80-0238-4996-8c10-acb314a3a534</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ai-edit-modal-container current-step-2 modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;ai-edit-modal-container&quot;]/div[1]/div[@class=&quot;choose-ai-edit-panel&quot;]/div[2]/div[@class=&quot;list-actions&quot;]/div[@class=&quot;action&quot;]</value>
      <webElementGuid>be42a3d7-1754-47f9-be76-81641851cd4a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get Clip'])[2]/following::div[3]</value>
      <webElementGuid>c47f916b-1930-49f8-9d68-02549c62bd5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Method'])[1]/following::div[6]</value>
      <webElementGuid>c6891a61-7fe9-474e-8565-33736fa55d54</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div[2]/div/div/div/div[2]/div[3]/div</value>
      <webElementGuid>f21cb2b0-adfb-43e4-b0d9-673d0bf7f148</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.' or . = 'Browse Clip LibraryStart AI Edit by selecting from your AI-Highlights library.')]</value>
      <webElementGuid>e9b4a3ca-7345-4952-a18a-fbad5ed1bcc8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get Clip'])[1]/following::div[3]</value>
      <webElementGuid>ba725f88-b819-42e4-997e-3238677252d6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
