<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Clair Obscur Expedition 33_position-abs_c3c05a</name>
   <tag></tag>
   <elementGuidId>deece484-0147-4e6b-b675-b2e483b7b5cb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Clair Obscur: Expedition 33'])[1]/following::div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.position-absolute.active</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e92b24c9-8e74-4931-9769-46041abe0b3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>position-absolute active</value>
      <webElementGuid>88a2c3d3-8139-4d8b-bbca-dae039158025</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade re-submit-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-lg modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;left col-12 d-flex flex-column justify-content-start&quot;]/div[3]/div[@class=&quot;row games mx-0 px-0 mb-2 d-flex justify-content-start&quot;]/div[@class=&quot;box px-1 pb-2&quot;]/div[@class=&quot;position-relative&quot;]/div[@class=&quot;position-absolute active&quot;]</value>
      <webElementGuid>77516ecc-b1f7-4cf8-99ea-3e4a03bdff8d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Clair Obscur: Expedition 33'])[1]/following::div[3]</value>
      <webElementGuid>b762dd7f-97d8-4bb3-9f28-006c5016a135</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[13]/following::div[3]</value>
      <webElementGuid>03f95cb0-8e21-4744-8029-a7b0a10fb9b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[14]/preceding::div[2]</value>
      <webElementGuid>4cfa3321-b206-4a2e-9e0f-b24c278f26d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Command &amp; Conquer'])[1]/preceding::div[3]</value>
      <webElementGuid>6ebe0827-2f54-46ab-ad61-d18759419b9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[12]/div/div</value>
      <webElementGuid>1e32121c-2455-4c81-84f8-3981a5a32745</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
