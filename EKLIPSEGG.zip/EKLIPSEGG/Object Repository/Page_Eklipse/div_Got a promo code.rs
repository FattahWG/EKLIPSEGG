<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Got a promo code</name>
   <tag></tag>
   <elementGuidId>7926903d-e140-45cd-b8fb-4c51896fe115</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.promo-header</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='card'])[1]/following::div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>b79039c5-803a-44e4-a8a9-ce6867d33996</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>promo-header </value>
      <webElementGuid>349f378d-3075-4abf-82d6-676159b2d129</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Got a promo code?</value>
      <webElementGuid>6764b5d4-74b4-4707-ac44-32a0d8ead250</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-modal ek-modal-cta-upgrade-premium modal show&quot;]/div[@class=&quot;modal-dialog modal-lg modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;banner&quot;]/div[@class=&quot;right-payment-container&quot;]/div[@class=&quot;mt-2&quot;]/div[@class=&quot;accordion&quot;]/div[1]/div[@class=&quot;promo-header&quot;]</value>
      <webElementGuid>6736e299-3358-44e0-bb63-3f72e1f7d432</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='card'])[1]/following::div[4]</value>
      <webElementGuid>0468ec4d-9661-41ac-851c-1985a948b860</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='paypal'])[1]/following::div[5]</value>
      <webElementGuid>e9b79840-1ad5-4ddf-b933-3f81213cdb15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Redeem'])[1]/preceding::div[2]</value>
      <webElementGuid>1749a11f-cc41-41a4-8847-1c9158302f53</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[4]/div/div/div</value>
      <webElementGuid>1501482c-ad2e-4912-a5b2-a73e90c99c21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Got a promo code?' or . = 'Got a promo code?')]</value>
      <webElementGuid>0765076a-eaff-4a1d-980a-87ad8ba91015</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
