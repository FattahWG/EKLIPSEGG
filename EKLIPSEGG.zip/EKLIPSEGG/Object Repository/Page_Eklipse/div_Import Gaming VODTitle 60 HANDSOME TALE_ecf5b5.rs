<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Import Gaming VODTitle 60 HANDSOME TALE_ecf5b5</name>
   <tag></tag>
   <elementGuidId>12c2db67-3b65-4fab-8344-e26392f7865d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-md.modal-dialog-centered > div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>349a521b-1ddd-4a5a-90be-3bad64d45bd1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>f041c419-346f-4fa1-909d-3a78ffe72698</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Import Gaming VODTitle🔴 6''0 HANDSOME TALENTED FUNNY VIETNAMESE KING DOMINATES RANKED 🔴Duration01:50:34Date/Time2025-06-28 13:20:00CancelGet Clip Now</value>
      <webElementGuid>9d7379bf-b38a-432e-b919-5d26db387ddc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-preview-vod-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-md modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>4cb91817-a43a-4083-b547-375407704768</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      <webElementGuid>ba16eb7a-7183-496e-8bf3-2f7a8f9a026c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::div[7]</value>
      <webElementGuid>3ada6b28-02f0-4d08-af96-1e130799402e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>d5c6231b-c895-4419-9465-1e5cf02aca42</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;Import Gaming VODTitle🔴 6&quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot;0 HANDSOME TALENTED FUNNY VIETNAMESE KING DOMINATES RANKED 🔴Duration01:50:34Date/Time2025-06-28 13:20:00CancelGet Clip Now&quot;) or . = concat(&quot;Import Gaming VODTitle🔴 6&quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot;0 HANDSOME TALENTED FUNNY VIETNAMESE KING DOMINATES RANKED 🔴Duration01:50:34Date/Time2025-06-28 13:20:00CancelGet Clip Now&quot;))]</value>
      <webElementGuid>2cd42eec-7ab4-4e44-b3e8-39434ce2c4fd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
