<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Import your StreamConnect AccountsConne_9d7913</name>
   <tag></tag>
   <elementGuidId>33faeb69-d36d-4d35-87cc-c03902daf6e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-dialog-centered > div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>746034a9-e7d6-4173-b07b-264cc5d5b832</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>9a127a89-5c49-4e79-8e09-25e9fd6c6fb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Import your StreamConnect AccountsConnect for the Ultimate ExperiencePrivate StreamNewTikTok LivestreamBetaUpload a VideoKick.comTry with your VOD link: 3 trial availableImportSelect...</value>
      <webElementGuid>a24b39e0-2c3c-49de-92bd-40eb827abf35</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-get-stream-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>bce9b566-72ce-4226-9aa0-d8059cffcddb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      <webElementGuid>e7274b2f-30ce-4b0c-9bc4-59a27bc65d81</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::div[7]</value>
      <webElementGuid>a6c6f6a0-1cbe-417c-8580-44436c23ac52</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>e9b35885-7283-4e49-b538-fbbd4941a96b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Import your StreamConnect AccountsConnect for the Ultimate ExperiencePrivate StreamNewTikTok LivestreamBetaUpload a VideoKick.comTry with your VOD link: 3 trial availableImportSelect...' or . = 'Import your StreamConnect AccountsConnect for the Ultimate ExperiencePrivate StreamNewTikTok LivestreamBetaUpload a VideoKick.comTry with your VOD link: 3 trial availableImportSelect...')]</value>
      <webElementGuid>8a4b7e53-a945-4f3a-a298-295d1cb88853</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
