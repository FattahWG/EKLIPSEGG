<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_OMG   R.E.P.O. Gameplay GONE WRONG  Not_36140f</name>
   <tag></tag>
   <elementGuidId>1a9e3af3-11ae-458c-814d-91e38d70d062</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Edit'])[4]/following::div[3]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.clip-title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>e031b665-d53f-4ab0-81e7-16fd5715c03b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>clip-title</value>
      <webElementGuid>bdf3d033-2a57-47c8-9b8f-b3afa46f7bc0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>OMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamer</value>
      <webElementGuid>fe876c0d-18c9-482f-b138-84469e998705</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade community-highlight-clip-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;d-flex flex-column community-highlight-clip-container&quot;]/div[@class=&quot;media-info&quot;]/div[@class=&quot;info&quot;]/div[@class=&quot;clip-title&quot;]</value>
      <webElementGuid>76d774e0-048f-46e2-98ae-44d50b901e98</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='AI Edit'])[4]/following::div[3]</value>
      <webElementGuid>c3d2608c-a283-4ee9-9531-22ec0ac21d1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close Modal Dialog'])[1]/following::div[4]</value>
      <webElementGuid>25a536c7-c221-45b9-b44a-90cea35cd4f3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='June, 25th 2025'])[1]/preceding::div[1]</value>
      <webElementGuid>a6074c36-6e13-4114-ac87-ae3793709771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='#repo'])[1]/preceding::div[2]</value>
      <webElementGuid>f877d6cd-099d-48e1-a190-9a767a489bc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/div[6]/div/div</value>
      <webElementGuid>e87c232d-cf96-4bf7-820a-e47662d18d18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'OMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamer' or . = 'OMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamer')]</value>
      <webElementGuid>11ec6b7d-be02-455e-9371-afe0c1501cae</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
