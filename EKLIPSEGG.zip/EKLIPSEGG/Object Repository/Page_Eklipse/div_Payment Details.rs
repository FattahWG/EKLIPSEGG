<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Payment Details</name>
   <tag></tag>
   <elementGuidId>56414204-56ef-4a55-b11b-393637a7b75a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Redeem'])[1]/following::div[4]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>0f884997-53de-4f4b-b5dc-38ec24aa4c54</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>promo-header </value>
      <webElementGuid>24984d6b-f92d-4866-ae1e-9678b3efacf7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Payment Details</value>
      <webElementGuid>7832ef0c-f88e-4563-a620-e592b2d9ec1d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-modal ek-modal-cta-upgrade-premium modal show&quot;]/div[@class=&quot;modal-dialog modal-lg modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;banner&quot;]/div[@class=&quot;right-payment-container&quot;]/div[@class=&quot;mt-2&quot;]/div[@class=&quot;accordion&quot;]/div[1]/div[@class=&quot;promo-header&quot;]</value>
      <webElementGuid>c4ed436b-5576-4292-98b4-99770000d9ac</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Redeem'])[1]/following::div[4]</value>
      <webElementGuid>19e3bd28-8211-4010-867a-57b3b9d88e30</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Got a promo code?'])[1]/following::div[8]</value>
      <webElementGuid>27d20714-65de-4712-b085-b3117f3e28f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Total'])[1]/preceding::div[2]</value>
      <webElementGuid>64b3013f-9489-4b4c-bf6c-12c41ae9f571</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div[5]/div/div/div</value>
      <webElementGuid>00ceab49-0613-415f-845c-1b85f0b4d276</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Payment Details' or . = 'Payment Details')]</value>
      <webElementGuid>ce846a29-3dab-4397-a7a5-e0a9d122b9b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
