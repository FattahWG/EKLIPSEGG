<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Premium Eklipse Annual149.99Total149.99</name>
   <tag></tag>
   <elementGuidId>0fe80a67-c9a3-4a44-b3b0-95e1c16f04c8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.collapse.show > div</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Details'])[1]/following::div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>1efc74e9-aa92-4a66-8395-65cac1d4c6cb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Premium Eklipse Annual$149.99Total$149.99</value>
      <webElementGuid>c977d689-1f5f-4fb2-b580-dcbfa47842b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-modal ek-modal-cta-upgrade-premium modal show&quot;]/div[@class=&quot;modal-dialog modal-lg modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;banner&quot;]/div[@class=&quot;right-payment-container&quot;]/div[@class=&quot;mt-2&quot;]/div[@class=&quot;accordion&quot;]/div[@class=&quot;collapse show&quot;]/div[1]</value>
      <webElementGuid>e71dfaca-ffbc-4c7a-9302-4d954a199a65</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Payment Details'])[1]/following::div[2]</value>
      <webElementGuid>043bac5d-2fac-45e3-ad3c-1721a1ba7594</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Redeem'])[1]/following::div[6]</value>
      <webElementGuid>ef7e0074-e194-4d3c-b469-00077523f8f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terms of Use, Auto-Renewal Policy'])[1]/preceding::div[3]</value>
      <webElementGuid>f41923e8-d0ff-4e5a-b67b-eb5cafb4efcb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div[2]/div</value>
      <webElementGuid>3d671dc5-a2bf-47c8-b42f-268da78216c2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Premium Eklipse Annual$149.99Total$149.99' or . = 'Premium Eklipse Annual$149.99Total$149.99')]</value>
      <webElementGuid>158c663f-e356-4302-b33b-cef3babe52fa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
