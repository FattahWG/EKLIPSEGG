<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Premium-Exclusive GameUpgrade now for e_dc7be9</name>
   <tag></tag>
   <elementGuidId>c5f07051-4c48-431b-bfcf-e528e7bca949</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Go to game page'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.swal2-container.swal2-center.swal2-backdrop-show</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>67f24f2e-8ca9-495e-a12d-1a7885c904dc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>swal2-container swal2-center swal2-backdrop-show</value>
      <webElementGuid>a735eadb-a8cf-400a-8a3d-c12d5239ed3c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>×Premium-Exclusive GameUpgrade now for early access to all games, exclusive new releases, and extra benefits!OKNoCancelGo Premium</value>
      <webElementGuid>3b2bf15a-dba9-4c89-8866-7ee081b72c16</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;swal2-shown swal2-height-auto&quot;]/body[@class=&quot;modal-open swal2-shown swal2-height-auto&quot;]/div[@class=&quot;swal2-container swal2-center swal2-backdrop-show&quot;]</value>
      <webElementGuid>baa88843-3c8f-47d1-9952-7a289112cf50</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Go to game page'])[1]/following::div[7]</value>
      <webElementGuid>4940384b-4962-474b-a1a7-fd3001ff9a70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Confirm'])[1]/following::div[7]</value>
      <webElementGuid>be18916d-fa4a-460c-8c67-4e11f5a6a77a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]</value>
      <webElementGuid>0802d007-1e4f-49a3-ba38-45d8fcf1762e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '×Premium-Exclusive GameUpgrade now for early access to all games, exclusive new releases, and extra benefits!OKNoCancelGo Premium' or . = '×Premium-Exclusive GameUpgrade now for early access to all games, exclusive new releases, and extra benefits!OKNoCancelGo Premium')]</value>
      <webElementGuid>c919f3b2-f222-45d6-aeb8-d26454fa95f7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
