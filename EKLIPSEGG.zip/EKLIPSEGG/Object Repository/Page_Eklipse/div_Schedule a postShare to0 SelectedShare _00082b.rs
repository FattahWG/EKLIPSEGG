<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Schedule a postShare to0 SelectedShare _00082b</name>
   <tag></tag>
   <elementGuidId>a8b89340-32c2-4b37-9628-6aee2afabe13</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-dialog-centered > div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>643825ef-3570-4786-98da-90540b145314</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>25455053-9437-4975-9c10-b14af1a34d58</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Schedule a postShare to:0 Selected+Share methodSchedule postLet Eklipse post  your content at the chosen timeDate &amp; timeUnlock NowShare nowInstantly share your content with just one click.CaptionAI Post CaptionSelect ToneCasualWittyFormalGenerateBy default, your clips may appear in the community to help others discover great momentsManage SettingsPreview Your PostTikTokFacebookIG ReelsYT ShortsDiscord+Find clipSchedule</value>
      <webElementGuid>2c06336b-20d5-4817-9e7f-cad72dd73f7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-schedule-post-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>270431ee-f6ff-441c-9344-2869d67144e1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      <webElementGuid>2250fc31-638b-4d11-b096-4321bcbbff7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::div[7]</value>
      <webElementGuid>e5ea00da-63c2-4b3e-ae0a-b4464a906809</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>e85ae4d8-6d47-4c5e-998a-b1c454b1b939</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Schedule a postShare to:0 Selected+Share methodSchedule postLet Eklipse post  your content at the chosen timeDate &amp; timeUnlock NowShare nowInstantly share your content with just one click.CaptionAI Post CaptionSelect ToneCasualWittyFormalGenerateBy default, your clips may appear in the community to help others discover great momentsManage SettingsPreview Your PostTikTokFacebookIG ReelsYT ShortsDiscord+Find clipSchedule' or . = 'Schedule a postShare to:0 Selected+Share methodSchedule postLet Eklipse post  your content at the chosen timeDate &amp; timeUnlock NowShare nowInstantly share your content with just one click.CaptionAI Post CaptionSelect ToneCasualWittyFormalGenerateBy default, your clips may appear in the community to help others discover great momentsManage SettingsPreview Your PostTikTokFacebookIG ReelsYT ShortsDiscord+Find clipSchedule')]</value>
      <webElementGuid>2d8ee638-d31f-4dff-a7da-f8c04d6bc489</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
