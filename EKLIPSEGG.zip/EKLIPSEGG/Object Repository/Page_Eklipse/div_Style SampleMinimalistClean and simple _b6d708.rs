<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Style SampleMinimalistClean and simple _b6d708</name>
   <tag></tag>
   <elementGuidId>845c821c-5c4f-44da-b805-5fdf38a0b583</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Capslock'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>47060709-3c61-49f0-b00f-9218a9372d49</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>95167c00-e5fa-434f-bae7-b76901eca738</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Style SampleMinimalistClean and simple edit focusing on the raw content.
Perfect for crucial gaming moments with raw impact.Don't show this againCloseApply Style</value>
      <webElementGuid>e4884614-ee20-43af-baa7-0448a99b8e17</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-ai-edit-style-confirm-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-xs modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>186a487c-cb8d-4bf2-81b0-ba0ad64a261d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capslock'])[1]/following::div[7]</value>
      <webElementGuid>7f6b0b99-b123-45be-8db5-ad6487689eb2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='jugs'])[5]/following::div[8]</value>
      <webElementGuid>ea203df5-b59d-4446-bdb6-bfacc740f910</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div</value>
      <webElementGuid>5f8565af-bc44-4748-a5d1-ed6ee7ee8d8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;Style SampleMinimalistClean and simple edit focusing on the raw content.
Perfect for crucial gaming moments with raw impact.Don&quot; , &quot;'&quot; , &quot;t show this againCloseApply Style&quot;) or . = concat(&quot;Style SampleMinimalistClean and simple edit focusing on the raw content.
Perfect for crucial gaming moments with raw impact.Don&quot; , &quot;'&quot; , &quot;t show this againCloseApply Style&quot;))]</value>
      <webElementGuid>4ac5f770-6e23-474b-94e6-99c25eaf5d86</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
