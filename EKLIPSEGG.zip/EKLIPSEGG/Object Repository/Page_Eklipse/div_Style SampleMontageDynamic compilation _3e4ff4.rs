<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Style SampleMontageDynamic compilation _3e4ff4</name>
   <tag></tag>
   <elementGuidId>3fd2e3ca-e34e-4945-9c23-5a336d62fac7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Capslock'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>35db0037-86cf-43c0-b2ad-8dcfa0e58420</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>af5baeef-3e94-4033-b40e-5e169e20a71f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Style SampleMontageDynamic compilation with music and smooth transitions
Ideal for action-packed clips with multiple highlights.Don't show this againCloseApply Style</value>
      <webElementGuid>a4fc999c-8f7c-4b65-a168-1dea9dacb3c0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-ai-edit-style-confirm-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-xs modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>9c83c28a-9104-48eb-bed0-3fbe9e2c05be</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capslock'])[1]/following::div[7]</value>
      <webElementGuid>c6072ad1-a5ee-4763-b50a-6df8afc05786</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='jugs'])[5]/following::div[8]</value>
      <webElementGuid>370980f6-a4ec-488a-8634-4963b24249e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div</value>
      <webElementGuid>3bcce4a5-623c-414d-af62-c602bac8e42e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = concat(&quot;Style SampleMontageDynamic compilation with music and smooth transitions
Ideal for action-packed clips with multiple highlights.Don&quot; , &quot;'&quot; , &quot;t show this againCloseApply Style&quot;) or . = concat(&quot;Style SampleMontageDynamic compilation with music and smooth transitions
Ideal for action-packed clips with multiple highlights.Don&quot; , &quot;'&quot; , &quot;t show this againCloseApply Style&quot;))]</value>
      <webElementGuid>e22b858c-cbef-4d09-aa4d-ee352a2eac40</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
