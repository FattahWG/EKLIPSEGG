<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Talking BRoll_1</name>
   <tag></tag>
   <elementGuidId>13ec5aeb-cbb8-4209-bb5b-56a15785e12d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Style Sample'])[1]/following::div[5]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>def26f79-0b61-4ef9-a51f-dc15fd4b4416</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title</value>
      <webElementGuid>62ad46b1-9a50-4b7f-b6c8-8eaa7e30cbba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Talking BRoll</value>
      <webElementGuid>1486f2bf-20a1-42a6-9193-4ac30ae485f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-ai-edit-style-confirm-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-xs modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;ai-edit-select-style-panel&quot;]/div[@class=&quot;style-description-wrapper mt-3&quot;]/div[@class=&quot;title&quot;]</value>
      <webElementGuid>94d550f0-8854-486d-8bac-9cead7173e89</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Style Sample'])[1]/following::div[5]</value>
      <webElementGuid>c193468e-058a-4b8a-bcad-bd653ff5c8ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Capslock'])[1]/following::div[14]</value>
      <webElementGuid>f72949ac-3a11-4821-97a1-88b983cfe649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='A sleek edit that integrates stock B-roll for smooth, cinematic transitions in non-gaming videos.'])[1]/preceding::div[1]</value>
      <webElementGuid>a203977e-1743-4100-91e8-e780eb2e9fd1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close'])[1]/preceding::div[3]</value>
      <webElementGuid>1f02ed48-e641-43eb-86ed-72fbecf65753</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/div[2]/div</value>
      <webElementGuid>a7626267-6ab5-47aa-aa37-fc67f320d2d2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Talking BRoll' or . = 'Talking BRoll')]</value>
      <webElementGuid>18ea7fd9-23bf-4f4b-8563-8633e1161897</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
