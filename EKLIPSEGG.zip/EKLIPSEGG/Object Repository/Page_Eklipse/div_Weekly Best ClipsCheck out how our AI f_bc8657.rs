<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Weekly Best ClipsCheck out how our AI f_bc8657</name>
   <tag></tag>
   <elementGuidId>70d95406-c78b-4377-913a-1486b28e00bf</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.modal-dialog.modal-dialog-centered > div.modal-content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>d7dac78d-32b4-4083-9e75-74f34fa75fd6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-content</value>
      <webElementGuid>0b15c196-1f69-451b-be9b-f6b7e472a52b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Weekly Best ClipsCheck out how our AI finds the epic moments in your stream!HakurenMaeVideo Player is loading.Play VideoPauseUnmuteCurrent Time 0:03/Duration 0:50Loaded: 31.48%0:04Stream Type LIVESeek to live, currently behind liveLIVERemaining Time -0:47 1xPlayback RateChaptersChaptersDescriptionsdescriptions off, selectedCaptionscaptions settings, opens captions settings dialogcaptions off, selectedAudio TrackPicture-in-PictureFullscreenThis is a modal window.Beginning of dialog window. Escape will cancel and close the window.TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentBackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparentWindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaqueFont Size50%75%100%125%150%175%200%300%400%Text Edge StyleNoneRaisedDepressedUniformDropshadowFont FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall CapsReset restore all settings to the default valuesDoneClose Modal DialogEnd of dialog window.AI EditOMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamerJune, 25th 2025#repoTry AI edit</value>
      <webElementGuid>9e7085b5-d41e-459a-b311-b8c38425155c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade community-highlight-clip-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]</value>
      <webElementGuid>f96a4e26-4c7f-4740-8c4d-1fa3617fdb99</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::div[7]</value>
      <webElementGuid>dc4abfc3-7c87-473c-834a-c06717ca76f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::div[7]</value>
      <webElementGuid>1d4c4f71-55fa-4427-934e-c46626d69aab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div</value>
      <webElementGuid>d3a3a1f9-2bae-4aa4-aa9d-ab1f0f86c424</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'Weekly Best ClipsCheck out how our AI finds the epic moments in your stream!HakurenMaeVideo Player is loading.Play VideoPauseUnmuteCurrent Time 0:03/Duration 0:50Loaded: 31.48%0:04Stream Type LIVESeek to live, currently behind liveLIVERemaining Time -0:47 1xPlayback RateChaptersChaptersDescriptionsdescriptions off, selectedCaptionscaptions settings, opens captions settings dialogcaptions off, selectedAudio TrackPicture-in-PictureFullscreenThis is a modal window.Beginning of dialog window. Escape will cancel and close the window.TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentBackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparentWindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaqueFont Size50%75%100%125%150%175%200%300%400%Text Edge StyleNoneRaisedDepressedUniformDropshadowFont FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall CapsReset restore all settings to the default valuesDoneClose Modal DialogEnd of dialog window.AI EditOMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamerJune, 25th 2025#repoTry AI edit' or . = 'Weekly Best ClipsCheck out how our AI finds the epic moments in your stream!HakurenMaeVideo Player is loading.Play VideoPauseUnmuteCurrent Time 0:03/Duration 0:50Loaded: 31.48%0:04Stream Type LIVESeek to live, currently behind liveLIVERemaining Time -0:47 1xPlayback RateChaptersChaptersDescriptionsdescriptions off, selectedCaptionscaptions settings, opens captions settings dialogcaptions off, selectedAudio TrackPicture-in-PictureFullscreenThis is a modal window.Beginning of dialog window. Escape will cancel and close the window.TextColorWhiteBlackRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentBackgroundColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyOpaqueSemi-TransparentTransparentWindowColorBlackWhiteRedGreenBlueYellowMagentaCyanTransparencyTransparentSemi-TransparentOpaqueFont Size50%75%100%125%150%175%200%300%400%Text Edge StyleNoneRaisedDepressedUniformDropshadowFont FamilyProportional Sans-SerifMonospace Sans-SerifProportional SerifMonospace SerifCasualScriptSmall CapsReset restore all settings to the default valuesDoneClose Modal DialogEnd of dialog window.AI EditOMG! 😱  R.E.P.O. Gameplay GONE WRONG!  Nothing but FEAR! 😨 #REPO #Gaming #Horror #Gameplay #Scary #streamerJune, 25th 2025#repoTry AI edit')]</value>
      <webElementGuid>982f91e3-14bb-402d-b6e5-f0e7759590c4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
