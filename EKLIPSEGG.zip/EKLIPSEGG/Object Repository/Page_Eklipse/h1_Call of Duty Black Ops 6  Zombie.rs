<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Call of Duty Black Ops 6  Zombie</name>
   <tag></tag>
   <elementGuidId>f7bcd956-9edf-4cb8-b35c-6364da673b69</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.game-title.mb-0</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div/div/div/div/div/div/div/div/div[2]/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>5e6011f7-dcd2-442e-81a1-7541ace58baf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>game-title mb-0</value>
      <webElementGuid>567d68a5-1d08-40ea-9b17-c2c8e0ce0e75</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Call of Duty: Black Ops 6 &amp; Zombie</value>
      <webElementGuid>dd200b96-d3b7-437c-891d-5d946e7a4462</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard unauthenticated&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;page-game-detail no-gutters p-3 row justify-content-center&quot;]/div[@class=&quot;col col-sm-10 col-xl-8&quot;]/div[@class=&quot;game-detail-container&quot;]/div[@class=&quot;game-info container px-md-0 ml-0&quot;]/div[@class=&quot;row justify-content-center&quot;]/div[@class=&quot;game-detail col-12 col-md-9 px-0 py-2 py-md-0&quot;]/div[@class=&quot;d-flex align-items-center game-name-container&quot;]/h1[@class=&quot;game-title mb-0&quot;]</value>
      <webElementGuid>c420bf12-be9e-4335-9686-0d814ae24179</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div/div/div/div/div/div/div/div/div[2]/div/h1</value>
      <webElementGuid>2ceabc4e-d8d4-481e-bc91-11292ce4eabe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Call of Duty: Black Ops 6 &amp; Zombie'])[1]/following::h1[1]</value>
      <webElementGuid>1238a94d-8ee0-4930-ad5b-f70f26cb958e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Game'])[1]/following::h1[1]</value>
      <webElementGuid>83ff0937-50af-45cd-9f37-82867c53b36d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Exclusive Game'])[1]/preceding::h1[1]</value>
      <webElementGuid>93e2b5bd-5b46-4ee6-991e-84b515c0cc3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Available Moments'])[1]/preceding::h1[1]</value>
      <webElementGuid>24586ac1-85c0-4a39-a37f-52f6f21d5233</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>615dce0e-7977-4c9b-8da5-09498e972b6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Call of Duty: Black Ops 6 &amp; Zombie' or . = 'Call of Duty: Black Ops 6 &amp; Zombie')]</value>
      <webElementGuid>e5245216-e961-4ab4-8b23-19ee4e40ea49</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
