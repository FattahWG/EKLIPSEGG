<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Get started on Eklipse</name>
   <tag></tag>
   <elementGuidId>f28f79f2-d9d8-4388-9b4d-e937be052db6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>h1.login-logo.text-center.my-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div/div[2]/div/h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>888d612e-901b-4c21-b9a1-7d5e6b2f2690</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>login-logo text-center my-2</value>
      <webElementGuid>5c1a7084-9682-4557-9bbe-2e6830b12f48</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Get started on Eklipse</value>
      <webElementGuid>6bd47a05-f5b6-4ec6-aca2-1c76db925493</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[@class=&quot;page-auth v2&quot;]/div[@class=&quot;container-fluid p-0&quot;]/div[@class=&quot;row m-0&quot;]/div[@class=&quot;section-login min-vh-100 col-12 col-lg-5&quot;]/div[@class=&quot;card-login card justify-content-center&quot;]/h1[@class=&quot;login-logo text-center my-2&quot;]</value>
      <webElementGuid>b8841b11-ec53-4bd2-94cc-b8a6c965fca7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div/div[2]/div/h1</value>
      <webElementGuid>ce01f550-2da4-4248-9a0b-330bcbfadc8f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Publish everything at once and boost your brand!'])[1]/following::h1[1]</value>
      <webElementGuid>aacba424-6ff1-469c-b56b-058d2f90289c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edit highlights into shareable clips instantly with AI-Edit.'])[1]/following::h1[1]</value>
      <webElementGuid>25919375-ab60-4b87-9e88-8a01d8207aa3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Continue with'])[1]/preceding::h1[1]</value>
      <webElementGuid>7791be1a-de3b-4e57-b908-6e4a5384d4b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OR'])[1]/preceding::h1[1]</value>
      <webElementGuid>48cef657-30a7-45f9-a0f1-8b4e7100f1bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Get started on Eklipse']/parent::*</value>
      <webElementGuid>fa29d5d3-ea2c-4b59-9b2b-2e3df1bb6134</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/h1</value>
      <webElementGuid>a06a4f0a-df07-43dc-9da0-46d62e154d28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Get started on Eklipse' or . = 'Get started on Eklipse')]</value>
      <webElementGuid>7f28c4b4-ff91-49d5-8dd8-c663778800cf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
