<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h2_Game Requests</name>
   <tag></tag>
   <elementGuidId>cb86d682-29c2-4a50-ab82-37b3a04ad9d5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div/div/h2</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h2</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h2</value>
      <webElementGuid>02575806-e1f5-4bf5-993c-b2d6d6a46899</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Game Requests</value>
      <webElementGuid>2463b471-c7ee-48c6-913b-043f16fd8807</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;game-requests-page&quot;]/div[@class=&quot;game-requests-container&quot;]/div[@class=&quot;d-flex justify-content-between align-items-center mb-3&quot;]/h2[1]</value>
      <webElementGuid>6261c980-ab32-4cdd-9dde-09eb8cc9317f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div/div/h2</value>
      <webElementGuid>fb049167-1713-4516-9e46-6cb9165bf422</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[3]/following::h2[1]</value>
      <webElementGuid>817b2468-48e8-427c-861d-a7434c3ef01e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Help'])[3]/following::h2[1]</value>
      <webElementGuid>7a7e4e91-7185-49b8-88b0-d87aeaf1835d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Submit Game'])[1]/preceding::h2[1]</value>
      <webElementGuid>5d59ecfa-0bb2-4d07-8515-59a2d6165a5c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Terms'])[1]/preceding::h2[1]</value>
      <webElementGuid>09ef6610-8f4e-4f5a-a551-e542544da921</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Game Requests']/parent::*</value>
      <webElementGuid>14ccbceb-3682-4aef-96c6-5b9c3c4ffc7c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2</value>
      <webElementGuid>300ca57c-297d-4f08-bde2-ae80ec587923</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h2[(text() = 'Game Requests' or . = 'Game Requests')]</value>
      <webElementGuid>244eb848-f7c1-4f49-afdd-f251e080080e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
