<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Professionally Edited</name>
   <tag></tag>
   <elementGuidId>08ed1959-31ce-4760-8963-2725e7db3c19</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div/div/div/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.ml-3.mb-0.align-self-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>82ed42b3-cd15-485f-b3f2-5491187b8495</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ml-3 mb-0 align-self-center</value>
      <webElementGuid>0ecf16c8-1a20-4b45-a6d8-88d150af80fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Professionally Edited</value>
      <webElementGuid>a982ea38-988e-4a9c-b4fb-af060e77712d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;ek-edited-video ek-pro-clips-page&quot;]/div[1]/div[@class=&quot;ek-create-clips--title&quot;]/div[1]/h3[@class=&quot;ml-3 mb-0 align-self-center&quot;]</value>
      <webElementGuid>d2eb812b-bafe-4287-bdc0-975dc15648d5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div/div/div/h3</value>
      <webElementGuid>d7984c13-aff4-4a97-91b2-1a732e27c066</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Pro Edits'])[2]/following::h3[1]</value>
      <webElementGuid>543558c9-1e10-47e6-a7df-826a038e5013</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edited Clip'])[1]/following::h3[1]</value>
      <webElementGuid>e2cf0e92-3f2f-4bfe-8d23-811bc50ea550</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Let our professional editors create a montage for you'])[1]/preceding::h3[1]</value>
      <webElementGuid>4c7fc198-b9af-4863-bf43-490ca648efd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sort by'])[1]/preceding::h3[1]</value>
      <webElementGuid>62b430f4-7bc0-40a4-b349-d6c7f7895633</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Professionally Edited']/parent::*</value>
      <webElementGuid>8372cd04-77d5-4f3f-9f1f-71dfd22ce2ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h3</value>
      <webElementGuid>1d720634-a11e-4de9-9939-1c8bc4d65f58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'Professionally Edited' or . = 'Professionally Edited')]</value>
      <webElementGuid>936e7bd1-10cf-47af-8cd4-a0cb5269e792</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
