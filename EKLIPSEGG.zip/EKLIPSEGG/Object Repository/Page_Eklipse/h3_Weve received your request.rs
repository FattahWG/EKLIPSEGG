<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h3_Weve received your request</name>
   <tag></tag>
   <elementGuidId>c16690b9-22c5-491a-8923-ebbde6809cfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div/div[2]/h3</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h3.mb-1.text-center</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
      <webElementGuid>9c5b0de6-c2e3-48d0-a1b1-f5741bc2ab21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mb-1 text-center</value>
      <webElementGuid>e2f4196b-9a2e-4d96-82d5-d9ad03e78061</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>We’ve received your request...</value>
      <webElementGuid>c9948cbe-6f65-4aac-a722-cc1048d7decb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[1]/div[@class=&quot;ek-waiting-stream-container&quot;]/div[@class=&quot;right-side-info&quot;]/h3[@class=&quot;mb-1 text-center&quot;]</value>
      <webElementGuid>afa89719-8508-4911-bdcf-e959fd70c52d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div/div[2]/h3</value>
      <webElementGuid>3de4dc6a-579f-4f14-bbfb-ab225ecb17bf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact us on discord!'])[1]/following::h3[1]</value>
      <webElementGuid>7dc64f57-2eec-401f-8a73-01c749b68b64</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get Notified'])[1]/preceding::h3[1]</value>
      <webElementGuid>32d01ce5-31f8-4f44-b92d-5beaf8a97b14</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Get Faster Processing'])[1]/preceding::h3[1]</value>
      <webElementGuid>119b1b10-a351-4fc4-88aa-4e659ab6ba24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='We’ve received your request...']/parent::*</value>
      <webElementGuid>9864d28a-7343-4b39-a3f2-4ab1e35e8ec7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/h3</value>
      <webElementGuid>956c3256-5485-48de-89aa-341ddf6f04ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h3[(text() = 'We’ve received your request...' or . = 'We’ve received your request...')]</value>
      <webElementGuid>e880340f-01f8-4d48-b546-a715280c5cf5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
