<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Not satisfied</name>
   <tag></tag>
   <elementGuidId>d17b9de9-21f0-4800-ad39-d5bcfd5c847c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='How would you rate our Customer Services?'])[1]/following::label[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>09167454-7cfa-45ea-9a26-f2401650e11e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>custom-input__container mb-3</value>
      <webElementGuid>10d1eb89-1195-433c-954b-dd137736904c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Not satisfied</value>
      <webElementGuid>fd158a8d-4c8c-4fec-811d-1d1a591e8f43</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade modal show&quot;]/div[@class=&quot;modal-dialog modal-md&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;p-4&quot;]/div[@class=&quot;row align-items-center justify-content-between mb-4&quot;]/div[@class=&quot;col-lg-3 custom-input&quot;]/label[@class=&quot;custom-input__container mb-3&quot;]</value>
      <webElementGuid>bf042c2d-466e-4088-90a2-25e59e73d6fb</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='How would you rate our Customer Services?'])[1]/following::label[1]</value>
      <webElementGuid>084bf7d7-45c8-4cca-891b-af4f4dc8eb8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Very satisfied'])[1]/following::label[1]</value>
      <webElementGuid>0687acf1-48e4-41be-bf12-c580b129ea56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Somewhat satisfied'])[2]/preceding::label[1]</value>
      <webElementGuid>1c2760ba-d55a-4228-a7d0-1621a3ea9d4a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Very satisfied'])[2]/preceding::label[2]</value>
      <webElementGuid>c6bc4522-d57e-41ec-9388-fc0193086f6a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/div[3]/div/label</value>
      <webElementGuid>136e8993-45d9-4bd1-a370-c88966a40f18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Not satisfied' or . = 'Not satisfied')]</value>
      <webElementGuid>c45d5ed3-2e0a-4d77-8a4e-faf5c4ac71ac</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
