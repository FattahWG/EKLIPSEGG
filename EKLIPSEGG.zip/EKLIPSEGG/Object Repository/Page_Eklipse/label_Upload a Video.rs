<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Upload a Video</name>
   <tag></tag>
   <elementGuidId>898a70ae-3181-4ba9-b765-ca7ec7fba115</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='upload-from-local-wrapper']/div/div[2]/label</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-6.text--highlight.cursor-pointer.text-right > label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>45f2dbd0-f6f4-4d3e-a810-a9a805de5655</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Upload a Video</value>
      <webElementGuid>793e37cf-cc91-44d9-9e95-cc0e93b76418</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;upload-from-local-wrapper&quot;)/div[@class=&quot;row justify-content-center align-items-center&quot;]/div[@class=&quot;col-6 text--highlight cursor-pointer text-right&quot;]/label[1]</value>
      <webElementGuid>f62f20dd-1c0e-4d25-a9dc-4127c0eb0377</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='upload-from-local-wrapper']/div/div[2]/label</value>
      <webElementGuid>ddcdb8c9-1add-4a34-8c02-6a8e4b5560d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload'])[1]/following::label[1]</value>
      <webElementGuid>ad87a3f2-535b-4d77-aa65-598cc0962df9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Stream Videos'])[1]/following::label[1]</value>
      <webElementGuid>5c594894-ba93-4cf5-b757-a3141bfee9cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Uploading files ...'])[1]/preceding::label[1]</value>
      <webElementGuid>331222e8-e4b2-487b-809a-1a3ec2a55163</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload Your Video from your Computer'])[1]/preceding::label[1]</value>
      <webElementGuid>6ca65b1b-105b-4caa-b97e-b0774a74dee3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Upload a Video']/parent::*</value>
      <webElementGuid>101daa4d-20a8-47e6-9a5a-8d288be1ba06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/label</value>
      <webElementGuid>66594a7f-7f43-482e-b950-a99564b37ea5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = 'Upload a Video' or . = 'Upload a Video')]</value>
      <webElementGuid>d6fc64df-3e31-4ced-a226-4f8a7b0e94b7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
