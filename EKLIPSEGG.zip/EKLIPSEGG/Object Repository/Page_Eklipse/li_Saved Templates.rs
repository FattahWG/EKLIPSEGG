<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Saved Templates</name>
   <tag></tag>
   <elementGuidId>3ff89e8c-f940-401a-a526-d02da2a3f83a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[4]/div/div/div[2]/div[2]/div[2]/ul/li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>6a11bed4-93a8-42a6-9620-1042a100db83</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tab-list-item ek-tab-style text-center w-50
                </value>
      <webElementGuid>339b5160-4d50-40a6-acac-2f82f730190c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Saved Templates</value>
      <webElementGuid>eedb2cfb-e3da-45e9-94bb-e46ae9bf8353</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;eklipse-ai-edit-customize-page&quot;]/div[@class=&quot;eklipse-ai-edit-customize-template&quot;]/div[@class=&quot;ai-edit-style-menu ai-edit-style-menu--no-nav-bar&quot;]/div[@class=&quot;menu-container menu-container--reverse&quot;]/div[@class=&quot;customize-style-container&quot;]/div[@class=&quot;ek-customize-panel&quot;]/div[@class=&quot;customize-option-container&quot;]/ul[@class=&quot;ek-list-tab-style&quot;]/li[@class=&quot;tab-list-item ek-tab-style text-center w-50&quot;]</value>
      <webElementGuid>01324706-088e-442c-883c-cf31d1e090f2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[4]/div/div/div[2]/div[2]/div[2]/ul/li[2]</value>
      <webElementGuid>03ae5972-a94e-4416-9055-24d33ccaaed2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Basic'])[1]/following::li[1]</value>
      <webElementGuid>e6128b87-7ba2-47d4-8d9f-31dda22150fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Layout Template'])[1]/following::li[2]</value>
      <webElementGuid>e1965113-9be5-42ac-a2b5-1910c0a98fc4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Top Split'])[1]/preceding::li[1]</value>
      <webElementGuid>392368bb-48ac-4569-b322-ad95639113a3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Full Screen'])[1]/preceding::li[1]</value>
      <webElementGuid>23815822-175c-42b2-b761-ff3cef5efe4e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Saved Templates']/parent::*</value>
      <webElementGuid>fce25b5c-9309-4b2f-b0a8-93f07f54e1f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]</value>
      <webElementGuid>71b0627d-ab89-4b9e-95e1-1e7b5deceff3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Saved Templates' or . = 'Saved Templates')]</value>
      <webElementGuid>cb20a38a-03b8-4d5e-91e4-76a1307e1e20</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
