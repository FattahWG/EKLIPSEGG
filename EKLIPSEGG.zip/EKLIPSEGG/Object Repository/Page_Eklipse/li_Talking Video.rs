<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Talking Video</name>
   <tag></tag>
   <elementGuidId>5be33514-4f28-4794-903b-9c80cce2ecba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>c45a5d10-9363-4e0b-936f-29559a603853</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tab-list-item btn-filter-stream ek-tab-style</value>
      <webElementGuid>90925139-882a-4237-ac23-01f28d8c4fa9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Talking Video</value>
      <webElementGuid>bfc84179-585a-45e4-a909-165c9076325e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;ek-streams ek-streams-page&quot;]/div[@class=&quot;flex-column d-flex mt-4&quot;]/div[1]/ul[@class=&quot;ek-list-tab-style mb-3&quot;]/li[@class=&quot;tab-list-item btn-filter-stream ek-tab-style&quot;]</value>
      <webElementGuid>38db67cf-d0bd-4fd7-aae4-67b2a6c9db85</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li[2]</value>
      <webElementGuid>535e9e28-dbf5-4b77-82eb-ade6cf610432</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Gaming Video'])[1]/following::li[1]</value>
      <webElementGuid>6014c35a-4700-4550-a092-4b4fda8e370f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Playlist'])[2]/following::li[2]</value>
      <webElementGuid>f6a828e3-70a9-445e-b8c2-6f538664f3ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Didn’t see your stream?'])[1]/preceding::li[1]</value>
      <webElementGuid>4f6b9b31-c517-471f-b1e9-504d825f3d8b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Refresh'])[1]/preceding::li[1]</value>
      <webElementGuid>bf45fe84-7ec9-4d58-8f3a-a001f09b2319</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Talking Video']/parent::*</value>
      <webElementGuid>84a35754-1efb-4e51-bef6-1336edb018bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/li[2]</value>
      <webElementGuid>b122acf3-337a-4af9-80fd-f4ed1a119444</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Talking Video' or . = 'Talking Video')]</value>
      <webElementGuid>d73c1199-0e3a-4578-99ec-5f30dd7b5e2a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
