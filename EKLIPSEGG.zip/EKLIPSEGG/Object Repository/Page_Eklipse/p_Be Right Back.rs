<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Be Right Back</name>
   <tag></tag>
   <elementGuidId>b32e76a9-36c0-403a-874e-f80421f6b398</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.sc-gswNZR.bbLVwL.plugin-setting-tab > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>467c282d-9b04-46d5-b9e7-7e0aa784e178</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Be Right Back</value>
      <webElementGuid>3ed3fbd4-98fb-4c5d-80b3-7bcfd3846209</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;ek-account-setting&quot;]/div[@class=&quot;sc-dkrFOg bpDwEs&quot;]/div[@class=&quot;waiting-screen-setting-container&quot;]/ul[@class=&quot;sc-bcXHqe sZiLj plugin-setting-tabs&quot;]/li[@class=&quot;sc-gswNZR bbLVwL plugin-setting-tab&quot;]/p[1]</value>
      <webElementGuid>a53a2e98-7c6f-4654-a8de-3d85a2ede0ca</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li/p</value>
      <webElementGuid>5fce8fd1-7f3e-4cd7-b0f9-23cf4c1f42ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close Modal Dialog'])[1]/following::p[3]</value>
      <webElementGuid>44896bf9-b22f-427f-9a35-9ca84d1cba1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Done'])[1]/following::p[3]</value>
      <webElementGuid>1d69a7e0-603e-42f2-b773-9634bbd21778</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Be Right Back URL'])[1]/preceding::p[2]</value>
      <webElementGuid>df351797-11fa-4f1a-b229-3eb244da53ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Copy URL of your Be Right Back screen to your OBS'])[1]/preceding::p[2]</value>
      <webElementGuid>7006f41c-427f-44b0-9490-9d926d26eec4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Be Right Back']/parent::*</value>
      <webElementGuid>cf4cd6be-35ef-4add-b3a4-448344ddcad8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div[2]/div/ul/li/p</value>
      <webElementGuid>9d430f58-dfa8-4f1b-a7bf-9b0a20df2875</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Be Right Back' or . = 'Be Right Back')]</value>
      <webElementGuid>8ec03414-af9f-4ccd-b19f-2887259ce32a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
