<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Game Setting</name>
   <tag></tag>
   <elementGuidId>8bd73fdf-01c9-4acc-a245-a799eba386a2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='4']/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#4 > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>d38e6431-0420-4b77-b3e0-cfcdb2f55ee5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Game Setting</value>
      <webElementGuid>8e11467e-55a5-4634-a545-69c8ab38485b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;4&quot;)/p[1]</value>
      <webElementGuid>ab2cf709-970a-47be-a51e-2787d70064bf</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='4']/p</value>
      <webElementGuid>eafdc7f9-33f0-46bb-934c-ed7b48b3e99a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Setting'])[1]/following::p[3]</value>
      <webElementGuid>fea9bde2-635a-435d-bea3-225f7b17f812</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[3]/following::p[3]</value>
      <webElementGuid>68ef8700-ccb6-4fe4-8b77-0abb3522aac5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[3]/preceding::p[1]</value>
      <webElementGuid>0c04c913-55b0-4198-8737-27aeca5d804a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Connect Rumble to Eklipse now!'])[1]/preceding::p[1]</value>
      <webElementGuid>94490e2f-b546-433c-be99-5b576d7935b7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Game Setting']/parent::*</value>
      <webElementGuid>0bf7ffa2-e12a-4600-9fba-525d09d11266</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/p</value>
      <webElementGuid>95f3c15b-d32f-4284-8c09-23b8294d914d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Game Setting' or . = 'Game Setting')]</value>
      <webElementGuid>667c7057-cd8c-43e0-8372-c4ab92540827</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
