<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Level Up with Eklipse Premium</name>
   <tag></tag>
   <elementGuidId>d7ad7a4c-e3eb-487d-a9f4-3216a4162590</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.title.text-blur</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>4e590b1c-ad88-416e-b03d-4d15a3972d88</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-blur</value>
      <webElementGuid>7a28fe95-8569-4810-9765-ff701d9c653d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Level Up with Eklipse Premium</value>
      <webElementGuid>b93b2641-f746-4847-b628-f6df4fea377f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-modal ek-modal-cta-upgrade-premium modal show&quot;]/div[@class=&quot;modal-dialog modal-lg modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;upgrade-content px-3 pt-3&quot;]/p[@class=&quot;title text-blur&quot;]</value>
      <webElementGuid>2d29ee17-dff6-41a1-bd3a-abaf2e063489</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept'])[1]/following::p[1]</value>
      <webElementGuid>55a04f7a-da5f-46ee-81e4-3370148d52c4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Reject'])[1]/following::p[1]</value>
      <webElementGuid>a5e2fcb8-a45f-451b-a74f-0006ffb670ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Select Plan'])[1]/preceding::p[7]</value>
      <webElementGuid>2b3c7e9d-5dcc-4bdc-9a4c-60a780ecf3bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Monthly'])[1]/preceding::p[7]</value>
      <webElementGuid>7e45d20e-b261-46b6-851d-3d3dd6b653e8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Level Up with Eklipse Premium']/parent::*</value>
      <webElementGuid>d3a9d39a-a66f-477a-94db-15ef2d052cc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/div/div/div/div/p</value>
      <webElementGuid>b0aa44ac-c4db-441a-9535-dd9f7fbdae62</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Level Up with Eklipse Premium' or . = 'Level Up with Eklipse Premium')]</value>
      <webElementGuid>e49434c2-4360-42f5-844a-c4ad82fef52d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
