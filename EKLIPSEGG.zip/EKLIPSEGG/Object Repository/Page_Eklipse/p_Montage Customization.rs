<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Montage Customization</name>
   <tag></tag>
   <elementGuidId>85b0b6fd-7829-4272-8154-be099e3610e6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[2]/div/div/div[2]/div/div/div/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div > p.m-0.text--large</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>12c16233-896f-4205-bd86-9733733e78b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>m-0 text--large</value>
      <webElementGuid>fbaa3d7d-fec3-43a4-834c-1177aee0221a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Montage Customization</value>
      <webElementGuid>f2bbe242-b50b-453d-8e7c-05f362635b9e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;eklipse-ai-edit-customize-page&quot;]/div[@class=&quot;eklipse-ai-edit-customize-menu&quot;]/div[@class=&quot;ai-edit-style-menu&quot;]/div[@class=&quot;menu-container none-scroll-bar&quot;]/div[@class=&quot;customize-style-container&quot;]/div[@class=&quot;ai-edit-style-customize&quot;]/div[1]/div[@class=&quot;ek-customize-panel&quot;]/div[@class=&quot;style-name-container customize-option-container&quot;]/div[1]/p[@class=&quot;m-0 text--large&quot;]</value>
      <webElementGuid>ce4cf69b-9dbb-4294-a362-7f6d5d0c80a7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[2]/div/div/div[2]/div/div/div/div/div/p</value>
      <webElementGuid>c9769927-c9a7-4de9-bc9c-2c78fa226da3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Generate AI Edit'])[1]/following::p[6]</value>
      <webElementGuid>f0e6a0d2-6bc8-415c-9dc0-758a576cd6a7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Transition'])[1]/preceding::p[1]</value>
      <webElementGuid>63181a3a-f15d-4c67-8693-ef66eddf64a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Audio'])[1]/preceding::p[1]</value>
      <webElementGuid>45a6d5d8-52b1-4910-b5b4-11f8dccd608d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Montage Customization']/parent::*</value>
      <webElementGuid>3fa4dc2f-8733-4cb7-afc0-0e7e8d2ae6fa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div/div/p</value>
      <webElementGuid>8002af10-9a57-4c11-bd32-997ab7ee8625</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Montage Customization' or . = 'Montage Customization')]</value>
      <webElementGuid>51e9a23e-914b-4a08-bc8e-7ca430ecd2cf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
