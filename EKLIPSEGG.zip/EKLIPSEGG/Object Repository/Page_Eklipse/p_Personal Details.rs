<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Personal Details</name>
   <tag></tag>
   <elementGuidId>fd072fa7-b9d0-4a94-b0d8-4d2e351f7e78</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='0']/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#0 > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>c84928ff-db13-46f5-89c1-95d23ebfb687</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Personal Details</value>
      <webElementGuid>7ec4e141-2589-4eef-a777-93ce99583ffe</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;ek-account-setting&quot;]/ul[@class=&quot;sc-bcXHqe sZiLj account-setting-header&quot;]/li[@id=&quot;0&quot;]/p[1]</value>
      <webElementGuid>d19054f6-37b7-4b5c-8855-1bcf98f1689b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='0']/p</value>
      <webElementGuid>98870915-b193-451d-b750-2e14e4a2c0a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Setting'])[1]/following::p[1]</value>
      <webElementGuid>8c77b092-c085-4976-9ec4-8d846d1039e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[3]/following::p[1]</value>
      <webElementGuid>98d87655-9b3d-4d4e-a549-6fea6b1fece9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[3]/preceding::p[3]</value>
      <webElementGuid>be8bc55a-c1e8-49a3-aca5-f41003651649</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Connect Rumble to Eklipse now!'])[1]/preceding::p[3]</value>
      <webElementGuid>a38f0e49-6c98-4dad-acbb-0a957511f53f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Personal Details']/parent::*</value>
      <webElementGuid>132f674a-6f76-4625-aa57-edea006771c1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/ul/li/p</value>
      <webElementGuid>db416b1b-15bb-426c-8eb4-6270dd774520</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Personal Details' or . = 'Personal Details')]</value>
      <webElementGuid>3e592712-6062-47fd-8778-9abadf4f5765</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
