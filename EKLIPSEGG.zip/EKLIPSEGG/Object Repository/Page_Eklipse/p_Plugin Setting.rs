<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Plugin Setting</name>
   <tag></tag>
   <elementGuidId>15890da1-3547-4bbc-9a0a-3b28638d49df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//li[@id='3']/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#3 > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>57bc63cc-5094-4741-a900-aca29b4d78f6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Plugin Setting</value>
      <webElementGuid>c1331eb2-c68f-4376-bc59-117184e9f944</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;3&quot;)/p[1]</value>
      <webElementGuid>d7f7470a-c0f0-48f5-91f8-cf92f78074cd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//li[@id='3']/p</value>
      <webElementGuid>157e505d-e25d-413c-b299-0092db9ec1e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Account Setting'])[1]/following::p[2]</value>
      <webElementGuid>379cd8d8-a9ba-40f2-86b8-7f4632fd4bdc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Logout'])[3]/following::p[2]</value>
      <webElementGuid>54de4b79-bff5-4aa5-a2a4-193cfe8250d8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='New'])[3]/preceding::p[2]</value>
      <webElementGuid>8492b799-692f-4fa7-b966-2bc9f246a313</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Connect Rumble to Eklipse now!'])[1]/preceding::p[2]</value>
      <webElementGuid>3a86b84c-69c2-4a04-a5b4-1b7f4f38a2a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Plugin Setting']/parent::*</value>
      <webElementGuid>2df70a2d-844b-4614-bb77-10421d7e180f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/p</value>
      <webElementGuid>f49aa4ea-34a7-43c1-a9c4-d33e0b9b2e99</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Plugin Setting' or . = 'Plugin Setting')]</value>
      <webElementGuid>181b47c4-06c5-4328-b970-d9ec86e9b869</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
