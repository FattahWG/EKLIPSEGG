<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Starting Soon</name>
   <tag></tag>
   <elementGuidId>6fd55df1-08e3-4f26-9739-2ff8675b3431</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li[2]/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>bfbe1bd8-51df-43a8-8751-13b4f298d25e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Starting Soon</value>
      <webElementGuid>7964a6bb-6d79-470b-b984-5d58ed2c71d8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard&quot;]/div[@class=&quot;ek-account-setting&quot;]/div[@class=&quot;sc-dkrFOg bpDwEs&quot;]/div[@class=&quot;waiting-screen-setting-container&quot;]/ul[@class=&quot;sc-bcXHqe sZiLj plugin-setting-tabs&quot;]/li[@class=&quot;sc-gswNZR bbLVwL plugin-setting-tab&quot;]/p[1]</value>
      <webElementGuid>dda85c6d-4964-48bd-8467-9b5b4e6dcf0c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div[2]/div/ul/li[2]/p</value>
      <webElementGuid>866166c4-f924-4d87-9398-8b114c537ab9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close Modal Dialog'])[1]/following::p[4]</value>
      <webElementGuid>d545bece-a913-4ade-bd46-66c2480a4cf5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Done'])[1]/following::p[4]</value>
      <webElementGuid>0fe7652c-9710-4472-84ab-025a6252532e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Be Right Back URL'])[1]/preceding::p[1]</value>
      <webElementGuid>b0db84e5-a1bb-4ef9-96e6-d9386a09abed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Copy URL of your Be Right Back screen to your OBS'])[1]/preceding::p[1]</value>
      <webElementGuid>9e93f35e-6995-40dd-aa34-aa2e6926abf2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Starting Soon']/parent::*</value>
      <webElementGuid>ba5dd7d6-4606-4859-a0c2-70553b074681</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/ul/li[2]/p</value>
      <webElementGuid>025e1065-782e-4131-bccc-40ff4addcaeb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Starting Soon' or . = 'Starting Soon')]</value>
      <webElementGuid>208b1adc-0051-4abc-baa3-3c40b97b7054</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
