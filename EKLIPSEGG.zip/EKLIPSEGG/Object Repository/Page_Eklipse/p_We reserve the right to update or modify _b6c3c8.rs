<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_We reserve the right to update or modify _b6c3c8</name>
   <tag></tag>
   <elementGuidId>d3a3fbbf-732d-4ddb-9869-ed3811fd7fb4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>p:nth-of-type(45)</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Changes to This Policy'])[1]/following::p[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>530c30ac-ba5f-4cc0-a27b-5d28873258b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>We reserve the right to update or modify this Payment, Refund, and Fees policy at any time. Changes will be effective as of the date of the update. We will notify you of any significant changes through our platform.</value>
      <webElementGuid>c7a3594a-a06e-49c4-a13c-50484412fdc0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-modal ek-modal-terms-and-conditions modal show&quot;]/div[@class=&quot;modal-dialog modal-sm modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;container p-4 d-flex flex-column align-items-center&quot;]/div[@class=&quot;terms-container p-3&quot;]/div[1]/p[45]</value>
      <webElementGuid>002b793e-5c66-4a95-a32a-6b6b13709d79</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Changes to This Policy'])[1]/following::p[1]</value>
      <webElementGuid>384ff27d-5791-4f21-a61a-80ba1d13e955</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Subscription through App Store or Google Play'])[1]/following::p[2]</value>
      <webElementGuid>312052ab-5ca7-4f14-a9f6-c1bebacb4ffc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accept and agree'])[1]/preceding::p[1]</value>
      <webElementGuid>f0a28521-2a32-4189-a361-44c140277738</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='We reserve the right to update or modify this Payment, Refund, and Fees policy at any time. Changes will be effective as of the date of the update. We will notify you of any significant changes through our platform.']/parent::*</value>
      <webElementGuid>cb0cf7fe-7c82-45e1-af48-2b544f5b52da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p[45]</value>
      <webElementGuid>0e780177-81a0-4f50-bffd-875631b02b1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'We reserve the right to update or modify this Payment, Refund, and Fees policy at any time. Changes will be effective as of the date of the update. We will notify you of any significant changes through our platform.' or . = 'We reserve the right to update or modify this Payment, Refund, and Fees policy at any time. Changes will be effective as of the date of the update. We will notify you of any significant changes through our platform.')]</value>
      <webElementGuid>37d17938-2e5e-4ea1-b892-95c3549c8241</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
