<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_TikTokFacebookIG ReelsYT ShortsDiscord</name>
   <tag></tag>
   <elementGuidId>5189cd9f-a3b3-4650-bb75-1b7e440318b2</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Preview Your Post'])[1]/following::select[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>select.ek-dropdown-list</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>03bcc22a-0cde-4006-82c4-805b4da52a69</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ek-dropdown-list</value>
      <webElementGuid>a18d0837-7da0-4007-86d0-eb24cd07ffa4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>TikTokFacebookIG ReelsYT ShortsDiscord</value>
      <webElementGuid>fee6bd7f-e3eb-4f00-92ae-3e442074dfa2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ek-schedule-post-modal modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;schedule-post-modal-body&quot;]/div[@class=&quot;preview-container post-step-1&quot;]/select[@class=&quot;ek-dropdown-list&quot;]</value>
      <webElementGuid>4ba97236-1f85-4860-805a-ce358bfa6e8e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Preview Your Post'])[1]/following::select[1]</value>
      <webElementGuid>d2ae248e-7df8-42b0-9690-3583d93a8aae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Manage Settings'])[1]/following::select[1]</value>
      <webElementGuid>c03c853d-e992-4053-ba8f-326df392a034</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[2]/preceding::select[1]</value>
      <webElementGuid>91078c72-ebdd-480c-8ca5-454df4466b3a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Find clip'])[1]/preceding::select[1]</value>
      <webElementGuid>64d58f16-4d0e-4f40-8bef-77917cd34ddc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>e1175641-c762-432a-8dd6-e4345d47e682</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[(text() = 'TikTokFacebookIG ReelsYT ShortsDiscord' or . = 'TikTokFacebookIG ReelsYT ShortsDiscord')]</value>
      <webElementGuid>d113926c-a5e0-4397-989e-058857f03889</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
