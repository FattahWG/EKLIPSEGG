<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Change Layout</name>
   <tag></tag>
   <elementGuidId>c4e4ed79-3f85-4274-928a-60fe70b02e47</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='app']/div/div/div[4]/div/div/div[2]/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.ml-2.prevent-text-selection</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>0ce656b4-9eb3-4928-8c96-5258457415da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ml-2 prevent-text-selection</value>
      <webElementGuid>0ab66ab4-a54a-42cf-9c1d-4a2cc3c40ff2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Change Layout</value>
      <webElementGuid>d9d284da-ef6c-4eab-8eb1-a9699b39ae9a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;app&quot;)/div[1]/div[@class=&quot;eklipse-ai-edit-customize-page&quot;]/div[@class=&quot;eklipse-ai-edit-customize-template&quot;]/div[@class=&quot;ai-edit-style-menu ai-edit-style-menu--no-nav-bar&quot;]/div[@class=&quot;menu-container menu-container--reverse&quot;]/div[@class=&quot;customize-style-container&quot;]/div[@class=&quot;p-3 d-flex justify-content-between align-items-center&quot;]/span[@class=&quot;ml-2 prevent-text-selection&quot;]</value>
      <webElementGuid>e71cb5c9-cd85-408a-80bd-8c5cdd734204</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='app']/div/div/div[4]/div/div/div[2]/div/span</value>
      <webElementGuid>004ca075-99c0-4339-b6e5-374316bb2c3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Beta'])[1]/following::span[1]</value>
      <webElementGuid>fefd77ec-91d3-42c0-a2b5-7e2b1c6b1cef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Custom Prompt'])[1]/following::span[1]</value>
      <webElementGuid>2fab2671-7140-499d-bdb6-59a9b39e44cd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Aspect Ratio'])[1]/preceding::span[1]</value>
      <webElementGuid>df3ba023-a724-4e90-8876-663990d89957</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Layout Template'])[1]/preceding::span[1]</value>
      <webElementGuid>a733be7a-9eb0-4c5e-b080-efecf078cae5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span</value>
      <webElementGuid>7762ef6d-2d96-48fb-a5a6-53da56d6f3bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Change Layout' or . = 'Change Layout')]</value>
      <webElementGuid>5708cc12-ee4b-4086-9285-2577f9bbb83c</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
