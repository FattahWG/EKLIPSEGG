<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Dont show this again</name>
   <tag></tag>
   <elementGuidId>b6a6671b-316a-4632-9a3b-ae4b8e6ed971</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Close Modal Dialog'])[1]/following::span[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.content</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>edf9332d-0cd9-4f27-92d7-a7dbbb82d11e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>content</value>
      <webElementGuid>dcbf8934-d28b-46a7-ac44-5b12d6e6c95d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Don't show this again</value>
      <webElementGuid>8772c089-54a7-478e-9262-17600c7c29f7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;modal-open&quot;]/div[@class=&quot;fade ai-edit-modal-container current-step-1 modal show&quot;]/div[@class=&quot;modal-dialog modal-dialog-centered&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;ai-edit-modal-container&quot;]/div[1]/div[@class=&quot;introduce-ai-panel&quot;]/div[@class=&quot;d-flex action-panel&quot;]/div[1]/div[@class=&quot;checkbox-section&quot;]/label[@class=&quot;ipt-label&quot;]/span[@class=&quot;content&quot;]</value>
      <webElementGuid>ea642118-9376-4cb3-8440-1a99b58a6396</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Close Modal Dialog'])[1]/following::span[2]</value>
      <webElementGuid>cebf7edf-de31-4627-ac5f-92813dcc95db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Done'])[1]/following::span[4]</value>
      <webElementGuid>4447ae7c-4a90-454d-8f84-6364589e763e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Start AI Edit'])[1]/preceding::span[1]</value>
      <webElementGuid>7517a115-4ed1-477f-950b-21c2ba2e438b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label/span[2]</value>
      <webElementGuid>aa920cce-db6f-4784-a117-62de8635d73c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;Don&quot; , &quot;'&quot; , &quot;t show this again&quot;) or . = concat(&quot;Don&quot; , &quot;'&quot; , &quot;t show this again&quot;))]</value>
      <webElementGuid>e702d91b-cd07-4167-ac3f-2fedd12a687d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
