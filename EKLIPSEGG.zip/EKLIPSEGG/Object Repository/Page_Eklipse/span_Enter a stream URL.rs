<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Enter a stream URL</name>
   <tag></tag>
   <elementGuidId>cce450d9-ee92-4a54-898f-c98d197f46f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='dashboard']/div[3]/div/div/div/div/div[2]/div/div[2]/div/div[2]/div[3]/div[2]/div/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.mx-auto > div.d-flex.align-items-center.gap-2.mb-2 > span.text-secondary</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>39a4de93-617a-49f2-8dce-0155272a7ad7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-secondary</value>
      <webElementGuid>594ab54c-dc54-42d4-99ef-4f12ffebc105</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Enter a stream URL</value>
      <webElementGuid>8ef1c1b1-5ee0-429b-9d4e-1e73920c3f99</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dashboard&quot;)/div[@class=&quot;ek-dashboard&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;container-children-dashboard p-0&quot;]/div[@class=&quot;ek-widget-wrapper d-flex&quot;]/div[@class=&quot;ek-dashboard__home ek-content-bar&quot;]/div[@class=&quot;ek-streamlist-container d-flex flex-column flex-xl-row&quot;]/div[@class=&quot;ek-stream-list w-100&quot;]/div[@class=&quot;d-flex gap-3 mt-3 flex-column flex-md-row empty-state-for-new-user-section&quot;]/div[@class=&quot;p-3 bg-base rounded-md generate-your-stream-highlight-section w-100&quot;]/div[@class=&quot;connect-and-import-from-empty-state-section&quot;]/div[@class=&quot;import-stream-from-empty-state-section bg-gray py-4 px-3 border--rounded__16 h-100 d-flex flex-column&quot;]/div[@class=&quot;mx-auto&quot;]/div[@class=&quot;d-flex align-items-center gap-2 mb-2&quot;]/span[@class=&quot;text-secondary&quot;]</value>
      <webElementGuid>e8bae6a1-4daf-4448-8254-9ab51fd0d709</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='dashboard']/div[3]/div/div/div/div/div[2]/div/div[2]/div/div[2]/div[3]/div[2]/div/span</value>
      <webElementGuid>86ef3fdf-9635-4881-9d43-8c90d2b9fe50</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='External Source'])[1]/following::span[1]</value>
      <webElementGuid>5b8882b8-ae84-4725-bd5b-5f13f5f8e520</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload TikTok Live'])[1]/preceding::span[1]</value>
      <webElementGuid>32e3f2b4-d862-41c7-afc1-cd917385702d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Upload from local files'])[1]/preceding::span[2]</value>
      <webElementGuid>4770bdf7-1ff5-43d3-b0b7-fbda80c8b93f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Enter a stream URL']/parent::*</value>
      <webElementGuid>7a78fbdd-beee-4a84-896f-1b0214637685</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div[2]/div/span</value>
      <webElementGuid>cdb79c56-fc71-44c1-a284-863ccbb3dcc6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Enter a stream URL' or . = 'Enter a stream URL')]</value>
      <webElementGuid>eb4e7196-3213-47c2-a1a7-4a290220fd36</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
