<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Montages_icon-collapse-sub-menu icon-c_9f202c</name>
   <tag></tag>
   <elementGuidId>786cb987-3ab8-4aaa-b8b3-787fe13d0d7c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mySidebar']/div[2]/nav/ul/li[6]/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li.sidebar-item.sidebar-item__dropdown.opened.false.undefined > span.icon-collapse-sub-menu.icon-collapse-sub-menu-up.hover-effect</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>a642c7df-84e7-41f4-a6ef-10d5b11a68bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>icon-collapse-sub-menu icon-collapse-sub-menu-up hover-effect</value>
      <webElementGuid>40d4132b-cd5e-4dcf-8757-bfffbf0c8dc1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mySidebar&quot;)/div[@class=&quot;menu-box-content&quot;]/nav[@class=&quot;navbar&quot;]/ul[@class=&quot;sidebar-menu&quot;]/li[@class=&quot;sidebar-item sidebar-item__dropdown opened  false undefined&quot;]/span[@class=&quot;icon-collapse-sub-menu icon-collapse-sub-menu-up hover-effect&quot;]</value>
      <webElementGuid>2bf6b1c6-a6e6-42a0-aa36-5b69b732e436</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mySidebar']/div[2]/nav/ul/li[6]/span</value>
      <webElementGuid>ec4325d4-8b6d-489e-a2e6-afb6e9f8f5cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Montages'])[1]/following::span[1]</value>
      <webElementGuid>d079b23d-7690-4924-afa6-e13921fc0ef6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Edited Clips'])[1]/following::span[2]</value>
      <webElementGuid>46336ac8-f78e-44cc-81d0-612cd91c5a5d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Content Publisher'])[1]/preceding::span[1]</value>
      <webElementGuid>378f1e1b-a1ea-484c-94b4-603d35013a74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Time-saving Tools'])[1]/preceding::span[2]</value>
      <webElementGuid>2ad56771-e102-45ea-a40f-5a9e61c0bc28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]/span</value>
      <webElementGuid>0e9f7a57-b96a-490e-9b4a-607d8b91eb05</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
